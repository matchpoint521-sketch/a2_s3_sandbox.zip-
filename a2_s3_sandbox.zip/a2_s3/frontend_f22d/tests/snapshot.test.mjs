// The built snapshot must match its manifest exactly (F2.2a: relative paths, any layout the
// rules accept). Validation logic lives in tests/helpers/snapshot-rules.mjs; negative
// fixtures for it are in tests/snapshot_rules.test.mjs.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { FRONTEND } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { inspectSnapshot, only, kindOf, listAll, buildIdOf } from './helpers/snapshot-rules.mjs';

const SKIP = SNAPSHOT_BUILT ? false : 'SKIP: data/snapshot not built (run tools/build_snapshot.py)';
const dir = path.join(FRONTEND, 'data/snapshot');

test('snapshot files match the manifest hashes and nothing extra exists', { skip: SKIP }, () => {
  const problems = inspectSnapshot(dir);
  assert.deepEqual(only(problems, 'files', 'hash', 'build', 'inputs', 'games', 'isolation'), []);
  // Explicit restatement of the F1.5 guarantees: exact relative-path set, build id, no audit.
  const m = JSON.parse(readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
  assert.deepEqual(listAll(dir).filter((f) => f !== 'manifest.json'), Object.keys(m.outputs).sort());
  assert.equal(m.build_id, buildIdOf(m.outputs));
  assert.ok(!listAll(dir).some((f) => /(^|\/)audit\//.test(f)), 'no audit files in the served snapshot');
});

test('snapshot capabilities and classes match the build kind (F1: games off, curated only)', { skip: SKIP }, () => {
  const problems = inspectSnapshot(dir);
  assert.deepEqual(only(problems, 'capabilities', 'classes', 'labels'), []);
  const m = JSON.parse(readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
  for (const k of ['headToHead', 'players', 'playerStats', 'statCoverage', 'compare']) assert.equal(m.capabilities[k], false, k);
  if (kindOf(dir) === 'f1') {
    // F1.5 assertions, unchanged in meaning.
    assert.equal(m.capabilities.games, false);
    assert.deepEqual(m.classes, ['curated']);
  } else {
    assert.equal(m.capabilities.games, true);
    assert.deepEqual(m.classes, ['curated', 'derived', 'source']);
  }
});
