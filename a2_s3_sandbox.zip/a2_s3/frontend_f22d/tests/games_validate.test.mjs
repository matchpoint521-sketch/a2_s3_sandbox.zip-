// F2.2d-A1 S2: synthetic tests for src/core/games.js (pure functions; no provider, no files).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { gameFixture } from './helpers/game-fixtures.mjs';
import {
  makeGameContext, validateShard, validateIndex, validateRecords, checkIndexForSeason, checkSeasonRecords,
  indexLookup, shardLookup, recordLookups, recomputeSeason, coverageState, validateFilters, filterGames,
  isCalendarDate, isGameId, weekRange, GAME_TYPES, POSTSEASON_TYPES, RECORD_STATUSES,
} from '../src/core/games.js';

const ctxOf = (f) => makeGameContext(f);
// Run `edit` on a fresh fixture, then the named check; expect at least one problem matching `re`.
function expectProblem(check, edit, re) {
  const f = gameFixture();
  edit(f);
  const ctx = ctxOf(f);
  const problems = {
    shard2001: () => validateShard(f.shards[2001], 2001, ctx),
    shard2002: () => validateShard(f.shards[2002], 2002, ctx),
    index: () => validateIndex(f.index, ctx),
    records: () => validateRecords(f.records, ctx),
    pair2001: () => checkIndexForSeason(indexLookup(f.index), 2001, f.shards[2001]),
    recompute2001: () => checkSeasonRecords(2001, f.shards[2001], f.records.records),
    recompute2002: () => checkSeasonRecords(2002, f.shards[2002], f.records.records),
  }[check]();
  assert.ok(problems.some((p) => re.test(p)), `${check}: expected ${re}, got ${JSON.stringify(problems)}`);
}

test('G-V00 the clean fixture passes every check', () => {
  const f = gameFixture();
  const ctx = ctxOf(f);
  const seasonOf = indexLookup(f.index);
  for (const y of [2001, 2002]) {
    assert.deepEqual(validateShard(f.shards[y], y, ctx), [], `shard ${y}`);
    assert.deepEqual(checkIndexForSeason(seasonOf, y, f.shards[y]), [], `index ${y}`);
    assert.deepEqual(checkSeasonRecords(y, f.shards[y], f.records.records), [], `records ${y}`);
  }
  assert.deepEqual(validateIndex(f.index, ctx), []);
  assert.deepEqual(validateRecords(f.records, ctx), []);
});

test('G-V01 shard envelope: class, review, verification, schema, source, league, season, coverage, keys', () => {
  const cases = [
    [(f) => { f.shards[2001].class = 'curated'; }, /class curated, expected source/],
    [(f) => { f.shards[2001].review_status = 'approved'; }, /review_status approved/],
    [(f) => { f.shards[2001].verification = 'certified'; }, /verification certified/],
    [(f) => { f.shards[2001].schema = 'other/1'; }, /schema other\/1/],
    [(f) => { f.shards[2001].source = 'elsewhere'; }, /source elsewhere/],
    [(f) => { f.shards[2001].league_code = 'AFL'; }, /league AFL is not the covered league/],
    [(f) => { f.shards[2001].season = 2002; }, /envelope season 2002, expected 2001/],
    [(f) => { f.manifest.coverage.games.to = 2000; }, /2001 is outside game coverage/],
    [(f) => { f.shards[2001].extra = 1; }, /envelope keys must be/],
    [(f) => { delete f.shards[2001].verification; }, /envelope keys must be/],
    [(f) => { f.shards[2001].records = {}; }, /records is not a list/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
});

test('G-V02 game ids, keys, duplicates, season, class and review status', () => {
  const g = (f) => f.shards[2001].records[0];
  const cases = [
    [(f) => { g(f).game_id = '2001_01_AAA_BBB'; }, /bad game id/],
    [(f) => { g(f).game_id = 'g_00000000000A'; }, /bad game id/],
    [(f) => { g(f).game_id = 'g_0000000001'; }, /bad game id/],
    [(f) => { f.shards[2001].records[1].game_id = g(f).game_id; }, /duplicate game id/],
    [(f) => { g(f).season = 2002; }, /season 2002, expected 2001/],
    [(f) => { g(f).class = 'derived'; }, /class derived, expected source/],
    [(f) => { g(f).review_status = 'certified'; }, /review_status certified/],
    [(f) => { g(f).verification = 'other'; }, /verification other/],
    [(f) => { g(f).league_code = 'AFL'; }, /league AFL/],
    [(f) => { g(f).spread = 1; }, /game keys must be/],
    [(f) => { delete g(f).overtime; }, /game keys must be/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
});

test('G-V03 types, weeks, dates and boolean fields', () => {
  const g = (f) => f.shards[2001].records[0];
  const cases = [
    [(f) => { g(f).game_type = 'PRE'; }, /unknown game type "PRE"/],
    [(f) => { g(f).week = 0; }, /week 0 is not a whole number/],
    [(f) => { g(f).week = '1'; }, /week "1" is not a whole number/],
    [(f) => { g(f).week = 1.5; }, /week 1.5 is not a whole number/],
    [(f) => { g(f).week = null; }, /week null is not a whole number/],
    [(f) => { g(f).game_date = '2001-9-09'; }, /not a YYYY-MM-DD calendar date/],
    [(f) => { g(f).game_date = '2001-02-30'; }, /not a YYYY-MM-DD calendar date/],
    [(f) => { g(f).game_date = '2001-09-09T00:00:00Z'; }, /not a YYYY-MM-DD calendar date/],
    [(f) => { g(f).game_date = '2002-03-01'; }, /outside the 2001 season/],
    [(f) => { g(f).game_date = '2000-12-31'; }, /outside the 2001 season/],
    [(f) => { g(f).neutral_site = 'false'; }, /neutral_site is not true\/false/],
    [(f) => { g(f).overtime = null; }, /overtime is not true\/false/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
  assert.equal(isCalendarDate('2000-02-29'), true);
  assert.equal(isCalendarDate('2004-02-29'), true);
  assert.equal(isCalendarDate('1900-02-29'), false);
  assert.equal(isCalendarDate('2001-13-01'), false);
  assert.equal(isCalendarDate(20010909), false);
});

test('G-V04 source reference: keys, source, key form, key agrees with season and week', () => {
  const g = (f) => f.shards[2001].records[0];
  const cases = [
    [(f) => { g(f).source_ref.extra = 1; }, /source_ref keys must be/],
    [(f) => { g(f).source_ref.source = 'other'; }, /source_ref.source other/],
    [(f) => { g(f).source_ref.key = '2001-01-AAA-BBB'; }, /unexpected form/],
    [(f) => { g(f).source_ref.key = '2001_02_AAA_BBB'; }, /disagrees with season 2001 week 1/],
    [(f) => { g(f).source_ref.key = '2000_01_AAA_BBB'; }, /disagrees with season 2001 week 1/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
});

test('G-V05 scores, franchises and identities (relationship and season coverage)', () => {
  const g = (f) => f.shards[2001].records[0];
  const cases = [
    [(f) => { g(f).home.score = -1; }, /score -1 is not a whole number/],
    [(f) => { g(f).home.score = 3.5; }, /score 3.5 is not a whole number/],
    [(f) => { g(f).home.score = '7'; }, /score "7" is not a whole number/],
    [(f) => { g(f).home.score = null; }, /score null is not a whole number/],
    [(f) => { g(f).home.extra = 1; }, /home: keys must be/],
    [(f) => { g(f).home.franchise_id = 'fr_zzz'; }, /unknown franchise fr_zzz/],
    [(f) => { g(f).home.identity_id = 'id_zzz_01'; }, /unknown identity id_zzz_01/],
    [(f) => { g(f).home.identity_id = 'id_ccc_01'; }, /belongs to fr_ccc, not fr_bbb/],
    [(f) => { g(f).away.identity_id = 'id_aaa_02'; }, /identity id_aaa_02 does not cover 2001/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
  expectProblem('shard2002', (f) => { f.shards[2002].records[0].away.identity_id = 'id_aaa_01'; }, /does not cover 2002/);
  expectProblem('shard2001', (f) => { const x = g(f); x.home = { ...x.away }; }, /cannot play itself/);
});

test('G-V06 postseason ties are refused; regular-season ties are allowed; order is enforced', () => {
  expectProblem('shard2001', (f) => { f.shards[2001].records[3].home.score = 7; }, /postseason game .* is tied/);
  const f = gameFixture();
  assert.equal(f.shards[2001].records[2].home.score, f.shards[2001].records[2].away.score, 'fixture has a regular-season tie');
  assert.deepEqual(validateShard(f.shards[2001], 2001, ctxOf(f)), []);
  expectProblem('shard2001', (x) => { x.shards[2001].records.reverse(); }, /not in \(date, round, source key\) order/);
  expectProblem('shard2002', (x) => { const r = x.shards[2002].records; [r[1], r[2]] = [r[2], r[1]]; }, /not in \(date, round, source key\) order/);
});

test('G-V07 index: envelope, rows without class, ids, duplicates, order, coverage', () => {
  const cases = [
    [(f) => { f.index.class = 'derived'; }, /class derived, expected source/],
    [(f) => { f.index.review_status = 'approved'; }, /review_status approved/],
    [(f) => { f.index.extra = 1; }, /envelope keys must be/],
    [(f) => { f.index.description = ''; }, /description missing/],
    [(f) => { f.index.records[0].class = 'source'; }, /row keys must be game_id, season/],
    [(f) => { f.index.records[0].game_id = 'G_1'; }, /bad game id/],
    [(f) => { f.index.records[1].game_id = f.index.records[0].game_id; }, /listed twice/],
    [(f) => { f.index.records.reverse(); }, /not sorted by game id/],
    [(f) => { f.index.records[0].season = 1999; }, /season 1999 is outside game coverage/],
  ];
  for (const [edit, re] of cases) expectProblem('index', edit, re);
});

test('G-V08 index to shard consistency', () => {
  expectProblem('pair2001', (f) => { f.index.records = f.index.records.filter((r) => r.game_id !== 'g_000000000002'); }, /g_000000000002 is missing from the index/);
  expectProblem('pair2001', (f) => { f.index.records[0].season = 2002; }, /index puts g_000000000001 in 2002, not 2001/);
  expectProblem('pair2001', (f) => { f.index.records.push({ game_id: 'g_00000000ffff', season: 2001 }); }, /listed for 2001 but is not in games\/2001\.json/);
});

test('G-V09 records file envelope and record fields', () => {
  const r = (f, i = 0) => f.records.records[i];
  const cases = [
    [(f) => { f.records.label = 'Calculated by Velora.'; }, /label must say "Not official league standings"/],
    [(f) => { f.records.formula = ' '; }, /formula missing/],
    [(f) => { f.records.class = 'source'; }, /class source, expected derived/],
    [(f) => { r(f).class = 'source'; }, /class source, expected derived/],
    [(f) => { r(f).verification = 'single_source_pinned'; }, /verification single_source_pinned, expected derived_from_source/],
    [(f) => { r(f).review_status = 'approved'; }, /review_status approved/],
    [(f) => { r(f).win_pct = 0.5; }, /record keys must be/],
    [(f) => { r(f).record_id = '2001-fr_bbb'; }, /record_id 2001-fr_bbb does not match/],
    [(f) => { f.records.records[1] = { ...r(f) }; }, /duplicate record 2001-fr_aaa/],
    [(f) => { f.records.records.reverse(); }, /not in \(season, franchise\) order/],
    [(f) => { r(f).season = 1998; r(f).record_id = '1998-fr_aaa'; }, /season 1998 is outside game coverage/],
    [(f) => { r(f).identity_id = 'id_aaa_02'; }, /does not name fr_aaa in 2001/],
    [(f) => { r(f).regular_season.wins = 2; }, /wins \+ losses \+ ties is not games/],
    [(f) => { r(f).regular_season.ties = -1; }, /regular_season must hold whole-number/],
    [(f) => { r(f).postseason.ties = 0; }, /postseason must hold/],
    [(f) => { r(f).postseason.rounds = ['WC']; }, /lists 1 rounds for 2 games/],
    [(f) => { r(f).postseason.rounds = ['WC', 'PRE']; }, /unknown round "PRE"/],
    [(f) => { r(f).postseason.rounds = ['SB', 'WC']; }, /not in WC, DIV, CON, SB order/],
    [(f) => { r(f).postseason.wins = 2; }, /postseason wins \+ losses is not games/],
    [(f) => { r(f).expected_regular_season_games = 16; }, /differs from the season's 2/],
  ];
  for (const [edit, re] of cases) expectProblem('records', edit, re);
});

test('G-V10 record status and notes (the BUF/CIN 2022 pattern)', () => {
  const r = (f, i) => f.records.records[i];
  const cases = [
    [(f) => { r(f, 0).status = 'withheld'; }, /status "withheld" is not in the verified schema/],
    [(f) => { r(f, 0).withheld_reason = 'x'; }, /withheld_reason must be null/],
    [(f) => { r(f, 0).note_ref = { field: 'schedule_note', id: 'E', season_id: 'NFL-2001' }; }, /complete record carries a note_ref/],
    [(f) => { r(f, 5).status = 'complete'; r(f, 5).note_ref = null; }, /complete record has 1 regular-season games, expected 2/],
    [(f) => { r(f, 0).status = 'complete_with_note'; r(f, 0).note_ref = { field: 'schedule_note', id: 'E', season_id: 'NFL-2001' }; }, /complete_with_note record has the expected number of games/],
    [(f) => { r(f, 5).note_ref = null; }, /note_ref keys must be/],
    [(f) => { r(f, 5).note_ref.season_id = 'NFL-2001'; }, /note_ref points at NFL-2001, not NFL-2002/],
    [(f) => { r(f, 5).note_ref.field = 'evidence'; }, /note_ref field evidence, expected schedule_note/],
    [(f) => { r(f, 5).note_ref.id = ''; }, /note_ref id missing/],
    [(f) => { f.seasons[3].schedule_note = ''; }, /note_ref does not resolve to a season note/],
  ];
  for (const [edit, re] of cases) expectProblem('records', edit, re);
  assert.deepEqual([...RECORD_STATUSES], ['complete', 'complete_with_note']);
});

test('G-V11 records recomputed from games (D-F22d-9)', () => {
  const f = gameFixture();
  const calc = recomputeSeason(f.shards[2001].records);
  assert.deepEqual(calc.get('fr_aaa'), { identity_ids: ['id_aaa_01'], regular_season: { games: 2, wins: 1, losses: 0, ties: 1 }, postseason: { games: 2, wins: 1, losses: 1, rounds: ['WC', 'SB'] } });
  assert.deepEqual(calc.get('fr_bbb').postseason, { games: 1, wins: 1, losses: 0, rounds: ['SB'] });
  assert.equal(calc.size, 3);
  const cases = [
    [2001, (x) => { x.records.records[0].regular_season.wins = 0; x.records.records[0].regular_season.losses = 1; }, /regular season wins 0, games give 1/],
    [2001, (x) => { x.records.records[0].postseason.rounds = ['SB', 'WC']; }, /rounds SB,WC, games give WC,SB/],
    [2001, (x) => { x.shards[2001].records[0].home.score = 25; }, /regular season wins/],
    [2002, (x) => { x.records.records[3].identity_id = 'id_aaa_01'; }, /identity id_aaa_01, games use id_aaa_02/],
    [2002, (x) => { x.records.records.splice(6, 1); }, /fr_ddd played in 2002 but has no record/],
    [2002, (x) => { x.shards[2002].records = x.shards[2002].records.filter((g) => g.away.franchise_id !== 'fr_ddd'); }, /2002-fr_ddd has no games/],
  ];
  for (const [y, edit, re] of cases) expectProblem(`recompute${y}`, edit, re);
});

test('G-V12 coverage states (D-A1-7)', () => {
  const ctx = ctxOf(gameFixture());
  assert.equal(coverageState('NFL', 2001, ctx), 'covered');
  assert.equal(coverageState('NFL', 2002, ctx), 'covered');
  assert.equal(coverageState('NFL', 2000, ctx), 'outside');
  assert.equal(coverageState('AFL', 1965, ctx), 'outside');
  assert.equal(coverageState('NFL', 2003, ctx), 'not_completed');
  assert.equal(coverageState('NFL', 1800, ctx), 'unknown');
  assert.equal(coverageState('XFL', 2001, ctx), 'unknown');
  const none = makeGameContext({ manifest: { schema: 's' }, franchises: [], identities: [], seasons: gameFixture().seasons });
  assert.equal(coverageState('NFL', 2001, none), 'outside', 'no game coverage in the manifest means nothing is covered');
});

test('G-V13 lookups and filters', () => {
  const f = gameFixture();
  const seasonOf = indexLookup(f.index);
  assert.equal(seasonOf.size, 9);
  assert.equal(seasonOf.get('g_000000000009'), 2002);
  const byId = shardLookup(f.shards[2001]);
  assert.equal(byId.get('g_000000000003'), f.shards[2001].records[2], 'shard lookup returns the stored objects, not copies');
  const { bySeason, byFranchise } = recordLookups(f.records);
  assert.deepEqual(bySeason.get(2002).map((r) => r.franchise_id), ['fr_aaa', 'fr_bbb', 'fr_ccc', 'fr_ddd']);
  assert.deepEqual(byFranchise.get('fr_aaa').map((r) => [r.season, r.identity_id]), [[2001, 'id_aaa_01'], [2002, 'id_aaa_02']], 'season-by-season, with the name used that season (D-A1-6)');
  assert.deepEqual(validateFilters({}), []);
  assert.deepEqual(validateFilters({ week: 2, type: 'REG' }), []);
  assert.match(validateFilters({ week: 0 })[0], /week 0/);
  assert.match(validateFilters({ type: 'POST' })[0], /unknown game type/);
  assert.match(validateFilters({ team: 'x' })[0], /unknown filter team/);
  assert.match(validateFilters(null)[0], /filters must be an object/);
  const games = f.shards[2001].records;
  assert.deepEqual(filterGames(games, { type: 'REG' }).map((g) => g.week), [1, 2, 3]);
  assert.deepEqual(filterGames(games, { week: 7 }).map((g) => g.game_type), ['SB']);
  assert.deepEqual(filterGames(games, { week: 4, type: 'WC' }).length, 1);
  assert.deepEqual(filterGames(games, { type: 'CON' }), []);
  assert.notEqual(filterGames(games), games, 'filterGames returns a new array');
  assert.equal(isGameId('g_4bf81cf6cdc9'), true);
  assert.equal(isGameId('1999_01_ARI_PHI'), false);
  assert.deepEqual([...GAME_TYPES], ['REG', 'WC', 'DIV', 'CON', 'SB']);
  assert.deepEqual([...POSTSEASON_TYPES], ['WC', 'DIV', 'CON', 'SB']);
});

test('G-V14 non-object inputs are reported, never thrown', () => {
  const ctx = ctxOf(gameFixture());
  for (const bad of [null, undefined, 7, 'x', [], [{}]]) {
    assert.ok(validateShard(bad, 2001, ctx).length > 0);
    assert.ok(validateIndex(bad, ctx).length > 0);
    assert.ok(validateRecords(bad, ctx).length > 0);
  }
  const f = gameFixture();
  f.shards[2001].records[0] = null;
  f.index.records[0] = 'x';
  f.records.records[0] = 5;
  assert.ok(validateShard(f.shards[2001], 2001, ctx).some((p) => /game keys must be/.test(p)));
  assert.ok(validateIndex(f.index, ctx).some((p) => /row keys must be/.test(p)));
  assert.ok(validateRecords(f.records, ctx).some((p) => /record keys must be/.test(p)));
});

test('G25 (pure part) validators keep no hidden state: a failed call does not affect a later call', () => {
  const ctx = ctxOf(gameFixture());
  const bad = gameFixture();
  bad.shards[2001].records[0].home.score = -1;
  assert.ok(validateShard(bad.shards[2001], 2001, ctx).length > 0, 'first call fails');
  const good = gameFixture();
  assert.deepEqual(validateShard(good.shards[2001], 2001, ctx), [], 'corrected bytes validate cleanly afterwards');
  assert.deepEqual(checkSeasonRecords(2001, good.shards[2001], good.records.records), []);
});

test('G-V15 (I-4) impossible weeks are refused even when the source key agrees', () => {
  // A game whose week and source key are changed together still fails when the week is
  // impossible for its type in that season (G = regular_season_games = 2 in the fixture).
  const setWeek = (g, w) => { g.week = w; g.source_ref.key = g.source_ref.key.replace(/_\d{2}_/, `_${String(w).padStart(2, '0')}_`); };
  const cases = [
    [(f) => setWeek(f.shards[2001].records[0], 19), /week 19 is impossible for REG in a 2-game season \(allowed 1–3\)/],
    [(f) => setWeek(f.shards[2001].records[2], 4), /week 4 is impossible for REG/],
    [(f) => setWeek(f.shards[2001].records[3], 5), /week 5 is impossible for WC in a 2-game season \(allowed 4\)/],
    [(f) => setWeek(f.shards[2001].records[4], 8), /week 8 is impossible for SB in a 2-game season \(allowed 7\)/],
    [(f) => setWeek(f.shards[2001].records[4], 6), /week 6 is impossible for SB/],
    [(f) => { f.seasons = f.seasons.filter((x) => x.season_id !== 'NFL-2001'); }, /no regular_season_games for NFL-2001/],
    [(f) => { f.seasons.find((x) => x.season_id === 'NFL-2001').regular_season_games = null; }, /no regular_season_games for NFL-2001/],
  ];
  for (const [edit, re] of cases) expectProblem('shard2001', edit, re);
  // Derived ranges for the two real conventions (16- and 17-game seasons), per S3 evidence.
  assert.deepEqual(weekRange('REG', 16), [1, 17]);
  assert.deepEqual(['WC', 'DIV', 'CON', 'SB'].map((t) => weekRange(t, 16)[0]), [18, 19, 20, 21]);
  assert.deepEqual(weekRange('REG', 17), [1, 18]);
  assert.deepEqual(['WC', 'DIV', 'CON', 'SB'].map((t) => weekRange(t, 17)[0]), [19, 20, 21, 22]);
  assert.equal(weekRange('PRE', 16), null);
  assert.equal(weekRange('REG', 0), null);
  assert.equal(weekRange('REG', '16'), null);
});
