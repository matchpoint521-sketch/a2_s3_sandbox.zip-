// F2.2d-A1 S2: games.js against the real installed snapshot (read-only). Skips when the
// served snapshot is absent or has no game files (F1.5).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { FRONTEND } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { kindOf } from './helpers/snapshot-rules.mjs';
import * as games from '../src/core/games.js';

const dir = path.join(FRONTEND, 'data/snapshot');
const SKIP = SNAPSHOT_BUILT && kindOf(dir) === 'f2' ? false : 'SKIP: no game snapshot in data/snapshot';
const read = (rel) => JSON.parse(readFileSync(path.join(dir, rel), 'utf8'));

function load() {
  const manifest = read('manifest.json');
  const curated = Object.fromEntries(['franchises', 'identities', 'seasons'].map((n) => [n, read(`${n}.json`).records]));
  const ctx = games.makeGameContext({ manifest, ...curated });
  return { manifest, ctx, index: read('games/index.json'), records: read('team_season_records.json') };
}

test('R-S2a every real shard, the index and the records file validate with no problems', { skip: SKIP }, () => {
  const { manifest, ctx, index, records } = load();
  assert.equal(manifest.build_id, '5913437cb58123df413f4738967cdd9a57ee51d4fe4331856c1b371863101876');
  assert.deepEqual(games.validateIndex(index, ctx), []);
  assert.deepEqual(games.validateRecords(records, ctx), []);
  const seasonOf = games.indexLookup(index);
  const types = {};
  let total = 0;
  for (let y = ctx.coverage.from; y <= ctx.coverage.to; y += 1) {
    const shard = read(`games/${y}.json`);
    assert.deepEqual(games.validateShard(shard, y, ctx), [], `games/${y}.json`);
    assert.deepEqual(games.checkIndexForSeason(seasonOf, y, shard), [], `index ${y}`);
    assert.deepEqual(games.checkSeasonRecords(y, shard, records.records), [], `records ${y}`);
    for (const g of shard.records) types[g.game_type] = (types[g.game_type] ?? 0) + 1;
    total += shard.records.length;
  }
  assert.equal(total, 7276);
  assert.deepEqual(types, { REG: 6967, WC: 120, DIV: 108, CON: 54, SB: 27 });
  assert.equal(records.records.length, 861);
});

test('R-S2b real notes, relocations and coverage states', { skip: SKIP }, () => {
  const { ctx, records } = load();
  const noted = records.records.filter((r) => r.status === 'complete_with_note').map((r) => r.record_id);
  assert.deepEqual(noted, ['2022-fr_buf', '2022-fr_cin']);
  const { byFranchise } = games.recordLookups(records);
  const rams = byFranchise.get('fr_lar');
  assert.equal(rams.find((r) => r.season === 2015).identity_id, 'id_lar_03');
  assert.equal(rams.find((r) => r.season === 2016).identity_id, 'id_lar_04');
  assert.equal(byFranchise.get('fr_hou')[0].season, 2002);
  const states = [['NFL', 2025], ['NFL', 1999], ['NFL', 1998], ['AFL', 1965], ['NFL', 1943], ['NFL', 1945], ['NFL', 2026], ['NFL', 1919]]
    .map(([l, y]) => games.coverageState(l, y, ctx));
  assert.deepEqual(states, ['covered', 'covered', 'outside', 'outside', 'outside', 'outside', 'not_completed', 'unknown']);
});
