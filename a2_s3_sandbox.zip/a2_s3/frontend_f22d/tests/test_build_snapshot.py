"""Tests for tools/build_snapshot.py. Standard library only.

The seed CSVs are located through $VELORA_SEED_SOURCE (a folder containing them or a
seed/ subfolder). Tests that need them are skipped, with an explicit message, if absent.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

FRONTEND = Path(__file__).resolve().parent.parent
BUILDER = FRONTEND / "tools" / "build_snapshot.py"
PINS = json.loads((FRONTEND / "tools" / "snapshot_inputs.json").read_text("utf-8"))
SOURCE = os.environ.get("VELORA_SEED_SOURCE")
SKIP_MSG = "SKIP: set VELORA_SEED_SOURCE to the folder holding the seed CSVs"

sys.path.insert(0, str(FRONTEND / "tools"))
import build_snapshot as B  # noqa: E402


def run(*args):
    return subprocess.run([sys.executable, str(BUILDER), *args], capture_output=True, text=True)


def tree_hashes(folder):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(folder).glob("*"))}


def source_files():
    src = Path(SOURCE)
    return {n: (B.locate(src, n)) for n in PINS["files"]}


@unittest.skipUnless(SOURCE, SKIP_MSG)
class BuildTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="velora-snap-"))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_build_counts_and_classes(self):
        out = self.tmp / "snap"
        r = run("--source", SOURCE, "--out", str(out))
        self.assertEqual(r.returncode, 0, r.stderr)
        m = json.loads((out / "manifest.json").read_text())
        self.assertEqual(m["counts"], {"leagues": 2, "seasons": 117, "franchises": 80, "franchises_active": 32,
                                       "franchises_defunct": 48, "identities": 118, "merged_seasons": 3})
        self.assertEqual(m["coverage"]["seasons"], {"from": 1920, "to": 2026})
        for name in m["outputs"]:
            body = json.loads((out / name).read_text())
            self.assertEqual(body["class"], "curated")
            self.assertTrue(all(r["review_status"] == "pending_review" and r["class"] == "curated" for r in body["records"]))

    def test_deterministic(self):
        a, b = self.tmp / "a", self.tmp / "b"
        self.assertEqual(run("--source", SOURCE, "--out", str(a)).returncode, 0)
        self.assertEqual(run("--source", SOURCE, "--out", str(b)).returncode, 0)
        self.assertEqual(tree_hashes(a), tree_hashes(b))

    def test_rebuild_replaces_atomically(self):
        out = self.tmp / "snap"
        run("--source", SOURCE, "--out", str(out))
        (out / "stray.json").write_text("{}")
        self.assertEqual(run("--source", SOURCE, "--out", str(out)).returncode, 0)
        self.assertNotIn("stray.json", tree_hashes(out))
        self.assertEqual([p.name for p in self.tmp.iterdir() if p.name.startswith(".")], [])

    def test_inputs_are_not_modified(self):
        before = {n: hashlib.sha256(p.read_bytes()).hexdigest() for n, p in source_files().items()}
        self.assertEqual(run("--source", SOURCE, "--out", str(self.tmp / "s")).returncode, 0)
        after = {n: hashlib.sha256(p.read_bytes()).hexdigest() for n, p in source_files().items()}
        self.assertEqual(before, after)
        self.assertEqual(before, PINS["files"])

    def test_hash_mismatch_refused_and_nothing_written(self):
        copy = self.tmp / "src"
        copy.mkdir()
        for n, p in source_files().items():
            shutil.copy(p, copy / n)
        with open(copy / "franchise_seed.csv", "ab") as fh:
            fh.write(b"\n")
        out = self.tmp / "snap"
        r = run("--source", str(copy), "--out", str(out))
        self.assertEqual(r.returncode, 2)
        self.assertIn("hash mismatch: franchise_seed.csv", r.stderr)
        self.assertFalse(out.exists())

    def test_missing_input_refused(self):
        copy = self.tmp / "src"
        copy.mkdir()
        for n, p in source_files().items():
            if n != "season_seed.csv":
                shutil.copy(p, copy / n)
        r = run("--source", str(copy), "--out", str(self.tmp / "snap"))
        self.assertEqual(r.returncode, 2)
        self.assertIn("missing input: season_seed.csv", r.stderr)

    def test_existing_snapshot_untouched_on_refusal(self):
        out = self.tmp / "snap"
        run("--source", SOURCE, "--out", str(out))
        before = tree_hashes(out)
        r = run("--source", str(self.tmp / "nowhere"), "--out", str(out))
        self.assertEqual(r.returncode, 2)
        self.assertEqual(tree_hashes(out), before)

    def test_check_writes_nothing(self):
        out = self.tmp / "snap"
        r = run("--source", SOURCE, "--out", str(out), "--check")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("CHECK OK", r.stdout)
        self.assertFalse(out.exists())

    def test_no_restricted_fields_in_output(self):
        out = self.tmp / "snap"
        run("--source", SOURCE, "--out", str(out))
        text = "".join(p.read_text() for p in out.glob("*.json"))
        for word in ("code_538", "moneyline", "spread", "odds", "total_line", "gsis", "espn", "pfr"):
            self.assertNotIn(f'"{word}', text)


class UnitTests(unittest.TestCase):
    """Rules that do not need the real seed files."""

    def test_research_output_refused(self):
        r = run("--source", "/nonexistent", "--out", "/tmp/x/research/M2.5/snap")
        self.assertEqual(r.returncode, 4)

    def test_frontend_root_refused(self):
        r = run("--source", "/nonexistent", "--out", str(FRONTEND))
        self.assertEqual(r.returncode, 4)

    def test_review_status_must_stay_pending(self):
        with self.assertRaises(B.Refused) as ctx:
            B.pending({"review_status": "approved"}, "row")
        self.assertEqual(ctx.exception.code, 3)

    def test_forbidden_key_detected(self):
        with self.assertRaises(B.Refused):
            B.check_keys({"records": [{"home_moneyline": 1}]})

    def test_overlapping_identities_refused(self):
        f = [{"franchise_id": "fr_x", "status": "active"}]
        ids = [{"identity_id": "a", "franchise_id": "fr_x", "first_season": 1950, "last_season": 1960},
               {"identity_id": "b", "franchise_id": "fr_x", "first_season": 1960, "last_season": None}]
        with self.assertRaises(B.Refused):
            B.check_integrity(f, ids, [])

    def test_pins_cover_six_files_of_five_datasets(self):
        self.assertEqual(len(PINS["files"]), 6)
        self.assertEqual(set(PINS["files"]), set(PINS["expected_rows"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
