// Node equivalent of the browser loader, rooted at a folder (the frontend by default).
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { DataLoadError, FileMissingError } from '../../src/core/errors.js';

export const FRONTEND = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

export function nodeLoader(root = FRONTEND, log = []) {
  return {
    async json(rel) {
      log.push(rel);
      let text;
      try { text = await readFile(path.join(root, rel), 'utf8'); }
      catch (e) { if (e.code === 'ENOENT') throw new FileMissingError(rel); throw new DataLoadError(rel, e.message); }
      try { return JSON.parse(text); } catch { throw new DataLoadError(rel, 'invalid JSON'); }
    },
  };
}
