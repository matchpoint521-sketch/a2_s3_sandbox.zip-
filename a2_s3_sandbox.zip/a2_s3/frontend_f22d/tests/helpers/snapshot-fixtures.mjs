// F2.2a test-only fixtures: tiny synthetic Version B snapshots written to temporary
// folders. They are shaped like the F1 and F2.2 layouts but carry no real records:
// ids and names are obviously synthetic. Nothing is written inside the frontend.
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { CAPABILITY_KEYS } from '../../src/core/capabilities.js';
import { buildIdOf, gamePins, pins, sha256, SCHEMA, PENDING, F1_FILES } from './snapshot-rules.mjs';

const dumps = (o) => `${JSON.stringify(o, null, 1)}\n`;
const curated = (records) => ({ schema: SCHEMA, class: 'curated', review_status: PENDING, records });
const rec = (o) => ({ ...o, class: 'curated', review_status: PENDING });

function game(id, season) {
  return {
    game_id: id, season, league_code: 'NFL', game_type: 'REG', week: 1, game_date: `${season}-09-10`,
    home: { franchise_id: 'fr_tsta', identity_id: 'id_tsta_01', score: 10 },
    away: { franchise_id: 'fr_tstb', identity_id: 'id_tstb_01', score: 3 },
    neutral_site: false, overtime: false, source_ref: { source: 'nflverse_games', key: 'fixture' },
    class: 'source', verification: 'single_source_pinned', review_status: PENDING,
  };
}

export function writeFixture({ games = false } = {}) {
  const dir = mkdtempSync(path.join(tmpdir(), `velora-f22a-${games ? 'f2' : 'f1'}-`));
  const files = {
    'leagues.json': curated([rec({ league_code: 'NFL', name: 'Fixture league' })]),
    'seasons.json': curated([rec({ season_id: 'NFL-2001', league_code: 'NFL', year: 2001 }), rec({ season_id: 'NFL-2002', league_code: 'NFL', year: 2002 })]),
    'franchises.json': curated([rec({ franchise_id: 'fr_tsta', display_name: 'Fixture A' }), rec({ franchise_id: 'fr_tstb', display_name: 'Fixture B' })]),
    'identities.json': curated([rec({ identity_id: 'id_tsta_01', franchise_id: 'fr_tsta' }), rec({ identity_id: 'id_tstb_01', franchise_id: 'fr_tstb' })]),
    'merged_seasons.json': curated([]),
  };
  const p = pins();
  const inputs = Object.fromEntries(Object.entries(p.files).map(([n, h]) => [n, { sha256: h, rows: p.expected_rows[n] }]));
  const manifest = {
    schema: SCHEMA, provider: 'snapshot', builder: { name: 'fixture' },
    capabilities: Object.fromEntries(CAPABILITY_KEYS.map((k) => [k, ['franchises', 'seasons', 'search'].includes(k)])),
    classes: ['curated'], coverage: { seasons: { from: 2001, to: 2002 } }, counts: { franchises: 2 }, inputs,
  };
  if (games) {
    const gp = gamePins();
    files['games/2001.json'] = { schema: SCHEMA, class: 'source', review_status: PENDING, season: 2001, league_code: 'NFL', source: 'nflverse_games', verification: 'single_source_pinned', records: [game('g_000000000001', 2001)] };
    files['games/2002.json'] = { schema: SCHEMA, class: 'source', review_status: PENDING, season: 2002, league_code: 'NFL', source: 'nflverse_games', verification: 'single_source_pinned', records: [game('g_000000000002', 2002)] };
    files['games/index.json'] = { schema: SCHEMA, class: 'source', review_status: PENDING, description: 'fixture', records: [{ game_id: 'g_000000000001', season: 2001 }, { game_id: 'g_000000000002', season: 2002 }] };
    files['team_season_records.json'] = {
      schema: SCHEMA, class: 'derived', review_status: PENDING, label: 'Fixture records. Not official league standings.', formula: 'Fixture formula.',
      records: [{ record_id: '2001-fr_tsta', season: 2001, franchise_id: 'fr_tsta', class: 'derived', verification: 'derived_from_source', review_status: PENDING }],
    };
    manifest.capabilities.games = true;
    manifest.classes = ['curated', 'derived', 'source'];
    manifest.coverage.games = { league: 'NFL', from: 2001, to: 2002, note: 'fixture' };
    manifest.counts.games = 2;
    manifest.counts.team_season_records = 1;
    manifest.inputs[gp.file.name] = { sha256: gp.file.sha256, rows: gp.file.rows, slice_digest: gp.slice.digest, slice_rows: gp.slice.rows };
  }
  for (const [name, body] of Object.entries(files)) writeFile(dir, name, body);
  manifest.outputs = {};
  writeFile(dir, 'manifest.json', manifest);
  rehash(dir, Object.keys(files));
  return dir;
}

export function writeFile(dir, rel, body) {
  const p = path.join(dir, ...rel.split('/'));
  mkdirSync(path.dirname(p), { recursive: true });
  writeFileSync(p, typeof body === 'string' ? body : dumps(body));
}

export const readFixture = (dir, rel) => JSON.parse(readFileSync(path.join(dir, ...rel.split('/')), 'utf8'));

export function editJson(dir, rel, fn) {
  const body = readFixture(dir, rel);
  fn(body);
  writeFile(dir, rel, body);
}

// Re-lists the given files (default: those already listed) with their current hashes and
// record counts, and recomputes build_id: a mutation then trips only the rule under test.
export function rehash(dir, names) {
  const m = readFixture(dir, 'manifest.json');
  const list = names ?? Object.keys(m.outputs);
  m.outputs = {};
  for (const n of list) {
    const buf = readFileSync(path.join(dir, ...n.split('/')));
    let records = 0;
    try { records = JSON.parse(buf).records?.length ?? 0; } catch { /* invalid JSON stays invalid */ }
    m.outputs[n] = { sha256: sha256(buf), records };
  }
  m.build_id = buildIdOf(m.outputs);
  writeFile(dir, 'manifest.json', m);
}

export const editManifest = (dir, fn) => { editJson(dir, 'manifest.json', fn); };
export { F1_FILES };
