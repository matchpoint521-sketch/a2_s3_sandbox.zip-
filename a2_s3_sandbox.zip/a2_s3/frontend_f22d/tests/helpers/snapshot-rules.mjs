// F2.2a test-only helper: validates a Version B snapshot folder against its manifest.
// Used by snapshot.test.mjs and labeling.test.mjs on the real snapshot, and by
// snapshot_rules.test.mjs on small temporary fixtures. Production code never imports it.
//
// It accepts exactly two served layouts:
//   F1   - the five curated files only; games off (F1.5 build, build_id 50dfae25…).
//   F2.2 - the five curated files + games/<year>.json shards + games/index.json
//          + team_season_records.json; games on (future install build, D-F22-1…5).
// Any other path is unknown and fails, so a new kind of file cannot be added to the
// served snapshot without a deliberate change to the RULES table below.
// Audit files are never allowed in the served snapshot (D-F22-2).
import { createHash } from 'node:crypto';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { FRONTEND } from './node-loader.mjs';
import { CAPABILITY_KEYS } from '../../src/core/capabilities.js';

export const SCHEMA = 'velora-nfl-frontend/1';
export const PENDING = 'pending_review';
export const F1_FILES = Object.freeze(['franchises.json', 'identities.json', 'leagues.json', 'merged_seasons.json', 'seasons.json']);
export const NOT_OFFICIAL = 'Not official league standings';
// Ignored on disk only: macOS Finder metadata. Every other file, hidden or not, must be listed.
export const IGNORED_ON_DISK = Object.freeze(['.DS_Store']);

// Path → expected class. Order matters only for readability; patterns do not overlap.
export const RULES = Object.freeze([
  { kind: 'curated', re: /^(leagues|seasons|franchises|identities|merged_seasons)\.json$/, cls: 'curated' },
  { kind: 'shard', re: /^games\/(\d{4})\.json$/, cls: 'source' },
  { kind: 'index', re: /^games\/index\.json$/, cls: 'source' },
  { kind: 'records', re: /^team_season_records\.json$/, cls: 'derived' },
]);
const SAFE_KEY = /^[a-z0-9_]+(?:\/[a-z0-9_]+)*\.json$/;
const AUDIT = /(^|\/)audit(\/|$)|dispositions|mapping_report/;
// Capabilities that must stay off in every F2.2-era snapshot, and those always on.
const ALWAYS_OFF = ['headToHead', 'players', 'playerStats', 'statCoverage', 'compare'];
const ALWAYS_ON = ['franchises', 'seasons', 'search'];
// Version A id prefixes that must never appear as a value in Version B data (T-60).
const DEMO_ID = /^(dm|di|dg|dp|dmrg)_/;

export const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
export const buildIdOf = (outputs) => sha256(Object.entries(outputs)
  .sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}:${v.sha256}\n`).join(''));

const readJson = (p) => JSON.parse(readFileSync(p, 'utf8'));
export const pins = () => readJson(path.join(FRONTEND, 'tools/snapshot_inputs.json'));
export const gamePins = () => readJson(path.join(FRONTEND, 'tools/f2_games_inputs.json'));

// Every file below dir as a POSIX relative path, hidden files included.
export function listAll(dir) {
  const out = [];
  const visit = (d) => {
    for (const name of readdirSync(d)) {
      const p = path.join(d, name);
      if (statSync(p).isDirectory()) visit(p);
      else if (!IGNORED_ON_DISK.includes(name)) out.push(path.relative(dir, p).split(path.sep).join('/'));
    }
  };
  visit(dir);
  return out.sort();
}

export const ruleFor = (rel) => RULES.find((r) => r.re.test(rel)) ?? null;

function stringValues(o, out = []) {
  if (Array.isArray(o)) o.forEach((x) => stringValues(x, out));
  else if (o && typeof o === 'object') Object.values(o).forEach((x) => stringValues(x, out));
  else if (typeof o === 'string') out.push(o);
  return out;
}

// Returns a list of {cat, msg}. An empty list means the snapshot is valid.
// Categories: files, hash, build, inputs, capabilities, classes, labels, games, isolation.
export function inspectSnapshot(dir) {
  const problems = [];
  const bad = (cat, msg) => problems.push({ cat, msg });
  const mPath = path.join(dir, 'manifest.json');
  if (!existsSync(mPath)) { bad('files', 'manifest.json is missing'); return problems; }
  let m;
  try { m = readJson(mPath); } catch (e) { bad('files', `manifest.json is not valid JSON: ${e.message}`); return problems; }
  if (m.schema !== SCHEMA) bad('files', `manifest schema ${m.schema}`);
  if (m.provider !== 'snapshot') bad('files', `manifest provider ${m.provider}`);
  const outputs = m.outputs && typeof m.outputs === 'object' ? m.outputs : {};
  if (!m.outputs) bad('files', 'manifest has no outputs');

  // 1. File set: exact equality between files on disk and manifest outputs (relative paths).
  const onDisk = listAll(dir).filter((f) => f !== 'manifest.json');
  const listed = Object.keys(outputs).sort();
  for (const f of onDisk) {
    if (AUDIT.test(f)) bad('files', `audit file inside the served snapshot: ${f}`);
    if (!listed.includes(f)) bad('files', `extra file not in manifest outputs: ${f}`);
  }
  for (const k of listed) {
    if (!SAFE_KEY.test(k) || k === 'manifest.json') bad('files', `unsafe or reserved output key: ${k}`);
    if (AUDIT.test(k)) bad('files', `audit file listed in manifest outputs: ${k}`);
    if (!ruleFor(k)) bad('files', `unknown output path (no rule): ${k}`);
    if (!onDisk.includes(k)) bad('files', `missing file listed in outputs: ${k}`);
  }
  for (const f of F1_FILES) if (!listed.includes(f)) bad('files', `required curated file not listed: ${f}`);

  // 2. Hashes, record counts, build id.
  const bodies = new Map();
  for (const k of listed) {
    const p = path.join(dir, ...k.split('/'));
    if (!SAFE_KEY.test(k) || !existsSync(p)) continue;
    const buf = readFileSync(p);
    if (sha256(buf) !== outputs[k].sha256) bad('hash', `sha256 mismatch: ${k}`);
    let body;
    try { body = JSON.parse(buf.toString('utf8')); } catch { bad('hash', `invalid JSON: ${k}`); continue; }
    bodies.set(k, body);
    if (!Array.isArray(body.records)) bad('labels', `${k} has no records array`);
    else if (body.records.length !== outputs[k].records) bad('hash', `${k} has ${body.records.length} records, manifest says ${outputs[k].records}`);
  }
  if (m.build_id !== buildIdOf(outputs)) bad('build', 'build_id does not match the outputs');

  // 3. Build kind.
  const shards = listed.map((k) => [k, k.match(/^games\/(\d{4})\.json$/)]).filter(([, x]) => x).map(([k, x]) => ({ k, year: Number(x[1]) }));
  const gameFiles = listed.filter((k) => ['shard', 'index', 'records'].includes(ruleFor(k)?.kind));
  const hasGames = gameFiles.length > 0;
  if (hasGames) {
    for (const need of ['games/index.json', 'team_season_records.json']) if (!listed.includes(need)) bad('games', `game build without ${need}`);
    if (!shards.length) bad('games', 'game build without any season shard');
  }

  // 4. Inputs: seeds must equal the F1 pins; the games CSV is allowed only in a game build.
  const p = pins();
  const inputs = m.inputs && typeof m.inputs === 'object' ? m.inputs : {};
  for (const [name, hash] of Object.entries(p.files)) {
    if (!inputs[name]) bad('inputs', `seed input missing: ${name}`);
    else {
      if (inputs[name].sha256 !== hash) bad('inputs', `seed pin differs: ${name}`);
      if (inputs[name].rows !== p.expected_rows[name]) bad('inputs', `seed rows differ: ${name}`);
    }
  }
  const gp = gamePins();
  for (const [name, info] of Object.entries(inputs)) {
    if (p.files[name]) continue;
    if (name !== gp.file.name) { bad('inputs', `unpinned input: ${name}`); continue; }
    if (!hasGames) bad('inputs', `games input in a build without game files: ${name}`);
    if (info.sha256 !== gp.file.sha256 || info.slice_digest !== gp.slice.digest || info.slice_rows !== gp.slice.rows) bad('inputs', `games input differs from the F2.1 pin: ${name}`);
  }
  if (hasGames && !inputs[gp.file.name]) bad('inputs', 'game build without the pinned games input');

  // 5. Capabilities.
  const caps = m.capabilities ?? {};
  const capKeys = Object.keys(caps).sort();
  if (JSON.stringify(capKeys) !== JSON.stringify([...CAPABILITY_KEYS].sort())) bad('capabilities', `capability keys ${capKeys.join(',')}`);
  for (const k of capKeys) if (typeof caps[k] !== 'boolean') bad('capabilities', `${k} is not boolean`);
  for (const k of ALWAYS_OFF) if (caps[k] !== false) bad('capabilities', `${k} must be false`);
  for (const k of ALWAYS_ON) if (caps[k] !== true) bad('capabilities', `${k} must be true`);
  if (caps.games !== hasGames) bad('capabilities', `games is ${caps.games} but game files are ${hasGames ? 'present' : 'absent'}`);

  // 6. Classes: manifest.classes is exactly the sorted set of classes present.
  const present = [...new Set(listed.map((k) => ruleFor(k)?.cls).filter(Boolean))].sort();
  const declared = Array.isArray(m.classes) ? m.classes : [];
  if (JSON.stringify(declared) !== JSON.stringify(present)) bad('classes', `manifest classes [${declared}] but files carry [${present}]`);

  // 7. Labels: file class, record class, pending_review everywhere.
  for (const [k, body] of bodies) {
    const rule = ruleFor(k);
    if (!rule) continue;
    if (body.schema !== SCHEMA) bad('labels', `${k} schema ${body.schema}`);
    if (body.class !== rule.cls) bad('labels', `${k} class ${body.class}, expected ${rule.cls}`);
    if (body.review_status !== PENDING) bad('labels', `${k} review_status ${body.review_status}`);
    for (const [i, r] of (body.records ?? []).entries()) {
      if (rule.kind === 'index') {
        if (Object.keys(r).sort().join(',') !== 'game_id,season') bad('labels', `${k}[${i}] has keys ${Object.keys(r)}`);
        continue;
      }
      if (r.class !== rule.cls) bad('labels', `${k}[${i}] class ${r.class}, expected ${rule.cls}`);
      if (r.review_status !== PENDING) bad('labels', `${k}[${i}] review_status ${r.review_status}`);
      if (r.identity && r.identity.review_status !== PENDING) bad('labels', `${k}[${i}].identity review_status`);
    }
  }

  // 8. Game-file integrity (only when present).
  if (hasGames) {
    const cov = m.coverage?.games;
    if (!cov || !Number.isInteger(cov.from) || !Number.isInteger(cov.to) || cov.from > cov.to || cov.league !== 'NFL') bad('games', 'coverage.games missing or malformed');
    else {
      const want = [];
      for (let y = cov.from; y <= cov.to; y += 1) want.push(y);
      if (JSON.stringify(shards.map((s) => s.year).sort((a, b) => a - b)) !== JSON.stringify(want)) bad('games', `shards do not equal coverage ${cov.from}–${cov.to}`);
    }
    const ids = new Map();
    for (const { k, year } of shards) {
      const b = bodies.get(k);
      if (!b) continue;
      if (b.season !== year) bad('games', `${k} season ${b.season}`);
      if (b.league_code !== 'NFL') bad('games', `${k} league ${b.league_code}`);
      if (b.verification !== 'single_source_pinned') bad('games', `${k} verification ${b.verification}`);
      for (const g of b.records ?? []) {
        if (g.season !== year) bad('games', `${k}: game ${g.game_id} has season ${g.season}`);
        if (g.verification !== b.verification) bad('games', `${k}: game ${g.game_id} verification ${g.verification}`);
        if (typeof g.game_id !== 'string' || !/^g_[0-9a-f]{12}$/.test(g.game_id)) bad('games', `${k}: bad game id ${g.game_id}`);
        if (ids.has(g.game_id)) bad('games', `duplicate game id ${g.game_id}`);
        ids.set(g.game_id, year);
      }
    }
    const idx = bodies.get('games/index.json');
    if (idx && Array.isArray(idx.records)) {
      const seen = new Set();
      for (const r of idx.records) {
        if (seen.has(r.game_id)) bad('games', `index lists ${r.game_id} twice`);
        seen.add(r.game_id);
        if (ids.get(r.game_id) !== r.season) bad('games', `index entry ${r.game_id}→${r.season} does not match the shards`);
      }
      for (const id of ids.keys()) if (!seen.has(id)) bad('games', `game ${id} is missing from the index`);
    }
    const recs = bodies.get('team_season_records.json');
    if (recs) {
      if (typeof recs.label !== 'string' || !recs.label.includes(NOT_OFFICIAL)) bad('games', 'records label lacks the not-official-standings text');
      if (typeof recs.formula !== 'string' || !recs.formula.trim()) bad('games', 'records file has no formula');
      for (const r of recs.records ?? []) if (cov && (r.season < cov.from || r.season > cov.to)) bad('games', `record ${r.record_id} outside game coverage`);
    }
    const c = m.counts ?? {};
    if (c.games !== undefined && c.games !== ids.size) bad('games', `counts.games ${c.games} but shards hold ${ids.size}`);
    if (recs && c.team_season_records !== undefined && c.team_season_records !== recs.records?.length) bad('games', 'counts.team_season_records differs');
  } else {
    if (m.coverage?.games !== undefined) bad('games', 'coverage.games present without game files');
    for (const k of Object.keys(m.counts ?? {})) if (/^games|^game_|^team_season_records/.test(k)) bad('games', `counts.${k} present without game files`);
  }

  // 9. Isolation: no Version A ids anywhere in Version B data (T-60, data part).
  for (const [k, body] of [...bodies, ['manifest.json', m]]) {
    const hit = stringValues(body).find((s) => DEMO_ID.test(s));
    if (hit) bad('isolation', `${k} contains demonstration id ${hit}`);
  }
  return problems;
}

export const only = (problems, ...cats) => problems.filter((p) => cats.includes(p.cat)).map((p) => `${p.cat}: ${p.msg}`);
export const kindOf = (dir) => (listAll(dir).some((f) => f.startsWith('games/') || f === 'team_season_records.json') ? 'f2' : 'f1');
