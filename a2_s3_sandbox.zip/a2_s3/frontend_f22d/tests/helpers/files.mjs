import { readdirSync, statSync, readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { FRONTEND } from './node-loader.mjs';

export function walk(dir, exts) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const name of readdirSync(dir)) {
    if (name.startsWith('.')) continue;
    const p = path.join(dir, name);
    if (statSync(p).isDirectory()) out.push(...walk(p, exts));
    else if (!exts || exts.some((e) => name.endsWith(e))) out.push(p);
  }
  return out;
}

export const rel = (p) => path.relative(FRONTEND, p).split(path.sep).join('/');
export const read = (p) => readFileSync(p, 'utf8');
export const SNAPSHOT_BUILT = existsSync(path.join(FRONTEND, 'data/snapshot/manifest.json'));
