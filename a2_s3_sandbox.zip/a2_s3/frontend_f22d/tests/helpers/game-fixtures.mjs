// Synthetic game data in the verified F2.2 schema (F2.2d-A1 S2). Fictional ids only.
// Records are written by hand (not computed), so recompute tests are not circular.
// Every call returns fresh objects, so a test may edit its copy freely.

const SCHEMA = 'velora-nfl-frontend/1';
const SOURCE = 'src_test';

function game(n, season, type, week, date, away, home, extra = {}) {
  const [aCode, aFid, aIid, aScore] = away;
  const [hCode, hFid, hIid, hScore] = home;
  return {
    away: { franchise_id: aFid, identity_id: aIid, score: aScore },
    class: 'source',
    game_date: date,
    game_id: `g_${String(n).padStart(12, '0')}`,
    game_type: type,
    home: { franchise_id: hFid, identity_id: hIid, score: hScore },
    league_code: 'NFL',
    neutral_site: extra.neutral ?? false,
    overtime: extra.overtime ?? false,
    review_status: 'pending_review',
    season,
    source_ref: { key: `${season}_${String(week).padStart(2, '0')}_${aCode}_${hCode}`, source: SOURCE },
    verification: 'single_source_pinned',
    week,
  };
}

function shard(season, records) {
  return { class: 'source', league_code: 'NFL', records, review_status: 'pending_review', schema: SCHEMA, season, source: SOURCE, verification: 'single_source_pinned' };
}

function record(season, fid, iid, rs, ps, note = null) {
  return {
    class: 'derived',
    expected_regular_season_games: 2,
    franchise_id: fid,
    identity_id: iid,
    league_code: 'NFL',
    note_ref: note,
    postseason: { games: ps[0], losses: ps[2], rounds: ps[3], wins: ps[1] },
    record_id: `${season}-${fid}`,
    regular_season: { games: rs[0], losses: rs[2], ties: rs[3], wins: rs[1] },
    review_status: 'pending_review',
    season,
    status: note ? 'complete_with_note' : 'complete',
    verification: 'derived_from_source',
    withheld_reason: null,
  };
}

export function gameFixture() {
  const A1 = ['AAA', 'fr_aaa', 'id_aaa_01'];
  const A2 = ['AAA', 'fr_aaa', 'id_aaa_02'];
  const B = ['BBB', 'fr_bbb', 'id_bbb_01'];
  const C = ['CCC', 'fr_ccc', 'id_ccc_01'];
  const D = ['DDD', 'fr_ddd', 'id_ddd_01'];
  const s = (t, score) => [...t, score];
  const note = { field: 'schedule_note', id: 'E-TEST-01', season_id: 'NFL-2002' };

  const g2001 = [
    game(1, 2001, 'REG', 1, '2001-09-09', s(A1, 20), s(B, 17)),
    game(2, 2001, 'REG', 2, '2001-09-16', s(B, 21), s(C, 24)),
    game(3, 2001, 'REG', 3, '2001-09-23', s(C, 10), s(A1, 10), { overtime: true }),
    game(4, 2001, 'WC', 4, '2002-01-12', s(C, 7), s(A1, 14)),
    game(5, 2001, 'SB', 7, '2002-02-03', s(A1, 3), s(B, 30), { neutral: true }),
  ];
  const g2002 = [
    game(6, 2002, 'REG', 1, '2002-09-08', s(A2, 27), s(B, 13)),
    game(8, 2002, 'REG', 2, '2002-09-15', s(B, 17), s(C, 3)),
    game(7, 2002, 'REG', 2, '2002-09-15', s(D, 6), s(A2, 9)),
    game(9, 2002, 'DIV', 5, '2003-01-11', s(B, 20), s(A2, 23)),
  ];
  const all = [...g2001, ...g2002];
  return {
    manifest: { schema: SCHEMA, coverage: { games: { league: 'NFL', from: 2001, to: 2002 } }, games_source: { id: SOURCE } },
    franchises: ['fr_aaa', 'fr_bbb', 'fr_ccc', 'fr_ddd'].map((franchise_id) => ({ franchise_id })),
    identities: [
      { identity_id: 'id_aaa_01', franchise_id: 'fr_aaa', first_season: 1990, last_season: 2001 },
      { identity_id: 'id_aaa_02', franchise_id: 'fr_aaa', first_season: 2002, last_season: null },
      { identity_id: 'id_bbb_01', franchise_id: 'fr_bbb', first_season: 1990, last_season: null },
      { identity_id: 'id_ccc_01', franchise_id: 'fr_ccc', first_season: 1995, last_season: null },
      { identity_id: 'id_ddd_01', franchise_id: 'fr_ddd', first_season: 2002, last_season: null },
    ],
    seasons: [
      { season_id: 'AFL-1965', league_code: 'AFL', year: 1965, regular_season_games: 14, schedule_note: 'x' },
      { season_id: 'NFL-2000', league_code: 'NFL', year: 2000, regular_season_games: 2, schedule_note: 'Standard.' },
      { season_id: 'NFL-2001', league_code: 'NFL', year: 2001, regular_season_games: 2, schedule_note: 'Standard.' },
      { season_id: 'NFL-2002', league_code: 'NFL', year: 2002, regular_season_games: 2, schedule_note: 'One game was declared a no contest.' },
      { season_id: 'NFL-2003', league_code: 'NFL', year: 2003, regular_season_games: 2, schedule_note: 'Current season.' },
    ],
    shards: { 2001: shard(2001, g2001), 2002: shard(2002, g2002) },
    index: {
      class: 'source', description: 'Lookup from Velora game id to its season shard.', review_status: 'pending_review', schema: SCHEMA,
      records: all.map((g) => ({ game_id: g.game_id, season: g.season })).sort((a, b) => (a.game_id < b.game_id ? -1 : 1)),
    },
    records: {
      class: 'derived',
      formula: 'Counts of completed games in this snapshot for the team-season.',
      label: 'Calculated by Velora from game results in this snapshot. Not official league standings.',
      review_status: 'pending_review',
      schema: SCHEMA,
      records: [
        record(2001, 'fr_aaa', 'id_aaa_01', [2, 1, 0, 1], [2, 1, 1, ['WC', 'SB']]),
        record(2001, 'fr_bbb', 'id_bbb_01', [2, 0, 2, 0], [1, 1, 0, ['SB']]),
        record(2001, 'fr_ccc', 'id_ccc_01', [2, 1, 0, 1], [1, 0, 1, ['WC']]),
        record(2002, 'fr_aaa', 'id_aaa_02', [2, 2, 0, 0], [1, 1, 0, ['DIV']]),
        record(2002, 'fr_bbb', 'id_bbb_01', [2, 1, 1, 0], [1, 0, 1, ['DIV']]),
        record(2002, 'fr_ccc', 'id_ccc_01', [1, 0, 1, 0], [0, 0, 0, []], { ...note }),
        record(2002, 'fr_ddd', 'id_ddd_01', [1, 0, 1, 0], [0, 0, 0, []], { ...note }),
      ],
    },
  };
}

export function deepFreeze(x) {
  if (x && typeof x === 'object' && !Object.isFrozen(x)) {
    Object.freeze(x);
    for (const v of Object.values(x)) deepFreeze(v);
  }
  return x;
}
