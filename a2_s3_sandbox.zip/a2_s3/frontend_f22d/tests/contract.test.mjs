// Runs the provider contract against both providers. Snapshot checks SKIP (explicitly) when no snapshot is built.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { nodeLoader } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { createMockProvider } from '../providers/mock/index.js';
import { createSnapshotProvider } from '../providers/snapshot/index.js';
import { assertProvider, PROVIDER_METHODS } from '../src/core/contract.js';
import { validateEnvelope } from '../src/core/envelope.js';
import { SnapshotUnavailable } from '../src/core/errors.js';

const SKIP = SNAPSHOT_BUILT ? false : 'SKIP: data/snapshot not built (run tools/build_snapshot.py)';

function ok(env, label) {
  assert.deepEqual(validateEnvelope(env), [], `${label}: invalid envelope`);
  return env;
}

async function exercise(p, cls) {
  assertProvider(p);
  const man = ok(await p.getManifest(), 'getManifest');
  assert.equal(man.meta.provider, p.id);
  assert.deepEqual(man.meta.classes, [cls]);

  const franchises = ok(await p.listFranchises(), 'listFranchises').data;
  assert.equal(franchises.length, man.data.counts.franchises);
  let identityTotal = 0;
  for (const f of franchises) {
    const env = ok(await p.getFranchise(f.franchise_id), `getFranchise ${f.franchise_id}`);
    assert.equal(env.status, 'ok');
    assert.ok(env.data.identities.length >= 1, `${f.franchise_id} has a name`);
    identityTotal += env.data.identities.length;
    for (const i of env.data.identities) {
      assert.equal(i.franchise_id, f.franchise_id);
      assert.equal(i.class, cls);
      const ts = ok(await p.getTeamSeason(f.franchise_id, i.first_season), 'getTeamSeason');
      assert.equal(ts.status, 'ok', `${i.identity_id} first season resolves`);
      assert.ok(ts.data.identities.some((x) => x.identity_id === i.identity_id));
    }
    for (const m of env.data.merged_seasons) {
      assert.ok(m.franchise_ids.includes(f.franchise_id));
      for (const mb of m.members) assert.notEqual(mb.display_name, mb.franchise_id, 'member resolves to a name');
      const ts = ok(await p.getTeamSeason(f.franchise_id, m.season), 'getTeamSeason merged');
      assert.ok(ts.data.merged.some((x) => x.merged_key === m.merged_key));
    }
  }
  assert.equal(identityTotal, man.data.counts.identities, 'every identity belongs to one franchise');

  const seasons = ok(await p.listSeasons(), 'listSeasons').data;
  assert.equal(seasons.length, man.data.counts.seasons);
  for (const s of seasons) {
    const env = ok(await p.getSeason(s.league_code, s.year), 'getSeason');
    assert.equal(env.status, 'ok');
    assert.equal(env.data.season.class, cls);
  }

  // not found and invalid input
  assert.equal(ok(await p.getFranchise('fr_nope'), 'nf').status, 'not_found');
  assert.equal(ok(await p.getTeamSeason(franchises[0].franchise_id, 1800), 'nf').status, 'not_found');
  assert.equal(ok(await p.getSeason('ZZZ', 2000), 'nf').status, 'not_found');
  assert.equal(ok(await p.search('x'), 'short search').status, 'empty');

  // Series and stat coverage are switched off in both providers. Games follow the games capability
  // (F2.2d-A1, D-A1-8): unavailable when off; when on, 'g1' is not a game id, so not_found.
  for (const env of [await p.getHeadToHead('a', 'b'), await p.getStatCoverage('k', 2000)]) {
    assert.equal(ok(env, 'off').status, 'unavailable');
  }
  assert.equal(ok(await p.getGame('g1'), 'getGame').status, man.data.capabilities.games ? 'not_found' : 'unavailable');
  return man.data;
}

test('contract lists exactly the agreed methods', () => {
  assert.equal(PROVIDER_METHODS.length, 14);
});

test('mock provider satisfies the contract with demo data only', async () => {
  const p = createMockProvider(nodeLoader());
  const m = await exercise(p, 'demo');
  assert.equal(m.counts.franchises, 6);
  const players = await p.listPlayers();
  assert.equal(players.status, 'ok');
  for (const pl of players.data) {
    const env = ok(await p.getPlayer(pl.player_id), 'getPlayer');
    assert.equal(env.data.class, 'demo');
    for (const st of env.data.stints) assert.ok(st.franchise, `stint franchise ${st.franchise_id} resolves`);
  }
  const s = ok(await p.search('lantern'), 'search');
  assert.equal(s.data.franchises.length, 1);
});

test('snapshot provider satisfies the contract with curated data only', { skip: SKIP }, async () => {
  const p = createSnapshotProvider(nodeLoader());
  const m = await exercise(p, 'curated');
  assert.deepEqual(
    [m.counts.leagues, m.counts.seasons, m.counts.franchises, m.counts.franchises_active, m.counts.franchises_defunct, m.counts.identities, m.counts.merged_seasons],
    [2, 117, 80, 32, 48, 118, 3]);
  for (const env of [await p.listPlayers(), await p.getPlayer('x')]) {
    assert.equal(ok(env, 'players off').status, 'unavailable');
    assert.match(env.meta.reason, /D-F4/);
  }
  const s = ok(await p.search('cardinals'), 'search');
  assert.ok(s.data.franchises.some((f) => f.franchise_id === 'fr_ari'));
  assert.ok(s.data.notes.some((n) => /D-F4/.test(n)));
});

test('snapshot relationships: merged seasons and relocations', { skip: SKIP }, async () => {
  const p = createSnapshotProvider(nodeLoader());
  const steagles = await p.getTeamSeason('fr_phi', 1943);
  assert.equal(steagles.data.merged[0].merged_key, 'mrg_1943_phipit');
  assert.deepEqual(steagles.data.merged[0].members.map((m) => m.franchise_id), ['fr_phi', 'fr_pit']);
  const cardpitt = await p.getTeamSeason('fr_ari', 1944);
  assert.equal(cardpitt.data.merged[0].common_name, 'Card-Pitt');
  const ari = await p.getFranchise('fr_ari');
  assert.ok(ari.data.identities.length >= 3, 'Cardinals have several names');
  assert.equal(ari.data.identities.at(-1).last_season, null, 'current name is open-ended');
  for (const fid of ['fr_d_lou', 'fr_d_mnn', 'fr_d_rac']) {
    const f = await p.getFranchise(fid);
    const ids = f.data.identities;
    const gapYear = ids[0].last_season + 1;
    const gap = await p.getTeamSeason(fid, gapYear);
    assert.equal(gap.status, 'empty', `${fid} ${gapYear} has no recorded name`);
    assert.ok(gap.meta.reason);
  }
});

test('snapshot provider without a snapshot fails closed on every method (no fallback)', async () => {
  const empty = mkdtempSync(path.join(tmpdir(), 'velora-nosnap-'));
  const log = [];
  const p = createSnapshotProvider(nodeLoader(empty, log));
  const calls = [
    () => p.getManifest(), () => p.listFranchises(), () => p.getFranchise('fr_ari'), () => p.getTeamSeason('fr_ari', 2000),
    () => p.listSeasons(), () => p.getSeason('NFL', 2000), () => p.getGame('g'), () => p.getHeadToHead('a', 'b'),
    () => p.listPlayers(), () => p.getPlayer('p'), () => p.getStatCoverage('k', 2000), () => p.search('ari'),
    () => p.listSeasonGames('NFL', 2000), () => p.getFranchiseRecords('fr_ari'),
  ];
  assert.equal(calls.length, PROVIDER_METHODS.length);
  for (const call of calls) await assert.rejects(call, SnapshotUnavailable);
  assert.ok(log.every((r) => r.startsWith('data/snapshot/')), `only snapshot paths requested: ${[...new Set(log)]}`);
});

test('a provider refuses files of the wrong data class', async () => {
  // Point the snapshot provider at a loader that serves mock files under snapshot paths.
  const real = nodeLoader();
  const swapped = { json: (r) => real.json(r.replace('data/snapshot/', 'data/mock/')) };
  const p = createSnapshotProvider(swapped);
  await assert.rejects(() => p.listFranchises(), /manifest belongs to "mock"|expected "curated"/);
});
