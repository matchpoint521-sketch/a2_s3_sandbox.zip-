// F2.2d-A2: game-view helpers and the game, team-season and season page contracts.
// Pages are rendered in Node against a minimal text-only DOM defined below (no dependencies),
// with the real snapshot provider, so the checks cover the real 1999–2025 data.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FRONTEND, nodeLoader } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { createSnapshotProvider } from '../providers/snapshot/index.js';
import { createMockProvider } from '../providers/mock/index.js';
import * as gamePage from '../src/pages/game.js';
import * as teamSeasonPage from '../src/pages/team-season.js';
import * as seasonPage from '../src/pages/season.js';
import {
  formatGameDate, sideName, stageText, scoreText, gameOutcome, matchupTitle, finalText, outcomeText,
  teamResult, splitGames, regularRecordText, postseasonSummary, recordView, resolveSeasonNote, identityMap, NAME_MISSING,
} from '../src/core/game-view.js';

// ------------------------------------------------------------------ minimal DOM (text only)
class FNode {
  constructor() { this.childNodes = []; this.parentNode = null; }
  append(...kids) { for (const k of kids) { const n = k instanceof FNode ? k : new FText(String(k)); n.parentNode = this; this.childNodes.push(n); } }
  get textContent() { return this.childNodes.map((c) => c.textContent).join(''); }
}
class FText extends FNode { constructor(t) { super(); this.data = t; } get textContent() { return this.data; } }
class FElement extends FNode {
  constructor(tag) { super(); this.tagName = tag.toUpperCase(); this.attrs = new Map(); this.dataset = {}; this.style = {}; this.className = ''; }
  setAttribute(k, v) { this.attrs.set(k, String(v)); }
  getAttribute(k) { return this.attrs.has(k) ? this.attrs.get(k) : null; }
  removeAttribute(k) { this.attrs.delete(k); }
  addEventListener() {}
}
globalThis.Node = FNode;
globalThis.document = {
  createElement: (t) => new FElement(t),
  createTextNode: (t) => new FText(t),
  createDocumentFragment: () => new FElement('#fragment'),
};
const all = (n, pred, out = []) => { if (n instanceof FElement && pred(n)) out.push(n); for (const c of n.childNodes) all(c, pred, out); return out; };
const tag = (n, t) => all(n, (e) => e.tagName === t.toUpperCase());
const h1 = (n) => tag(n, 'h1').map((e) => e.textContent).join('|');
const hrefs = (n) => tag(n, 'a').map((a) => a.getAttribute('href'));
const STRAY = /\b(null|undefined|NaN)\b|\[object Object\]/;
// Win–loss or score shapes (1–2 digits each side); four-digit year ranges such as 1999–2025 are not records.
const RECORD_NUMBERS = /(?<!\d)\d{1,2}–\d{1,2}(?!\d)|Wins \d|Losses \d|No postseason games/;

const SKIP = SNAPSHOT_BUILT ? false : 'SKIP: data/snapshot not built';
const snap = () => createSnapshotProvider(nodeLoader(FRONTEND));
const mock = () => createMockProvider(nodeLoader(FRONTEND));
const route = (params) => ({ params, query: {} });

function deepFreeze(o) { if (o && typeof o === 'object' && !Object.isFrozen(o)) { Object.freeze(o); Object.values(o).forEach(deepFreeze); } return o; }

// ------------------------------------------------------------------ synthetic fixtures
const side = (f, i, score) => ({ franchise_id: f, identity_id: i, score });
const G = (extra) => ({ game_id: 'g_000000000001', season: 2001, league_code: 'NFL', game_type: 'REG', week: 3, game_date: '2001-09-23',
  neutral_site: false, overtime: false, home: side('fr_aaa', 'id_aaa_01', 24), away: side('fr_bbb', 'id_bbb_01', 17),
  source_ref: { key: '2001_03_BBB_AAA', source: 'src_test' }, class: 'source', verification: 'single_source_pinned', review_status: 'pending_review', ...extra });
const LABELS = { REG: 'Regular season', WC: 'Wild Card round', DIV: 'Divisional round', CON: 'Conference championship', SB: 'Super Bowl' };

test('A2-V1 dates are formatted as text, with no time-zone shift and no guessing', () => {
  assert.equal(formatGameDate('2022-09-08'), 'September 8, 2022');
  assert.equal(formatGameDate('2024-02-29'), 'February 29, 2024');
  assert.equal(formatGameDate('2023-01-01'), 'January 1, 2023');
  assert.equal(formatGameDate('2025-12-31'), 'December 31, 2025');
  assert.equal(formatGameDate('2025-13-01'), '2025-13-01');
  assert.equal(formatGameDate('Sept 8'), 'Sept 8');
  assert.equal(formatGameDate(null), null);
});

test('A2-V2 outcome, title, stage and final text for home win, away win, tie, overtime and neutral site', () => {
  assert.deepEqual(gameOutcome(G()), { tie: false, winner: 'home', loser: 'away' });
  assert.deepEqual(gameOutcome(G({ home: side('fr_aaa', 'id_aaa_01', 3) })), { tie: false, winner: 'away', loser: 'home' });
  const tie = G({ home: side('fr_aaa', 'id_aaa_01', 20), away: side('fr_bbb', 'id_bbb_01', 20), overtime: true });
  assert.deepEqual(gameOutcome(tie), { tie: true, winner: null, loser: null });
  assert.equal(outcomeText(tie, 'B', 'A'), 'Tie');
  assert.equal(outcomeText(G(), 'B', 'A'), 'A won');
  assert.equal(finalText(tie), 'Final, overtime');
  assert.equal(finalText(G()), 'Final');
  assert.equal(matchupTitle(G(), 'B', 'A'), 'B at A');
  assert.equal(matchupTitle(G({ neutral_site: true }), 'B', 'A'), 'B vs. A');
  assert.equal(stageText(G(), LABELS), 'Week 3');
  for (const t of ['WC', 'DIV', 'CON', 'SB']) assert.equal(stageText(G({ game_type: t, week: 20 }), LABELS), LABELS[t]);
  assert.equal(stageText(G({ game_type: 'WC' }), {}), 'WC');
  assert.equal(scoreText(31, 10), '31–10');
});

test('A2-V3 team result from each side, including ties, neutral sites and non-participants', () => {
  const home = teamResult(G(), 'fr_aaa');
  assert.equal(home.letter, 'W'); assert.equal(home.word, 'Win'); assert.equal(home.score, '24–17'); assert.equal(home.prefix, 'vs.');
  assert.equal(home.opponentIdentityId, 'id_bbb_01');
  const away = teamResult(G(), 'fr_bbb');
  assert.equal(away.letter, 'L'); assert.equal(away.word, 'Loss'); assert.equal(away.score, '17–24'); assert.equal(away.prefix, 'at');
  assert.equal(teamResult(G({ neutral_site: true }), 'fr_bbb').prefix, 'vs.');
  assert.equal(teamResult(G({ home: side('fr_aaa', 'id_aaa_01', 17) }), 'fr_bbb').letter, 'T');
  assert.equal(teamResult(G(), 'fr_zzz'), null);
});

test('A2-V4 record text, postseason summary and the availability gate', () => {
  assert.equal(regularRecordText({ games: 16, wins: 13, losses: 3, ties: 0 }), '13–3');
  assert.equal(regularRecordText({ games: 17, wins: 9, losses: 7, ties: 1 }), '9–7–1');
  assert.equal(regularRecordText(null), null);
  assert.equal(postseasonSummary({ games: 0, wins: 0, losses: 0, rounds: [] }, LABELS), null);
  assert.deepEqual(postseasonSummary({ games: 2, wins: 1, losses: 1, rounds: ['WC', 'DIV'] }, LABELS), { record: '1–1', rounds: 'Wild Card round, Divisional round' });
  const rec = { status: 'complete_with_note', expected_regular_season_games: 17, regular_season: { games: 16, wins: 13, losses: 3, ties: 0 },
    postseason: { games: 0, wins: 0, losses: 0, rounds: [] }, note_ref: { season_id: 'NFL-2022', field: 'schedule_note', id: 'E-1' } };
  const v = recordView({ state: 'available', record: rec, label: 'L', formula: 'F' }, LABELS);
  assert.equal(v.regular, '13–3'); assert.equal(v.postseason, null);
  assert.equal(v.countNote, '16 of 17 expected regular-season games are in this data.');
  assert.deepEqual(v.noteRef, rec.note_ref);
  for (const state of ['no_games', 'outside_coverage', 'not_completed', 'unavailable']) {
    assert.equal(recordView({ state, record: rec, label: 'L', formula: 'F' }), null, state);
  }
  assert.equal(recordView(null), null);
  assert.equal(recordView({ state: 'available', record: null }), null);
  assert.equal(recordView({ state: 'available', record: { ...rec, status: 'complete', note_ref: null } }).countNote, null);
});

test('A2-V5 season notes resolve only through note_ref; identity names never fall back to a number', () => {
  const seasons = [{ season_id: 'NFL-2022', schedule_note: 'A note.' }, { season_id: 'NFL-2021', schedule_note: null }];
  assert.equal(resolveSeasonNote({ season_id: 'NFL-2022', field: 'schedule_note' }, seasons), 'A note.');
  assert.equal(resolveSeasonNote({ season_id: 'NFL-2021', field: 'schedule_note' }, seasons), null);
  assert.equal(resolveSeasonNote(null, seasons), null);
  assert.equal(sideName({ location_name: 'Oakland', nickname: 'Raiders' }), 'Oakland Raiders');
  assert.equal(sideName(null), NAME_MISSING);
  assert.equal(identityMap([{ identity_id: 'x' }, null]).size, 1);
});

test('A2-V6 helpers never change their inputs', () => {
  const g = deepFreeze(G({ neutral_site: true }));
  const games = deepFreeze([G(), G({ game_id: 'g_000000000002', game_type: 'WC', week: 19 })]);
  const results = deepFreeze({ state: 'available', label: 'L', formula: 'F', record: { status: 'complete', expected_regular_season_games: 17,
    regular_season: { games: 17, wins: 9, losses: 7, ties: 1 }, postseason: { games: 1, wins: 0, losses: 1, rounds: ['WC'] }, note_ref: null } });
  assert.doesNotThrow(() => {
    teamResult(g, 'fr_aaa'); gameOutcome(g); matchupTitle(g, 'a', 'b'); outcomeText(g, 'a', 'b'); stageText(g, LABELS);
    const s = splitGames(games); assert.equal(s.regular.length, 1); assert.equal(s.postseason.length, 1);
    recordView(results, LABELS);
  });
  assert.equal(splitGames(games).regular[0], games[0], 'stored order and objects are kept');
});

// ------------------------------------------------------------------ pages on the real snapshot

const GAMES = {
  reg: 'g_d34106702f37', tieHouInd: 'g_443cce357e60', tieNygWas: 'g_c7e28c31b408', neutralReg: 'g_74808b6d42d1',
  neutralWc: 'g_becece5fd573', sb: 'g_987fe5b35110', postOt: 'g_6864cb3a06bd', was2020: 'g_d1a94ba71229',
};

test('A2-P1 game page renders every verified field, the names used that season and provenance', { skip: SKIP }, async () => {
  const p = snap();
  for (const id of Object.values(GAMES)) {
    const env = await p.getGame(id);
    const g = env.data.game;
    const { title, node } = await gamePage.render({ provider: p, route: route({ game: id }) });
    const text = node.textContent;
    assert.ok(!STRAY.test(text), `${id}: stray text`);
    assert.equal(h1(node), title);
    assert.ok(title.includes(sideName(env.data.home_identity)) && title.includes(sideName(env.data.away_identity)), id);
    assert.ok(title.includes(g.neutral_site ? ' vs. ' : ' at '), id);
    assert.ok(text.includes(String(g.home.score)) && text.includes(String(g.away.score)), id);
    assert.ok(text.includes(formatGameDate(g.game_date)), id);
    assert.ok(text.includes(env.data.game_type_label), id);
    assert.equal(text.includes('Game typePostseason'), g.game_type !== 'REG', `${id}: postseason game type (S3)`);
    assert.ok(text.includes(g.overtime ? 'Final, overtime' : 'Final ·'), id);
    assert.ok(text.includes(g.home.score === g.away.score ? '· Tie' : ' won'), id);
    assert.ok(text.includes('Game results: nflverse, nflverse-data, CC BY 4.0.'), `${id}: attribution`);
    assert.ok(text.includes(g.source_ref.key) && text.includes('Pending review'), id);
    const links = hrefs(node);
    for (const s of [g.home, g.away]) assert.ok(links.includes(`#/teams/${s.franchise_id}/${g.season}`), `${id}: team-season link`);
    assert.ok(links.includes(`#/seasons/${g.league_code}/${g.season}`), `${id}: season link`);
    assert.equal(/neutral site, as marked by the source/.test(text), g.neutral_site, `${id}: neutral note`);
    for (const absent of ['Stadium', 'Venue', 'Quarter', 'Attendance', 'Margin', 'Spread', 'Odds']) assert.ok(!text.includes(absent), `${id}: ${absent}`);
  }
});

test('A2-P2 game page: invalid ids are not found; the mock version stays unavailable with its reason', { skip: SKIP }, async () => {
  const p = snap();
  for (const id of ['1999_01_MIN_ATL', 'g_000000000000', 'g_D34106702F37']) {
    const { title, node } = await gamePage.render({ provider: p, route: route({ game: id }) });
    assert.equal(title, 'Game not found', id);
    assert.ok(!/Game details/.test(node.textContent), id);
  }
  const { title, node } = await gamePage.render({ provider: mock(), route: route({ game: 'dg_0001' }) });
  assert.equal(title, 'Game');
  const reason = (await mock().getGame('dg_0001')).meta.reason;
  assert.ok(reason && node.textContent.includes(reason));
  assert.ok(!RECORD_NUMBERS.test(node.textContent));
});

test('A2-P3 every available team-season shows its stored record, its own games and historical opponent names', { skip: SKIP }, async () => {
  const p = snap();
  const recs = JSON.parse(await (await import('node:fs/promises')).readFile(`${FRONTEND}/data/snapshot/team_season_records.json`, 'utf8')).records;
  assert.equal(recs.length, 861);
  for (const r of recs) {
    const env = await p.getTeamSeason(r.franchise_id, r.season);
    assert.equal(env.data.results.state, 'available', r.record_id);
    const { node } = await teamSeasonPage.render({ provider: p, route: route({ franchise: r.franchise_id, year: r.season }) });
    const text = node.textContent;
    assert.ok(!STRAY.test(text), `${r.record_id}: stray text`);
    assert.ok(!text.includes('Name not recorded'), `${r.record_id}: missing opponent name`);
    assert.ok(text.includes(regularRecordText(r.regular_season)), `${r.record_id}: record`);
    assert.ok(text.includes('Not official league standings'), r.record_id);
    const gameLinks = hrefs(node).filter((h) => h.startsWith('#/games/'));
    assert.equal(gameLinks.length, r.regular_season.games + r.postseason.games, `${r.record_id}: one link per game`);
    assert.equal(tag(node, 'tr').length - 1 - (r.postseason.games ? 1 : 0), gameLinks.length, `${r.record_id}: one row per game`);
    assert.equal(/No postseason games in this data/.test(text), r.postseason.games === 0, r.record_id);
  }
});

test('A2-P4 relocations and renames: page titles and opponent cells use the name used that season', { skip: SKIP }, async () => {
  const p = snap();
  const title = async (f, y) => (await teamSeasonPage.render({ provider: p, route: route({ franchise: f, year: y }) })).title;
  assert.equal(await title('fr_lar', 2015), 'St. Louis Rams, 2015');
  assert.equal(await title('fr_lar', 2016), 'Los Angeles Rams, 2016');
  assert.equal(await title('fr_was', 2020), 'Washington Football Team, 2020');
  assert.equal(await title('fr_was', 2022), 'Washington Commanders, 2022');
  assert.equal(await title('fr_ten', 1999), 'Tennessee Titans, 1999');
  const kc = async (y) => (await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_kc', year: y }) })).node.textContent;
  const t19 = await kc(2019); const t20 = await kc(2020);
  assert.ok(t19.includes('Oakland Raiders') && !t19.includes('Las Vegas Raiders'));
  assert.ok(t20.includes('Las Vegas Raiders') && !t20.includes('Oakland Raiders'));
});

test('A2-P5 2022 Buffalo and Cincinnati: 16 of 17 games, the season note, and no invented row', { skip: SKIP }, async () => {
  const p = snap();
  const note = (await p.getSeason('NFL', 2022)).data.season.schedule_note;
  for (const [f, post] of [['fr_buf', 2], ['fr_cin', 3]]) {
    const { node } = await teamSeasonPage.render({ provider: p, route: route({ franchise: f, year: 2022 }) });
    const text = node.textContent;
    assert.ok(text.includes('16 of 17 expected regular-season games are in this data.'), f);
    assert.ok(text.includes(note), `${f}: season note verbatim`);
    assert.equal(hrefs(node).filter((h) => h.startsWith('#/games/')).length, 16 + post, f);
  }
  const { node } = await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_kc', year: 2022 }) });
  assert.ok(!node.textContent.includes('expected regular-season games are in this data'), 'complete records carry no count note');
});

test('A2-P6 ties and neutral sites in team-season rows', { skip: SKIP }, async () => {
  const p = snap();
  const hou = (await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_hou', year: 2022 }) })).node;
  const tieRow = tag(hou, 'tr').find((tr) => hrefs(tr).includes(`#/games/${GAMES.tieHouInd}`));
  assert.ok(tieRow && tieRow.textContent.includes('Tie, ') && tieRow.textContent.includes('Yes'), 'tie row with overtime');
  assert.ok(hou.textContent.includes('–1'), 'record shows the tie');
  const lar = (await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_lar', year: 2024 }) })).node;
  const wc = tag(lar, 'tr').find((tr) => hrefs(tr).includes(`#/games/${GAMES.neutralWc}`));
  assert.ok(wc && wc.textContent.includes('(neutral site)') && wc.textContent.startsWith('Wild Card round'));
  const heads = tag(lar, 'thead').map((t) => tag(t, 'th').map((c) => c.textContent).join('|'));
  assert.deepEqual(heads, ['Week|Opponent|Result|Date|Overtime', 'Round|Opponent|Result|Date|Overtime'], 'S3 column order');
});

test('A2-P7 states without game data never show record numbers, and always show the provider reason', { skip: SKIP }, async () => {
  const p = snap();
  const franchises = (await p.listFranchises()).data.map((f) => f.franchise_id);
  let checked = 0;
  for (const f of franchises) {
    for (const y of [1920, 1944, 1960, 1965, 1998, 2026, 1999, 2010]) {
      const env = await p.getTeamSeason(f, y);
      if (env.status === 'not_found') continue;
      const state = env.data.results.state;
      if (state === 'available') continue;
      const { node } = await teamSeasonPage.render({ provider: p, route: route({ franchise: f, year: y }) });
      const text = node.textContent;
      assert.ok(!RECORD_NUMBERS.test(text), `${f} ${y} (${state}) shows record numbers`);
      assert.ok(!STRAY.test(text), `${f} ${y}: stray text`);
      assert.equal(hrefs(node).filter((h) => h.startsWith('#/games/')).length, 0, `${f} ${y}`);
      if (env.status === 'ok') assert.ok(text.includes(env.data.results.reason), `${f} ${y}: reason`);
      checked += 1;
    }
  }
  assert.ok(checked > 400, `checked ${checked}`);
  const empty = await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_hou', year: 2000 }) });
  assert.ok(empty.node.textContent.includes('No name recorded for this season'), 'D-A2-11: A1 empty state kept');
  const nf = await teamSeasonPage.render({ provider: p, route: route({ franchise: 'fr_buf', year: 2027 }) });
  assert.equal(nf.title, 'Season not found');
  const m = await teamSeasonPage.render({ provider: mock(), route: route({ franchise: 'dm_lan', year: 1990 }) });
  assert.ok(!RECORD_NUMBERS.test(m.node.textContent));
  assert.ok(m.node.textContent.includes((await mock().getTeamSeason('dm_lan', 1990)).data.results.reason));
});

test('A2-P8 navigation round trip: team-season → game → both team-seasons', { skip: SKIP }, async () => {
  const p = snap();
  for (const [f, y] of [['fr_buf', 2022], ['fr_ne', 2025], ['fr_lar', 2015], ['fr_ten', 1999]]) {
    const { node } = await teamSeasonPage.render({ provider: p, route: route({ franchise: f, year: y }) });
    for (const link of hrefs(node).filter((h) => h.startsWith('#/games/'))) {
      const id = link.slice('#/games/'.length);
      const env = await p.getGame(id);
      assert.equal(env.status, 'ok', link);
      assert.ok([env.data.game.home.franchise_id, env.data.game.away.franchise_id].includes(f), link);
      const back = hrefs((await gamePage.render({ provider: p, route: route({ game: id }) })).node);
      assert.ok(back.includes(`#/teams/${f}/${y}`), `${link} links back`);
    }
  }
});

test('A2-P9 season page (D-A2-6b): no false "not in this snapshot" text; mock copy unchanged', { skip: SKIP }, async () => {
  const p = snap();
  const cov = (await p.getManifest()).data.coverage.games.note;
  for (const [l, y] of [['NFL', 2022], ['NFL', 1950], ['AFL', 1965], ['NFL', 2026]]) {
    const text = (await seasonPage.render({ provider: p, route: route({ league: l, year: y }) })).node.textContent;
    assert.ok(!text.includes('not in this development snapshot'), `${l} ${y}`);
    assert.ok(text.includes(cov), `${l} ${y}: coverage note`);
    assert.ok(!STRAY.test(text), `${l} ${y}`);
  }
  const mtext = (await seasonPage.render({ provider: mock(), route: route({ league: 'DEMO', year: 1974 }) })).node.textContent;
  assert.ok(mtext.includes('Results, standings and playoffs'));
  assert.ok(mtext.includes('Demonstration game results arrive with the game pages in milestone F2.'));
});
