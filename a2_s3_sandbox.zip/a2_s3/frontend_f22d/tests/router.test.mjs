import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseHash, href } from '../src/app/router.js';
import { ROUTES } from '../src/app/routes.js';
import { PAGES } from '../src/pages/index.js';

const CASES = [
  ['', 'explore', {}], ['#/', 'explore', {}], ['#/compare', 'compare', {}], ['#/compare/teams?a=fr_ari', 'compare-teams', {}],
  ['#/compare/seasons', 'compare-seasons', {}], ['#/compare/players', 'compare-players', {}], ['#/teams', 'teams', {}],
  ['#/teams/fr_ari', 'team', { franchise: 'fr_ari' }], ['#/teams/fr_ari/1944', 'team-season', { franchise: 'fr_ari', year: 1944 }],
  ['#/players', 'players', {}], ['#/players/dp_001', 'player', { player: 'dp_001' }], ['#/seasons', 'seasons', {}],
  ['#/seasons/AFL/1965', 'season', { league: 'AFL', year: 1965 }], ['#/games/1999_01_MIN_ATL', 'game', { game: '1999_01_MIN_ATL' }],
  ['#/search?q=bears', 'search', {}], ['#/data', 'data', {}],
];

test('every route in the table has a test case and a page', () => {
  const tested = new Set(CASES.map(([, id]) => id));
  for (const r of ROUTES) {
    assert.ok(tested.has(r.id), `no case for ${r.id}`);
    assert.ok(PAGES[r.id], `no page for ${r.id}`);
  }
  assert.equal(ROUTES.length, 15);
  assert.ok(PAGES['not-found']);
});

test('routes parse with typed parameters', () => {
  for (const [hash, id, params] of CASES) {
    const r = parseHash(hash);
    assert.equal(r.id, id, hash);
    assert.deepEqual(r.params, params, hash);
  }
  assert.deepEqual(parseHash('#/search?q=green%20bay').query, { q: 'green bay' });
});

test('malformed and unknown paths go to not-found', () => {
  for (const bad of ['#/nope', '#/teams/fr_ari/19444', '#/teams/FR ARI', '#/seasons/nfl/1965', '#/seasons/NFL/19x5', '#/teams/fr_ari/1944/extra', '#/players/%E0%A4%A']) {
    assert.equal(parseHash(bad).id, 'not-found', bad);
  }
});

test('href builds links that parse back to the same route', () => {
  for (const [hash, id, params] of CASES) {
    const built = href(id, params, parseHash(hash).query);
    const back = parseHash(built);
    assert.equal(back.id, id);
    assert.deepEqual(back.params, params);
  }
  assert.equal(href('teams', {}, { status: null, q: '' }), '#/teams');
});
