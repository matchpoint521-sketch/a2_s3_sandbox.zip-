// F2.2d-A1 S3: G25 (provider-level eviction and retry, D-A1-13 option A) and G26 at provider level.
// Uses temporary copies of the real snapshot; data/snapshot and src/core/loader.js are never changed.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { nodeLoader, FRONTEND } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { kindOf } from './helpers/snapshot-rules.mjs';
import { deepFreeze } from './helpers/game-fixtures.mjs';
import { createSnapshotProvider } from '../providers/snapshot/index.js';
import { browserLoader } from '../src/core/loader.js';
import { DataLoadError } from '../src/core/errors.js';

const SNAP = path.join(FRONTEND, 'data/snapshot');
const SKIP = SNAPSHOT_BUILT && kindOf(SNAP) === 'f2' ? false : 'SKIP: no game snapshot in data/snapshot';
const S2005 = 'data/snapshot/games/2005.json';

// A temporary copy in which season 2005 fails its check: one regular-season result is flipped,
// so the shard is well formed but no longer matches its team-season records.
function brokenCopy() {
  const root = mkdtempSync(path.join(tmpdir(), 'velora-g25-'));
  cpSync(SNAP, path.join(root, 'data/snapshot'), { recursive: true });
  const file = path.join(root, S2005);
  const good = readFileSync(file, 'utf8');
  const body = JSON.parse(good);
  const g = body.records.find((x) => x.game_type === 'REG' && x.home.score !== x.away.score);
  [g.home.score, g.away.score] = [g.away.score, g.home.score];
  writeFileSync(file, JSON.stringify(body));
  return { root, gameId: g.game_id, franchiseId: g.home.franchise_id, restore: () => writeFileSync(file, good) };
}
const reads = (log, rel) => log.filter((r) => r === rel).length;

test('G25-1 only the failing season is discarded; other seasons and shared files stay cached', { skip: SKIP }, async () => {
  const b = brokenCopy();
  const log = [];
  const p = createSnapshotProvider(nodeLoader(b.root, log));
  const before = await p.listSeasonGames('NFL', 2004);
  assert.equal(before.status, 'ok');
  await assert.rejects(p.listSeasonGames('NFL', 2005), (e) => e instanceof DataLoadError && /2005-fr_\w+ regular season/.test(e.message));
  const after = await p.listSeasonGames('NFL', 2004);
  assert.deepEqual(after, before);
  assert.equal(reads(log, 'data/snapshot/games/2004.json'), 1, '2004 was not re-read');
  assert.equal(reads(log, 'data/snapshot/games/index.json'), 1, 'index was not re-read');
  assert.equal(reads(log, 'data/snapshot/team_season_records.json'), 1, 'records were not re-read');
  await assert.rejects(p.listSeasonGames('NFL', 2005), DataLoadError);
  assert.equal(reads(log, S2005), 2, 'the failing season alone is requested again on the next call');
});

test('G25-2 no partial or invalid data: every path into the failing season rejects; others are untouched', { skip: SKIP }, async () => {
  const b = brokenCopy();
  const p = createSnapshotProvider(nodeLoader(b.root));
  const clean = createSnapshotProvider(nodeLoader(FRONTEND));
  await assert.rejects(p.getGame(b.gameId), DataLoadError);
  await assert.rejects(p.getTeamSeason(b.franchiseId, 2005), DataLoadError);
  await assert.rejects(p.listSeasonGames('NFL', 2005, { type: 'REG' }), DataLoadError);
  for (const y of [2004, 2006]) assert.deepEqual(await p.listSeasonGames('NFL', y), await clean.listSeasonGames('NFL', y));
  assert.deepEqual(await p.getTeamSeason(b.franchiseId, 2006), await clean.getTeamSeason(b.franchiseId, 2006));
  assert.deepEqual(await p.getFranchiseRecords(b.franchiseId), await clean.getFranchiseRecords(b.franchiseId), 'records-only reads are structural (D-A1-11)');
});

test('G25-3 retry succeeds when a non-caching loader supplies corrected bytes', { skip: SKIP }, async () => {
  const b = brokenCopy();
  const log = [];
  const p = createSnapshotProvider(nodeLoader(b.root, log));
  await assert.rejects(p.listSeasonGames('NFL', 2005), DataLoadError);
  b.restore();
  const env = await p.listSeasonGames('NFL', 2005);
  assert.equal(env.status, 'ok');
  assert.deepEqual(env, await createSnapshotProvider(nodeLoader(FRONTEND)).listSeasonGames('NFL', 2005));
  assert.equal((await p.getGame(b.gameId)).status, 'ok');
  assert.equal(reads(log, S2005), 2, 'one failed read, one successful re-read, then cached');
});

test('G25-4 the real browser loader keeps the invalid bytes until a reload (documented limitation)', { skip: SKIP }, async (t) => {
  const b = brokenCopy();
  const realFetch = globalThis.fetch;
  let fetches = 0;
  globalThis.fetch = async (url) => {
    fetches += 1;
    try { return new Response(readFileSync(path.join(b.root, new URL(url).pathname), 'utf8'), { status: 200 }); }
    catch { return new Response('', { status: 404 }); }
  };
  t.after(() => { globalThis.fetch = realFetch; });
  const base = 'velora-test://frontend/';
  const page1 = createSnapshotProvider(browserLoader(base));
  await assert.rejects(page1.listSeasonGames('NFL', 2005), DataLoadError);
  b.restore();
  const n = fetches;
  await assert.rejects(page1.listSeasonGames('NFL', 2005), DataLoadError, 'same page: the loader serves its cached copy of the invalid file');
  assert.equal(fetches, n, 'nothing was fetched again: the loader cache answered');
  assert.equal((await page1.listSeasonGames('NFL', 2004)).status, 'ok', 'other seasons still work on the same page');
  const page2 = createSnapshotProvider(browserLoader(base)); // a page reload creates a new loader
  assert.equal((await page2.listSeasonGames('NFL', 2005)).status, 'ok', 'after a reload the corrected file is read');
});

test('G26 provider methods never change loader-returned objects (deep-frozen and byte-compared)', { skip: SKIP }, async () => {
  const cache = new Map();
  const base = nodeLoader(FRONTEND);
  const frozenLoader = { json: (rel) => { if (!cache.has(rel)) cache.set(rel, base.json(rel).then(deepFreeze)); return cache.get(rel); } };
  const run = async (p) => [
    await p.getGame('g_4bf81cf6cdc9'),
    await p.listSeasonGames('NFL', 1999), await p.listSeasonGames('NFL', 2022, { type: 'WC' }), await p.listSeasonGames('NFL', 1998),
    await p.getTeamSeason('fr_buf', 2022), await p.getTeamSeason('fr_lar', 2016), await p.getTeamSeason('fr_ari', 1998),
    await p.getFranchiseRecords('fr_lar'), await p.getFranchiseRecords('fr_d_akr'),
    await p.listFranchises(), await p.getFranchise('fr_lv'), await p.getSeason('NFL', 2022), await p.search('rams'),
  ];
  let frozenResults;
  await assert.doesNotReject(async () => { frozenResults = await run(createSnapshotProvider(frozenLoader)); });
  assert.deepEqual(frozenResults, await run(createSnapshotProvider(nodeLoader(FRONTEND))), 'frozen and plain inputs give the same envelopes');
  const plainCache = new Map();
  const plainLoader = { json: (rel) => { if (!plainCache.has(rel)) plainCache.set(rel, base.json(rel)); return plainCache.get(rel); } };
  await run(createSnapshotProvider(plainLoader));
  for (const [rel, p] of plainCache) {
    const onDisk = JSON.parse(readFileSync(path.join(FRONTEND, rel), 'utf8'));
    assert.equal(JSON.stringify(await p), JSON.stringify(onDisk), `${rel}: the loader's object is unchanged after use`);
  }
});
