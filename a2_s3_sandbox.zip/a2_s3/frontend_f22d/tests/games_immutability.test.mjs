// F2.2d-A1 S2, G26: no game validation or processing function changes the objects it is given.
// Loader results are shared cache entries (loader.js and the P-1 embedded loader cache one
// parsed object per path), so a mutation would silently change data for every later reader.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { gameFixture, deepFreeze } from './helpers/game-fixtures.mjs';
import * as games from '../src/core/games.js';

// Every function export, called the way a provider would call it (valid and invalid inputs).
function exerciseAll(f) {
  const ctx = games.makeGameContext(f);
  const seasonOf = games.indexLookup(f.index);
  const out = {
    makeGameContext: ctx.schema,
    validateShard: [games.validateShard(f.shards[2001], 2001, ctx), games.validateShard(f.shards[2002], 2002, ctx), games.validateShard(f.shards[2002], 2001, ctx)],
    validateIndex: games.validateIndex(f.index, ctx),
    validateRecords: games.validateRecords(f.records, ctx),
    indexLookup: [...seasonOf],
    checkIndexForSeason: [games.checkIndexForSeason(seasonOf, 2001, f.shards[2001]), games.checkIndexForSeason(seasonOf, 2002, f.shards[2001])],
    shardLookup: [...games.shardLookup(f.shards[2002]).keys()],
    recordLookups: [...games.recordLookups(f.records).byFranchise.keys()],
    recomputeSeason: [...games.recomputeSeason(f.shards[2001].records)],
    checkSeasonRecords: [games.checkSeasonRecords(2001, f.shards[2001], f.records.records), games.checkSeasonRecords(2002, f.shards[2001], f.records.records)],
    coverageState: ['NFL', 'AFL'].map((l) => games.coverageState(l, 2001, ctx)),
    validateFilters: [games.validateFilters({ week: 1 }), games.validateFilters({ type: 'X' })],
    filterGames: games.filterGames(f.shards[2001].records, { type: 'REG' }).map((g) => g.game_id),
    isCalendarDate: games.isCalendarDate(f.shards[2001].records[0].game_date),
    isGameId: games.isGameId(f.index.records[0].game_id),
    weekRange: f.seasons.map((x) => games.weekRange('SB', x.regular_season_games)),
  };
  return out;
}

test('G26 every function export is exercised by this test', () => {
  const fns = Object.entries(games).filter(([, v]) => typeof v === 'function').map(([k]) => k).sort();
  assert.deepEqual(Object.keys(exerciseAll(gameFixture())).sort(), fns);
});

test('G26 deep-frozen inputs: every function runs without writing, with the same results', () => {
  const frozen = deepFreeze(gameFixture());
  assert.ok(Object.isFrozen(frozen.shards[2001].records[0].home), 'fixture is deep-frozen');
  let got;
  assert.doesNotThrow(() => { got = exerciseAll(frozen); }, 'a write to a frozen object throws in module (strict) code');
  assert.deepEqual(got, exerciseAll(gameFixture()), 'frozen and unfrozen inputs give identical results');
});

test('G26 unfrozen inputs are byte-identical after every function has run', () => {
  const f = gameFixture();
  const before = JSON.stringify(f);
  exerciseAll(f);
  const bad = gameFixture();
  bad.shards[2001].records[0].home.score = -1;
  bad.records.records[0].postseason.rounds = ['SB', 'WC'];
  const badBefore = JSON.stringify(bad);
  exerciseAll(bad);
  assert.equal(JSON.stringify(f), before);
  assert.equal(JSON.stringify(bad), badBefore, 'failing validation does not change inputs either');
});

test('G26 results are new objects, never the inputs themselves', () => {
  const f = deepFreeze(gameFixture());
  const calc = games.recomputeSeason(f.shards[2001].records);
  for (const v of calc.values()) assert.equal(Object.isFrozen(v), false, 'recompute results are fresh objects');
  const filtered = games.filterGames(f.shards[2001].records, {});
  assert.notEqual(filtered, f.shards[2001].records);
  const { bySeason } = games.recordLookups(f.records);
  assert.notEqual(bySeason.get(2001), f.records.records);
  assert.equal(Object.isFrozen(games.makeGameContext(f)), true, 'the context itself is frozen against later edits');
});
