"""F2.1 tests for the historical game builder (tools/f2_games.py via tools/build_snapshot.py).

Standard library only. Needs two inputs, located through environment variables:
  VELORA_SEED_SOURCE   folder holding the six curated seed CSVs (or a seed/ subfolder)
  VELORA_GAMES_SOURCE  the pinned nflverse games CSV (sha256 24d55c06…)
Without them every test here reports SKIP with an explicit message.

Negative controls write tampered copies and temporary configs into a temp folder only;
the pinned inputs and the packaged config are never modified. Test ids follow
NFL_F2_TEST_PLAN.md (T-xx).
"""
import ast
import csv
import hashlib
import io
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from collections import Counter, defaultdict
from pathlib import Path

FRONTEND = Path(__file__).resolve().parent.parent
TOOLS = FRONTEND / "tools"
BUILDER = TOOLS / "build_snapshot.py"
CONFIG = TOOLS / "f2_games_inputs.json"
SEEDS = os.environ.get("VELORA_SEED_SOURCE")
GAMES = os.environ.get("VELORA_GAMES_SOURCE")
SKIP_MSG = "SKIP: set VELORA_SEED_SOURCE (seed CSV folder) and VELORA_GAMES_SOURCE (pinned games CSV)"

sys.path.insert(0, str(TOOLS))
import build_snapshot as B  # noqa: E402
import f2_games as F2  # noqa: E402

F15_SEED_PINS = {
    "league_seed.csv": "edad89a1f5cc10ecdc644fb33e75995bcb751f9c3a4c67460ea567878963f32c",
    "season_seed.csv": "e977fa477ad298d0dc57f938d7eab680ffcf87e3aabd531816eb44f7911b1db6",
    "franchise_seed.csv": "93434ccae9a2f444f3eca42d0c8440e5492455ba2e41e805f548931c74fc4c51",
    "team_identity_seed.csv": "946bafc06bfe6c453ff91608ecf4144f0e8adae0de9dc6ab65a2526d39e0de8d",
    "merged_identity_seed.csv": "4cb2c4ac0b5257c4331df53b6a43b3d08e31780b4db5ce6e544d84efb1cb1418",
    "merged_team_season_seed.csv": "3f7c8d000adfe130bb0dbbdbb2ad6dcbfccc721e75d10164772fa05adcba7214",
}
F15_BUILD_ID = "50dfae255ff610ad738593fc8a98b131d209837c70ff59fd1d851e953b790c2a"
GAMES_SHA = "24d55c0686438606c197d61196df4a337e1b2c4d1b5d19482d6b90ee64c6fddb"
# Same patterns as tests/forbidden.test.mjs (F1.5).
BETTING = re.compile(r"moneyline|spread_line|_odds\b|total_line|over_odds|under_odds|\bwager|\bsportsbook", re.I)
DATABASE = re.compile(r"postgres|psql|pg_dump|:5432|velora_nfl_dev|velora_nfl_test|tipoff_|matchpoint_db", re.I)
URL_RE = re.compile(r"\bhttps?://", re.I)
GAME_KEYS = {"game_id", "season", "league_code", "game_type", "week", "game_date", "home", "away",
             "neutral_site", "overtime", "source_ref", "class", "verification", "review_status"}
SIDE_KEYS = {"franchise_id", "identity_id", "score"}
RECORD_KEYS = {"record_id", "season", "league_code", "franchise_id", "identity_id", "expected_regular_season_games",
               "regular_season", "postseason", "status", "note_ref", "withheld_reason", "class", "verification", "review_status"}
BROWSER_FILES = re.compile(r"^(games/\d{4}\.json|games/index\.json|team_season_records\.json)$")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(*args):
    return subprocess.run([sys.executable, str(BUILDER), *map(str, args)], capture_output=True, text=True)


def tree(folder):
    folder = Path(folder)
    return {p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob("*")) if p.is_file()}


def read_csv(path):
    rows = list(csv.reader(io.StringIO(Path(path).read_text("utf-8"), newline="")))
    return rows[0], rows[1:]


class Fixture:
    """A tampered copy of the games CSV plus a temporary config pinned to it."""

    def __init__(self, tmp, name):
        self.dir = Path(tmp) / name
        self.dir.mkdir(parents=True)
        self.header, self.rows = read_csv(GAMES)
        self.cfg = json.loads(CONFIG.read_text("utf-8"))
        self.map_text = (TOOLS / self.cfg["team_code_map"]["file"]).read_text("utf-8")
        self.exceptions = json.loads((TOOLS / self.cfg["exceptions"]["file"]).read_text("utf-8"))

    def col(self, name):
        return self.header.index(name)

    def find(self, key):
        return next(r for r in self.rows if r[0] == key)

    def set(self, key, **values):
        r = self.find(key)
        for k, v in values.items():
            r[self.col(k)] = v
        return r

    def write(self, update_raw=True, update_slice=True):
        buf = io.StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(self.header)
        w.writerows(self.rows)
        data = buf.getvalue().encode("utf-8")
        games = self.dir / "games.csv"
        games.write_bytes(data)
        if update_raw:
            self.cfg["file"].update(sha256=sha(data), rows=len(self.rows))
        if update_slice:
            dicts = [dict(zip(self.header, r)) for r in self.rows] if len(set(map(len, self.rows))) == 1 else []
            if dicts and list(dicts[0].keys()) == self.cfg["file"]["header"]:
                digest, n = F2.slice_digest(dicts, self.cfg)
                self.cfg["slice"].update(digest=digest, rows=n)
        (self.dir / self.cfg["team_code_map"]["file"]).write_text(self.map_text, "utf-8")
        self.cfg["team_code_map"]["sha256"] = sha(self.map_text.encode("utf-8"))
        exc = (json.dumps(self.exceptions, indent=1) + "\n").encode("utf-8")
        (self.dir / self.cfg["exceptions"]["file"]).write_bytes(exc)
        self.cfg["exceptions"]["sha256"] = sha(exc)
        config = self.dir / "f2_games_inputs.json"
        config.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=1) + "\n", "utf-8")
        return games, config

    def build(self, out=None, *extra, **write_kw):
        games, config = self.write(**write_kw)
        out = out or self.dir / "out"
        return run("--source", SEEDS, "--games", games, "--games-config", config, "--out", out, *extra), out


@unittest.skipUnless(SEEDS and GAMES, SKIP_MSG)
class F2Build(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp(prefix="velora-f2-"))
        cls.out = cls.tmp / "base"
        r = run("--source", SEEDS, "--games", GAMES, "--out", cls.out)
        assert r.returncode == 0, r.stderr
        cls.files = tree(cls.out)
        cls.manifest = json.loads(cls.files["manifest.json"])
        cls.games = [g for s in range(1999, 2026) for g in json.loads(cls.files[f"games/{s}.json"])["records"]]
        cls.records = json.loads(cls.files["team_season_records.json"])["records"]
        cls.rec = {r["record_id"]: r for r in cls.records}
        cls.disp = json.loads(cls.files["audit/games_dispositions.json"])
        cls.mapping = json.loads(cls.files["audit/mapping_report.json"])

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def fixture(self, name):
        return Fixture(self.tmp, name)

    def assertRefused(self, result, code, text=None):
        self.assertEqual(result.returncode, code, result.stderr + result.stdout)
        if text:
            self.assertIn(text, result.stderr)

    # ---------------------------------------------------------------- 1. inputs and pins
    def test_T00_pinned_input_hash(self):
        self.assertEqual(sha(Path(GAMES).read_bytes()), GAMES_SHA)
        self.assertEqual(json.loads(CONFIG.read_text("utf-8"))["file"]["sha256"], GAMES_SHA)

    def test_T01_raw_hash_mismatch_refuses(self):
        bad = self.tmp / "t01.csv"
        bad.write_bytes(Path(GAMES).read_bytes() + b"\n")
        out = self.tmp / "t01_out"
        r = run("--source", SEEDS, "--games", bad, "--out", out)
        self.assertRefused(r, 2, "hash mismatch")
        self.assertFalse(out.exists())

    def test_T02_slice_digest_enforced_even_with_new_raw_pin(self):
        fx = self.fixture("t02")
        fx.set("2010_01_MIA_BUF", home_score="11", result="-4", total="26")
        r, out = fx.build(update_raw=True, update_slice=False)
        self.assertRefused(r, 2, "historical-slice digest differs")
        self.assertFalse(out.exists())

    def test_T03_header_contract(self):
        cases = {
            "added": lambda h, rows: (h + ["extra"], [r + [""] for r in rows]),
            "removed": lambda h, rows: (h[:-1], [r[:-1] for r in rows]),
            "renamed": lambda h, rows: ([("home_pts" if c == "home_score" else c) for c in h], rows),
            "reordered": lambda h, rows: ([h[1], h[0]] + h[2:], [[r[1], r[0]] + r[2:] for r in rows]),
        }
        for name, change in cases.items():
            with self.subTest(name):
                fx = self.fixture(f"t03_{name}")
                fx.header, fx.rows = change(fx.header, fx.rows)
                r, _ = fx.build(update_slice=False)
                self.assertRefused(r, 2, "header differs")

    def test_T04_seed_pins_unchanged(self):
        self.assertEqual(json.loads((TOOLS / "snapshot_inputs.json").read_text("utf-8"))["files"], F15_SEED_PINS)

    def test_T05_no_network_or_database_imports(self):
        banned = {"socket", "urllib", "http", "requests", "ssl", "ftplib", "smtplib", "asyncio", "sqlite3", "psycopg", "psycopg2"}
        for f in (TOOLS / "f2_games.py", BUILDER):
            mods = set()
            for node in ast.walk(ast.parse(f.read_text("utf-8"))):
                if isinstance(node, ast.Import):
                    mods |= {a.name.split(".")[0] for a in node.names}
                elif isinstance(node, ast.ImportFrom) and node.module:
                    mods.add(node.module.split(".")[0])
            self.assertFalse(mods & banned, f"{f.name} imports {mods & banned}")

    # ---------------------------------------------------------------- 2. schema and allowlist
    def test_T10_output_schema(self):
        for g in self.games:
            self.assertEqual(set(g), GAME_KEYS)
            self.assertEqual(set(g["home"]), SIDE_KEYS)
            self.assertEqual(set(g["away"]), SIDE_KEYS)
            self.assertEqual(set(g["source_ref"]), {"source", "key"})
            self.assertIn(g["game_type"], F2.GAME_TYPES)
            self.assertIsInstance(g["neutral_site"], bool)
            self.assertIsInstance(g["overtime"], bool)
            self.assertTrue(all(isinstance(g[s]["score"], int) and 0 <= g[s]["score"] <= 99 for s in ("home", "away")))
            self.assertRegex(g["game_date"], r"^\d{4}-\d{2}-\d{2}$")
            self.assertEqual((g["class"], g["verification"], g["review_status"], g["league_code"]),
                             ("source", "single_source_pinned", "pending_review", "NFL"))
        for r in self.records:
            self.assertEqual(set(r), RECORD_KEYS)
            self.assertEqual((r["class"], r["review_status"]), ("derived", "pending_review"))
        for s in range(1999, 2026):
            body = json.loads(self.files[f"games/{s}.json"])
            self.assertEqual((body["class"], body["season"], body["review_status"]), ("source", s, "pending_review"))
        recs = json.loads(self.files["team_season_records.json"])
        self.assertIn("Not official league standings", recs["label"])
        self.assertEqual(recs["class"], "derived")

    def test_T11_forbidden_keys(self):
        def keys(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    yield k
                    yield from keys(v)
            elif isinstance(o, list):
                for v in o:
                    yield from keys(v)
        for name, body in self.files.items():
            for k in keys(json.loads(body)):
                self.assertIsNone(B.FORBIDDEN_KEY.search(k), f"{name}: {k}")

    def test_T12_non_emitted_columns_and_values_never_reach_output(self):
        cfg = json.loads(CONFIG.read_text("utf-8"))
        names = [c for c in cfg["file"]["header"] if c not in cfg["slice"]["digest_fields"]]
        self.assertEqual(len(names), 35)
        pat = re.compile(r"(?<![A-Za-z0-9_])(" + "|".join(map(re.escape, names)) + r")(?![A-Za-z0-9_])")
        for name, body in self.files.items():
            if name.startswith(("games/", "audit/")) or name in ("team_season_records.json", "manifest.json"):
                self.assertIsNone(pat.search(body.decode("utf-8")), name)
        # Sentinel values in non-emitted columns of an included game must not appear anywhere.
        fx = self.fixture("t12")
        key = "2015_05_WAS_ATL"
        # Sentinels contain characters that can never occur in hex digests or ids.
        fx.set(key, spread_line="-777.25", home_moneyline="+313.37q", total_line="88.75", home_qb_name="Sentinel Zqx Player",
               referee="Referee Zqx", stadium="Stadium Zqx", gsis="gsisZqx", espn="espnZqx")
        r, out = fx.build(update_slice=False)  # non-emitted columns are not in the slice digest
        self.assertEqual(r.returncode, 0, r.stderr)
        blob = b"".join(tree(out).values())
        for s in (b"-777.25", b"313.37q", b"88.75", b"Zqx"):
            self.assertNotIn(s, blob)

    def test_T13_frontend_forbidden_patterns(self):
        for name, body in self.files.items():
            text = body.decode("utf-8")
            self.assertIsNone(BETTING.search(text), name)
            self.assertIsNone(DATABASE.search(text), name)
            self.assertIsNone(URL_RE.search(text), name)

    # ---------------------------------------------------------------- 3. coverage and identity
    def test_T20_season_coverage_and_counts(self):
        cfg = json.loads(CONFIG.read_text("utf-8"))
        by = defaultdict(Counter)
        for g in self.games:
            by[g["season"]][g["game_type"]] += 1
        self.assertEqual(sorted(by), list(range(1999, 2026)))
        for s in range(1999, 2026):
            st = F2.structure_for(cfg, s)
            reg = st["teams"] * st["reg_games_per_team"] // 2 - (1 if s == 2022 else 0)
            self.assertEqual(dict(by[s]), {"REG": reg, "WC": st["wc_games"], "DIV": 4, "CON": 2, "SB": 1}, s)
        self.assertEqual(len(self.games), 7276)
        self.assertEqual(self.manifest["coverage"]["games"]["from"], 1999)
        self.assertEqual(self.manifest["coverage"]["games"]["to"], 2025)
        self.assertNotIn("games/1998.json", self.files)

    def test_T21_2026_excluded(self):
        x1 = [d for d in self.disp["rows"] if d["disposition"] == F2.X1]
        self.assertEqual(len(x1), 272)
        self.assertTrue(all(d["season"] == "2026" and d["game_id"] is None for d in x1))
        self.assertEqual(self.disp["counts"], {"INCLUDED": 7276, "X1_SEASON_NOT_COMPLETED": 272})
        self.assertNotIn("games/2026.json", self.files)
        self.assertFalse(any(g["season"] > 2025 for g in self.games))
        _, rows = read_csv(GAMES)
        played_2026 = {r[0] for r in rows if r[1] == "2026" and r[10] != ""}
        self.assertEqual(len(played_2026), 80)
        self.assertTrue(played_2026 <= {d["source_key"] for d in x1})

    def test_T22_game_id_uniqueness_and_collision(self):
        ids = [g["game_id"] for g in self.games]
        self.assertEqual(len(set(ids)), 7276)
        self.assertEqual(len({g["source_ref"]["key"] for g in self.games}), 7276)
        route_rule = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
        for g in self.games:
            self.assertRegex(g["game_id"], r"^g_[0-9a-f]{12}$")
            self.assertRegex(g["game_id"], route_rule)
            self.assertEqual(g["game_id"], F2.game_id_for(g["source_ref"]["key"]))
        index = json.loads(self.files["games/index.json"])["records"]
        self.assertEqual({i["game_id"]: i["season"] for i in index}, {g["game_id"]: g["season"] for g in self.games})
        rows = [{"game_id": f"k{i}", "season": "2000", "game_type": "REG", "week": "1", "gameday": "2000-09-10",
                 "home_score": "1", "away_score": "0", "location": "Home", "overtime": "0"} for i in range(40)]
        disp = [{"source_key": f"k{i}", "disposition": F2.INCLUDED,
                 "home": {"franchise_id": "a", "identity_id": "a"}, "away": {"franchise_id": "b", "identity_id": "b"}} for i in range(40)]
        with self.assertRaises(F2.Refused) as cm:
            F2.make_games(rows, disp, id_length=1)  # 40 keys into 16 ids must collide
        self.assertEqual(cm.exception.code, 3)

    # ---------------------------------------------------------------- 4. values
    def test_T30_missing_score_quarantines_and_refuses_with_report(self):
        fx = self.fixture("t30")
        fx.set("2012_03_KC_NO", home_score="")
        report = fx.dir / "report.json"
        r, out = fx.build(None, "--report", report)
        self.assertRefused(r, 3, "2012_03_KC_NO: Q1_MISSING_SCORE")
        self.assertFalse(out.exists())
        rows = {d["source_key"]: d for d in json.loads(report.read_text())["rows"]}
        self.assertEqual(rows["2012_03_KC_NO"]["disposition"], F2.Q1)
        self.assertFalse(rows["2012_03_KC_NO"]["approved_quarantine"])

    def test_T31_home_away_and_score_checks(self):
        fx = self.fixture("t31a")
        fx.set("2011_02_KC_DET", home_team="KC", game_id="2011_02_KC_KC")
        r, _ = fx.build()
        self.assertRefused(r, 3, "Q2_INVALID_VALUE")
        fx = self.fixture("t31b")
        fx.set("2011_02_KC_DET", result="1")
        r, _ = fx.build()
        self.assertRefused(r, 3, "score-difference check failed")
        for g in self.games:
            self.assertNotEqual(g["home"]["franchise_id"], g["away"]["franchise_id"])

    def test_T32_postseason_classification(self):
        cfg = json.loads(CONFIG.read_text("utf-8"))
        for s in range(1999, 2026):
            post = [g for g in self.games if g["season"] == s and g["game_type"] != "REG"]
            teams = {g[x]["franchise_id"] for g in post for x in ("home", "away")}
            self.assertEqual(len(teams), F2.structure_for(cfg, s)["playoff_teams"], s)
            self.assertTrue(all(18 <= g["week"] <= 22 for g in post))
        fx = self.fixture("t32")
        sb = list(next(r for r in fx.rows if r[1] == "2010" and r[2] == "SB"))
        sb[fx.col("away_team")], sb[fx.col("home_team")] = sb[fx.col("home_team")], sb[fx.col("away_team")]
        sb[fx.col("away_score")], sb[fx.col("home_score")] = sb[fx.col("home_score")], sb[fx.col("away_score")]
        sb[fx.col("result")] = str(-int(sb[fx.col("result")]))
        sb[0] = f"2010_{int(sb[fx.col('week')]):02d}_{sb[fx.col('away_team')]}_{sb[fx.col('home_team')]}"
        fx.rows.append(sb)
        r, _ = fx.build()
        self.assertRefused(r, 3, "Q6_IMPOSSIBLE")

    def test_T33_ties(self):
        ties = [g for g in self.games if g["home"]["score"] == g["away"]["score"]]
        self.assertEqual(len(ties), 15)
        self.assertTrue(all(g["game_type"] == "REG" and g["overtime"] for g in ties))
        fx = self.fixture("t33")
        key = next(r[0] for r in fx.rows if r[1] == "2015" and r[2] == "DIV")
        r0 = fx.find(key)
        fx.set(key, home_score=r0[fx.col("away_score")], result="0",
               total=str(2 * int(r0[fx.col("away_score")])))
        r, _ = fx.build()
        self.assertRefused(r, 3, "postseason game recorded as a tie")

    def test_T34_overtime(self):
        self.assertEqual(sum(g["overtime"] for g in self.games), 443)
        self.assertEqual(sum(g["overtime"] for g in self.games if g["game_type"] != "REG"), 28)

    def test_T35_neutral_site(self):
        self.assertEqual(sum(g["neutral_site"] for g in self.games), 94)
        self.assertTrue(all(g["neutral_site"] for g in self.games if g["game_type"] == "SB"))
        g = next(g for g in self.games if g["source_ref"]["key"] == "2024_19_MIN_LA")
        self.assertTrue(g["neutral_site"])
        self.assertEqual((g["home"]["franchise_id"], g["away"]["franchise_id"]), ("fr_lar", "fr_min"))

    def test_T36_week_and_date_rules(self):
        fx = self.fixture("t36a")
        fx.set("2003_05_NO_CAR", week="25", game_id="2003_25_NO_CAR")
        r, _ = fx.build()
        self.assertRefused(r, 3, "regular-season week 25")
        fx = self.fixture("t36b")
        fx.set("2003_05_NO_CAR", gameday="2003-07-04")
        r, _ = fx.build()
        self.assertRefused(r, 3, "outside Aug 1 2003")

    # ---------------------------------------------------------------- 5. mapping
    def test_T40_every_code_season_maps_and_unmapped_refuses(self):
        rows = self.mapping["code_seasons"]
        self.assertEqual(len(rows), 861)
        self.assertTrue(all(r["outcome"] == "RESOLVED" for r in rows))
        self.assertEqual(self.mapping["unused_map_rows"], [])
        self.assertEqual(len({r["source_code"] for r in rows}), 35)
        fx = self.fixture("t40")
        fx.set("2004_07_DET_NYG", home_team="XYZ", game_id="2004_07_DET_XYZ")
        r, _ = fx.build()
        self.assertRefused(r, 3, "Q3_UNMAPPED_CODE")

    def test_T41_map_overlap_refuses(self):
        fx = self.fixture("t41")
        fx.map_text += "nflverse_games,ARI,2010,2012,fr_ari,Arizona,A,proposed\n"
        r, _ = fx.build()
        self.assertRefused(r, 3, "overlapping rows for 'ARI'")

    def test_T42_identity_must_be_unique(self):
        ids = [{"identity_id": "a", "franchise_id": "f", "first_season": 2000, "last_season": None, "location_name": "X", "verification": "v"},
               {"identity_id": "b", "franchise_id": "f", "first_season": 2005, "last_season": 2010, "location_name": "X", "verification": "v"}]
        self.assertEqual(F2.resolve_identity(ids, "f", 2007), (None, 2))
        self.assertEqual(F2.resolve_identity(ids, "f", 1999), (None, 0))
        self.assertEqual(F2.resolve_identity(ids, "f", 2003)[0]["identity_id"], "a")
        seed = {"franchises": [{"franchise_id": "f", "first_nfl_season": 1990, "last_season": None}],
                "identities": ids, "merged_seasons": []}
        mapper = F2.Mapper([{"source": "nflverse_games", "source_code": "FF", "first_season": "1999", "last_season": "2025",
                             "franchise_id": "f", "expected_location": "X"}], seed)
        self.assertEqual(mapper.resolve("FF", 2007)[0], F2.Q4)
        self.assertEqual(mapper.resolve("FF", 2003)[0], "ok")

    def test_T43_location_cross_check_refuses(self):
        fx = self.fixture("t43")
        fx.map_text = fx.map_text.replace("STL,1999,2015,fr_lar,St. Louis", "STL,1999,2015,fr_lar,Los Angeles")
        r, _ = fx.build()
        self.assertRefused(r, 3, "M-5")
        fx = self.fixture("t43b")  # HOU mapped to the Oilers franchise is caught only by location
        fx.map_text = fx.map_text.replace("HOU,2002,2025,fr_hou", "HOU,2002,2025,fr_ten")
        r, _ = fx.build()
        self.assertRefused(r, 3, "M-5")

    def ident(self, fid, season):
        return {g[s]["identity_id"] for g in self.games if g["season"] == season for s in ("home", "away") if g[s]["franchise_id"] == fid}

    def test_T44_relocation_continuity(self):
        for fid, a, b, ia, ib in (("fr_lar", 2015, 2016, "id_lar_03", "id_lar_04"),
                                  ("fr_lac", 2016, 2017, "id_lac_02", "id_lac_03"),
                                  ("fr_lv", 2019, 2020, "id_lv_03", "id_lv_04")):
            self.assertEqual(self.ident(fid, a), {ia})
            self.assertEqual(self.ident(fid, b), {ib})

    def test_T45_washington_identities(self):
        self.assertEqual(self.ident("fr_was", 2019), {"id_was_03"})
        self.assertEqual(self.ident("fr_was", 2020), {"id_was_04"})
        self.assertEqual(self.ident("fr_was", 2021), {"id_was_04"})
        self.assertEqual(self.ident("fr_was", 2022), {"id_was_05"})

    def test_T46_hou_ten_cle_bal(self):
        hou_seasons = {g["season"] for g in self.games for s in ("home", "away") if g[s]["franchise_id"] == "fr_hou"}
        self.assertEqual(min(hou_seasons), 2002)
        self.assertEqual(self.ident("fr_ten", 1999), {"id_ten_03"})
        self.assertEqual(self.ident("fr_cle", 1999), {"id_cle_01"})
        self.assertEqual(self.ident("fr_bal", 1999), {"id_bal_01"})
        self.assertEqual(len({g[s]["franchise_id"] for g in self.games for s in ("home", "away")}), 32)

    def test_T47_no_source_codes_in_browser_files(self):
        codes = {r["source_code"] for r in self.mapping["code_seasons"]}

        def walk(o, inside_ref=False):
            if isinstance(o, dict):
                for k, v in o.items():
                    self.assertNotIn(k, {"home_team", "away_team", "source_code", "team"})
                    yield from walk(v, inside_ref or k == "source_ref")
            elif isinstance(o, list):
                for v in o:
                    yield from walk(v, inside_ref)
            elif isinstance(o, str) and not inside_ref:
                yield o
        for name, body in self.files.items():
            if BROWSER_FILES.match(name):
                for value in walk(json.loads(body)):
                    self.assertNotIn(value, codes, name)

    # ---------------------------------------------------------------- 6. derived records
    def test_T50_records_match_independent_recount(self):
        want = defaultdict(lambda: [0, 0, 0, 0, 0])
        for g in self.games:
            for me, op in (("home", "away"), ("away", "home")):
                k = f"{g['season']}-{g[me]['franchise_id']}"
                a, b = g[me]["score"], g[op]["score"]
                if g["game_type"] == "REG":
                    want[k][0 if a > b else 1 if a < b else 2] += 1
                else:
                    want[k][3 if a > b else 4] += 1
        self.assertEqual(set(want), set(self.rec))
        for k, (w, l, t, pw, pl) in want.items():
            r = self.rec[k]
            self.assertEqual((r["regular_season"]["wins"], r["regular_season"]["losses"], r["regular_season"]["ties"]), (w, l, t), k)
            self.assertEqual((r["postseason"]["wins"], r["postseason"]["losses"]), (pw, pl), k)

    def test_T51_anchors(self):
        rs = lambda k: tuple(self.rec[k]["regular_season"][x] for x in ("wins", "losses", "ties"))
        self.assertEqual(rs("2007-fr_ne"), (16, 0, 0))
        self.assertEqual(rs("2008-fr_det"), (0, 16, 0))
        self.assertEqual(rs("2017-fr_cle"), (0, 16, 0))
        self.assertEqual(rs("2025-fr_gb"), (9, 7, 1))

    def test_T52_reconciliation_and_missing_game_refuses(self):
        self.assertEqual(len(self.records), 861)
        short = sorted(r["record_id"] for r in self.records if r["regular_season"]["games"] != r["expected_regular_season_games"])
        self.assertEqual(short, ["2022-fr_buf", "2022-fr_cin"])
        for s in range(1999, 2026):
            rs = [r["regular_season"] for r in self.records if r["season"] == s]
            self.assertEqual(sum(x["wins"] for x in rs), sum(x["losses"] for x in rs))
        fx = self.fixture("t52")
        fx.rows.remove(fx.find("2015_10_DET_GB"))
        r, _ = fx.build()
        self.assertRefused(r, 3, "R-2")

    def test_T53_2022_note_reuses_seed_text(self):
        seasons = {s["season_id"]: s for s in json.loads(self.files["seasons.json"])["records"]}
        self.assertIn("no contest", seasons["NFL-2022"]["schedule_note"])
        for k in ("2022-fr_buf", "2022-fr_cin"):
            r = self.rec[k]
            self.assertEqual(r["status"], "complete_with_note")
            self.assertEqual(r["regular_season"]["games"], 16)
            self.assertEqual(r["note_ref"], {"id": "E-2022-01", "season_id": "NFL-2022", "field": "schedule_note"})
        self.assertEqual(Counter(r["status"] for r in self.records), {"complete": 859, "complete_with_note": 2})

    def test_T54_approved_quarantine_withholds_records(self):
        fx = self.fixture("t54")
        key = "2024_05_CLE_WAS"
        fx.set(key, home_score="")
        fx.exceptions["approved_quarantines"] = [{"source_key": key, "disposition": F2.Q1, "reason": "test fixture"}]
        r, out = fx.build()
        self.assertEqual(r.returncode, 0, r.stderr)
        m = json.loads((out / "manifest.json").read_text())
        self.assertEqual(m["counts"]["games"], 7275)
        self.assertEqual(m["f2_config"]["approved_quarantines"], 1)
        self.assertEqual(m["counts"]["team_season_records_withheld"], 2)
        recs = {x["record_id"]: x for x in json.loads((out / "team_season_records.json").read_text())["records"]}
        for k in ("2024-fr_cle", "2024-fr_was"):
            self.assertEqual(recs[k]["status"], "withheld")
            self.assertIsNone(recs[k]["regular_season"])
            self.assertIn(key, recs[k]["withheld_reason"])
        self.assertNotIn(key, (out / "games/2024.json").read_text())

    def test_T55_postseason_never_added_to_regular_season(self):
        for r in self.records:
            self.assertEqual(r["regular_season"]["games"] + r["postseason"]["games"],
                             sum(1 for g in self.games if g["season"] == r["season"]
                                 and r["franchise_id"] in (g["home"]["franchise_id"], g["away"]["franchise_id"])))
            self.assertLessEqual(r["regular_season"]["games"], r["expected_regular_season_games"])

    def test_T56_stale_exception_refuses(self):
        fx = self.fixture("t56")
        fx.exceptions["approved_quarantines"] = [{"source_key": "2010_01_MIA_BUF", "disposition": F2.Q1, "reason": "stale"}]
        r, _ = fx.build()
        self.assertRefused(r, 3, "match no quarantined row")

    # ---------------------------------------------------------------- 7. determinism, isolation, regression
    def test_T61_determinism(self):
        out2 = self.tmp / "again"
        r = run("--source", SEEDS, "--games", GAMES, "--out", out2)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(tree(out2), self.files)
        fx = self.fixture("t61")
        random.Random(7).shuffle(fx.rows)
        r, out = fx.build(update_slice=False)
        self.assertEqual(r.returncode, 0, r.stderr)
        shuffled = tree(out)
        for name in self.files:
            if name != "manifest.json":
                self.assertEqual(shuffled[name], self.files[name], name)
        self.assertEqual(json.loads(shuffled["manifest.json"])["build_id"], self.manifest["build_id"])

    def test_T62_f1_outputs_byte_identical(self):
        plain = self.tmp / "plain"
        r = run("--source", SEEDS, "--out", plain)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn(F15_BUILD_ID, r.stdout)
        p = tree(plain)
        self.assertEqual(sorted(p), ["franchises.json", "identities.json", "leagues.json", "manifest.json", "merged_seasons.json", "seasons.json"])
        for name in p:
            if name != "manifest.json":
                self.assertEqual(p[name], self.files[name], name)
        pm = json.loads(p["manifest.json"])
        self.assertEqual((pm["builder"]["milestone"], pm["classes"]), ("F1", ["curated"]))
        self.assertEqual(self.manifest["capabilities"], pm["capabilities"])  # F2.1 enables nothing

    def test_T63_atomic_and_check(self):
        out = self.tmp / "atomic"
        self.assertEqual(run("--source", SEEDS, "--games", GAMES, "--out", out).returncode, 0)
        before = tree(out)
        bad = self.tmp / "t63.csv"
        bad.write_bytes(Path(GAMES).read_bytes()[:-10])
        self.assertEqual(run("--source", SEEDS, "--games", bad, "--out", out).returncode, 2)
        self.assertEqual(tree(out), before)
        chk = self.tmp / "check_only"
        r = run("--source", SEEDS, "--games", GAMES, "--out", chk, "--check")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn(self.manifest["build_id"], r.stdout)
        self.assertFalse(chk.exists())

    def test_T70_output_guards(self):
        cases = [("--games", GAMES), ("--games", GAMES, "--out", FRONTEND / "data" / "snapshot"),
                 ("--games", GAMES, "--out", FRONTEND / "data" / "snapshot" / "sub"),
                 ("--games", GAMES, "--out", FRONTEND / "data" / "mock"), ("--out", FRONTEND / "data" / "mock"),
                 ("--out", FRONTEND / "data" / "mock" / "x"),
                 ("--games", GAMES, "--out", self.tmp / "g70", "--report", FRONTEND / "data" / "mock" / "r.json")]
        for args in cases:
            with self.subTest(args=[str(a) for a in args]):
                self.assertRefused(run("--source", SEEDS, *args), 4)
        self.assertFalse((FRONTEND / "data" / "mock" / "x").exists())

    def test_T72_report_into_new_folder(self):
        report = self.tmp / "t72" / "nested" / "report.json"
        r = run("--source", SEEDS, "--games", GAMES, "--out", self.tmp / "t72_out", "--report", report)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(report.read_bytes(), self.files["audit/games_dispositions.json"])
        chk = self.tmp / "t72c" / "report.json"
        r = run("--source", SEEDS, "--games", GAMES, "--out", self.tmp / "t72c_out", "--report", chk, "--check")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertFalse(chk.exists())  # --check writes nothing, report included

    def test_T71_version_a_untouched(self):
        sums = {}
        for line in (FRONTEND / "SHA256SUMS").read_text().splitlines():
            h, name = line.split(None, 1)
            sums[name.strip()] = h
        mock = sorted(p for p in (FRONTEND / "data" / "mock").iterdir())
        self.assertEqual(len(mock), 7)
        for p in mock:
            self.assertEqual(sha(p.read_bytes()), sums[f"data/mock/{p.name}"], p.name)
            self.assertNotIn(b"fr_", p.read_bytes())  # no real franchise ids in Version A
        self.assertFalse(any(p.name.startswith("games") for p in mock))


if __name__ == "__main__":
    unittest.main()
