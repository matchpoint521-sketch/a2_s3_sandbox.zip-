// No betting fields, no database references, no external network URLs.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { FRONTEND } from './helpers/node-loader.mjs';
import { walk, rel, read } from './helpers/files.mjs';

const BETTING = /moneyline|spread_line|_odds\b|total_line|over_odds|under_odds|\bwager|\bsportsbook/i;
const DATABASE = /postgres|psql|pg_dump|:5432|velora_nfl_dev|velora_nfl_test|tipoff_|matchpoint_db/i;
const URL_RE = /\bhttps?:\/\/[^\s'"`)]+/gi;

const code = [
  ...walk(path.join(FRONTEND, 'src')), ...walk(path.join(FRONTEND, 'providers')), ...walk(path.join(FRONTEND, 'entries')),
  ...['index.html', 'foundation.html', 'validation.html'].map((f) => path.join(FRONTEND, f)),
];
const data = [...walk(path.join(FRONTEND, 'data/mock'), ['.json']), ...walk(path.join(FRONTEND, 'data/snapshot'), ['.json'])];

test('no betting vocabulary in code or data', () => {
  for (const f of [...code, ...data]) assert.ok(!BETTING.test(read(f)), `${rel(f)} contains betting vocabulary`);
});

test('no database references in browser code or data', () => {
  for (const f of [...code, ...data]) assert.ok(!DATABASE.test(read(f)), `${rel(f)} references a database`);
});

test('browser code makes no requests to external URLs', () => {
  for (const f of code) {
    const urls = (read(f).match(URL_RE) ?? []);
    assert.deepEqual(urls, [], `${rel(f)} contains ${urls.join(', ')}`);
  }
});

test('data files carry no URL schemes (references stay as plain text)', () => {
  for (const f of data) assert.deepEqual(read(f).match(URL_RE) ?? [], [], rel(f));
});

test('HTML entries set a restrictive content security policy', () => {
  for (const f of ['foundation.html', 'validation.html']) {
    const html = read(path.join(FRONTEND, f));
    assert.match(html, /Content-Security-Policy" content="default-src 'self'/);
    assert.match(html, /connect-src 'self'/);
  }
});

test('no innerHTML or eval in browser code', () => {
  for (const f of code.filter((x) => x.endsWith('.js'))) assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|\beval\(|new Function\(/.test(read(f)), rel(f));
});
