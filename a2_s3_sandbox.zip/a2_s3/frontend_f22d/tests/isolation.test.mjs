// Proves Version A and Version B cannot reach each other's provider or data.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { FRONTEND } from './helpers/node-loader.mjs';
import { walk, rel, read } from './helpers/files.mjs';

const IMPORT_RE = /(?:import|export)\s[^'"]*?from\s*['"]([^'"]+)['"]|import\s*\(\s*['"]([^'"]+)['"]\s*\)|import\s*['"]([^'"]+)['"]/g;

function importsOf(file) {
  const out = [];
  for (const m of read(file).matchAll(IMPORT_RE)) out.push(path.resolve(path.dirname(file), m[1] ?? m[2] ?? m[3]));
  return out;
}

function graph(entry) {
  const seen = new Set();
  const stack = [path.join(FRONTEND, entry)];
  while (stack.length) {
    const f = stack.pop();
    if (seen.has(f)) continue;
    seen.add(f);
    stack.push(...importsOf(f));
  }
  return [...seen].map(rel).sort();
}

const fileText = (r) => read(path.join(FRONTEND, r));

test('foundation entry reaches the mock provider and never the snapshot', () => {
  const g = graph('entries/foundation.js');
  assert.ok(g.includes('providers/mock/index.js'));
  assert.ok(!g.some((f) => f.startsWith('providers/snapshot')), g.join('\n'));
  for (const f of g) assert.ok(!fileText(f).includes('data/snapshot'), `${f} mentions data/snapshot`);
});

test('validation entry reaches the snapshot provider and never the mock', () => {
  const g = graph('entries/validation.js');
  assert.ok(g.includes('providers/snapshot/index.js'));
  assert.ok(!g.some((f) => f.startsWith('providers/mock')), g.join('\n'));
  for (const f of g) assert.ok(!fileText(f).includes('data/mock'), `${f} mentions data/mock`);
});

test('both versions share the same app code', () => {
  const shared = (g) => g.filter((f) => f.startsWith('src/'));
  assert.deepEqual(shared(graph('entries/foundation.js')), shared(graph('entries/validation.js')));
  assert.ok(shared(graph('entries/foundation.js')).length > 20);
});

test('no page, component or core module imports a provider', () => {
  for (const f of walk(path.join(FRONTEND, 'src'), ['.js'])) {
    for (const imp of importsOf(f)) assert.ok(!rel(imp).startsWith('providers/'), `${rel(f)} imports ${rel(imp)}`);
    assert.ok(!/data\/(mock|snapshot)/.test(read(f)), `${rel(f)} names a data folder`);
  }
});

test('each HTML entry loads exactly its own entry script', () => {
  const scripts = (html) => [...fileText(html).matchAll(/<script[^>]*src="([^"]+)"/g)].map((m) => m[1]);
  assert.deepEqual(scripts('foundation.html'), ['entries/foundation.js']);
  assert.deepEqual(scripts('validation.html'), ['entries/validation.js']);
  assert.deepEqual(scripts('index.html'), []);
});

test('every import resolves to an existing file', () => {
  for (const f of [...walk(path.join(FRONTEND, 'src'), ['.js']), ...walk(path.join(FRONTEND, 'providers'), ['.js']), ...walk(path.join(FRONTEND, 'entries'), ['.js'])]) {
    for (const imp of importsOf(f)) assert.doesNotThrow(() => read(imp), `${rel(f)} → ${rel(imp)}`);
  }
});

test('every data page reads its provider, so Version B fails closed everywhere', () => {
  for (const f of walk(path.join(FRONTEND, 'src/pages'), ['.js'])) {
    const name = path.basename(f);
    if (['index.js', 'common.js', 'not-found.js'].includes(name)) continue;
    assert.match(read(f), /provider\.(get|list|search)\w*\(/, `${name} renders without reading the provider`);
  }
});
