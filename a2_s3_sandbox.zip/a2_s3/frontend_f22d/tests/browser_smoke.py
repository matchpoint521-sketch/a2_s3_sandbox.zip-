"""Optional browser smoke test (not part of the required suite).

Needs Python Playwright with Chromium. Serves the frontend on 127.0.0.1 with the
standard library server, opens every route in both versions, and checks:
  - each page renders an h1 and no uncaught errors,
  - Version A never requests data/snapshot, Version B never requests data/mock,
  - no request leaves 127.0.0.1,
  - Version B without a snapshot shows the not-built state on every route,
  - reduced motion turns the field sweep off,
  - (F1.5) each section sets its scene, the self-hosted fonts load, and the
    decorative backdrop is hidden from assistive technology.
  - (F2.2d-A2, Version B) real game and team-season pages: expected h1 per state,
    no record numbers where there is no game data, team-season -> game -> team-season
    navigation, and focus on the h1 after each navigation; at 1280 px and 375 px.
Without a built snapshot, the Version B passes that need it are reported as
explicit SKIP lines (not failures); the dedicated no-snapshot pass still runs.
Optional: set AXE_JS to a local axe.min.js to run an accessibility scan.
Usage: python3 tests/browser_smoke.py [--screens <folder>]
"""
import argparse
import functools
import http.server
import os
import shutil
import sys
import tempfile
import threading
from pathlib import Path

FRONTEND = Path(__file__).resolve().parent.parent
ROUTES = ["#/", "#/compare", "#/compare/teams?a=fr_ari", "#/compare/seasons", "#/compare/players", "#/teams",
          "#/teams/{f}", "#/teams/{f}/{y}", "#/players", "#/players/dp_001", "#/seasons", "#/seasons/{l}/{y2}",
          "#/games/1999_01_MIN_ATL", "#/search?q={q}", "#/data", "#/nope"]
PARAMS = {"foundation": dict(f="dm_lan", y=1990, l="DEMO", y2=1974, q="redmoor"),
          "validation": dict(f="fr_ari", y=1944, l="AFL", y2=1965, q="cardinals")}
# F2.2d-A2 (Version B only): route -> (expected h1, page has game data). Record-shaped text
# ("13–3", "Wins 1") must appear only where the page has game data.
A2_ROUTES = {
    "#/games/g_d34106702f37": ("Buffalo Bills at Los Angeles Rams", True),
    "#/games/g_443cce357e60": (None, True), "#/games/g_c7e28c31b408": (None, True),
    "#/games/g_74808b6d42d1": (None, True), "#/games/g_becece5fd573": (None, True),
    "#/games/g_987fe5b35110": (None, True), "#/games/g_6864cb3a06bd": (None, True),
    "#/games/g_d1a94ba71229": (None, True),
    "#/games/1999_01_MIN_ATL": ("Game not found", False), "#/games/g_000000000000": ("Game not found", False),
    "#/teams/fr_buf/2022": ("Buffalo Bills, 2022", True), "#/teams/fr_cin/2022": ("Cincinnati Bengals, 2022", True),
    "#/teams/fr_lar/2015": ("St. Louis Rams, 2015", True), "#/teams/fr_lar/2016": ("Los Angeles Rams, 2016", True),
    "#/teams/fr_ten/1999": ("Tennessee Titans, 1999", True), "#/teams/fr_ten/1998": ("Tennessee Oilers, 1998", False),
    "#/teams/fr_cle/1997": ("Cleveland Browns, 1997", False), "#/teams/fr_buf/2026": ("Buffalo Bills, 2026", False),
    "#/teams/fr_hou/2000": ("Houston Texans, 2000", False), "#/teams/fr_buf/2027": ("Season not found", False),
    "#/seasons/NFL/2022": ("National Football League, 2022", False),
}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def serve(root):
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=str(root)))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}/"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--screens")
    args = ap.parse_args()
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("SKIP: Playwright is not installed")
        return 0
    axe = Path(os.environ["AXE_JS"]).read_text() if os.environ.get("AXE_JS") else None
    results, failures, skips = [], [], []

    def check(ok, msg):
        results.append((ok, msg))
        if not ok:
            failures.append(msg)

    with sync_playwright() as p:
        browser = p.chromium.launch()

        def visit(base, version, route, ctx_opts=None, shot=None):
            ctx = browser.new_context(bypass_csp=bool(axe), **(ctx_opts or {}))  # bypass only so the scanner can be injected
            page = ctx.new_page()
            reqs, errors = [], []
            page.on("request", lambda r: reqs.append(r.url))
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" and "Failed to load resource" not in m.text else None)
            page.goto(f"{base}{version}.html{route}")
            page.wait_for_function("() => !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
            page.wait_for_timeout(250)
            h1 = page.inner_text("main h1")
            text = page.inner_text("body")
            import re as _re
            stray = _re.findall(r"\b(null|undefined|NaN|\[object Object\])\b", text)
            if stray:
                errors.append(f"stray text {stray[:3]}")
            width = page.evaluate("document.documentElement.scrollWidth")
            vw = page.viewport_size["width"]
            if width > vw:
                errors.append(f"horizontal overflow {width}px > {vw}px")
            violations = []
            if axe:
                page.add_script_tag(content=axe)
                violations = page.evaluate("async () => (await axe.run(document, {resultTypes:['violations']})).violations.map(v => v.id + ':' + v.nodes.length)")
            if shot:
                page.screenshot(path=shot, full_page=True)
            ctx.close()
            return h1, reqs, errors, violations

        snapshot_built = (FRONTEND / "data" / "snapshot" / "manifest.json").exists()
        versions = ("foundation", "validation") if snapshot_built else ("foundation",)
        if not snapshot_built:
            skips.append("validation: all-route pass at 1280 px (16 routes) - snapshot not built")
            skips.append("validation: all-route pass at 375 px (16 routes) - snapshot not built")
            skips.append("validation: mobile team screenshot - snapshot not built")
        httpd, base = serve(FRONTEND)
        for version in versions:
            other = "data/snapshot" if version == "foundation" else "data/mock"
            for i, tmpl in enumerate(ROUTES):
                route = tmpl.format(**PARAMS[version])
                shot = None
                if args.screens:
                    shot = str(Path(args.screens) / f"{version}_{i:02d}.png")
                h1, reqs, errors, violations = visit(base, version, route, shot=shot)
                tag = f"{version} {route}"
                check(bool(h1.strip()), f"{tag}: h1 '{h1}'")
                check(not errors, f"{tag}: no page errors {errors}")
                check(not any(other in u for u in reqs), f"{tag}: never requests {other}")
                check(all(u.startswith(base) for u in reqs), f"{tag}: all requests local")
                if axe:
                    check(not violations, f"{tag}: axe violations {violations}")
        # every route at 375 px
        for version in versions:
            for tmpl in ROUTES:
                route = tmpl.format(**PARAMS[version])
                h1, reqs, errors, _ = visit(base, version, route, {"viewport": {"width": 375, "height": 812}})
                check(not errors, f"{version} {route} @375px: {errors}")
        # F2.2d-A2: game and team-season pages (Version B) at 1280 px and 375 px.
        import re as _re2
        record_shape = _re2.compile(r"(?<!\d)\d{1,2}\u2013\d{1,2}(?!\d)|Wins \d|No postseason games")
        if "validation" in versions:
            for width in (1280, 375):
                for route, (want, has_data) in A2_ROUTES.items():
                    opts = {"viewport": {"width": width, "height": 900 if width == 1280 else 812}}
                    h1, reqs, errors, violations = visit(base, "validation", route, opts)
                    tag = f"A2 {route} @{width}px"
                    check(not errors, f"{tag}: no page errors {errors}")
                    if want:
                        check(h1.strip() == want, f"{tag}: h1 '{h1}' (expected '{want}')")
                    if axe:
                        check(not violations, f"{tag}: axe violations {violations}")
                    if not has_data:
                        ctx = browser.new_context(**opts)
                        page = ctx.new_page()
                        page.goto(f"{base}validation.html{route}")
                        page.wait_for_function("() => !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
                        body = page.inner_text("main")
                        ctx.close()
                        check(not record_shape.search(body), f"{tag}: no record numbers without game data")
            # navigation: team-season -> first game -> back to the same team-season; focus on the h1
            ctx = browser.new_context()
            page = ctx.new_page()
            page.goto(f"{base}validation.html#/teams/fr_buf/2022")
            page.wait_for_function("() => !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
            page.click("main a[href^='#/games/']")
            page.wait_for_function("() => location.hash.startsWith('#/games/') && !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
            page.wait_for_timeout(150)
            check(page.evaluate("document.activeElement === document.querySelector('main h1')"), "A2 nav: focus on the game h1")
            page.click("main a[href='#/teams/fr_buf/2022']")
            page.wait_for_function("() => location.hash === '#/teams/fr_buf/2022' && !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
            page.wait_for_timeout(150)
            check(page.inner_text("main h1") == "Buffalo Bills, 2022", "A2 nav: game links back to the team-season")
            check(page.evaluate("document.activeElement === document.querySelector('main h1')"), "A2 nav: focus on the team-season h1")
            ctx.close()
        else:
            skips.append("A2: game and team-season pages - snapshot not built")
        # mobile screenshots and reduced motion
        if args.screens:
            for version in versions:
                route = "#/teams/" + PARAMS[version]["f"]
                visit(base, version, route, {"viewport": {"width": 375, "height": 812}, "device_scale_factor": 2},
                      shot=str(Path(args.screens) / f"{version}_mobile_team.png"))
                for i in (0, 1, 5, 8, 10):  # the five sections on a phone
                    visit(base, version, ROUTES[i].format(**PARAMS[version]), {"viewport": {"width": 375, "height": 812}, "device_scale_factor": 2},
                          shot=str(Path(args.screens) / f"{version}_mobile_{i:02d}.png"))
        # F1.5: scenes, fonts and the decorative backdrop (Version A).
        scenes = {"#/": "explore", "#/compare": "compare", "#/teams": "teams", "#/players": "players", "#/seasons": "seasons",
                  "#/data": "plain"}
        ctx = browser.new_context()
        page = ctx.new_page()
        for route, scene in scenes.items():
            page.goto(f"{base}foundation.html{route}")
            page.wait_for_function("() => !document.querySelector('main')?.hasAttribute('aria-busy') && document.querySelector('main h1')")
            got = page.evaluate("document.body.dataset.scene")
            check(got == scene, f"scene for {route} is '{scene}' ({got})")
        page.evaluate("document.fonts.ready")
        fonts = page.evaluate("""async () => { await document.fonts.ready;
          return [document.fonts.check('800 20px "Big Shoulders Display"'), document.fonts.check('400 16px "Atkinson Hyperlegible Next"'),
                  [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family + ' ' + f.weight)]; }""")
        check(fonts[0] and fonts[1] and len(fonts[2]) >= 2, f"self-hosted fonts load ({fonts[2]})")
        hidden = page.evaluate("document.querySelector('.backdrop')?.getAttribute('aria-hidden')")
        check(hidden == "true", f"backdrop is aria-hidden ({hidden})")
        ctx.close()

        ctx = browser.new_context(reduced_motion="reduce")
        page = ctx.new_page()
        page.goto(f"{base}foundation.html#/teams/dm_lan")
        page.wait_for_selector(".field__line")
        dur = page.evaluate("getComputedStyle(document.querySelector('.field__line')).transitionDuration")
        check(dur in ("0s", "0ms"), f"reduced motion disables the sweep (transition {dur})")
        page.keyboard.press("Tab")
        focused = page.evaluate("document.activeElement.className")
        check("skip-link" in focused, f"first Tab reaches the skip link ({focused})")
        ctx.close()
        httpd.shutdown()

        # Version B with no snapshot: copy the tree without data/snapshot.
        tmp = Path(tempfile.mkdtemp(prefix="velora-nosnap-"))
        try:
            shutil.copytree(FRONTEND, tmp / "fe", ignore=lambda d, names: [n for n in names if n == "__pycache__" or (n == "snapshot" and Path(d).name == "data")])
            httpd, base = serve(tmp / "fe")
            for i, tmpl in enumerate(ROUTES):
                route = tmpl.format(**PARAMS["validation"])
                shot = str(Path(args.screens) / f"validation_nosnapshot_{i:02d}.png") if args.screens and i in (0, 1, 5, 8, 10) else None
                h1, reqs, errors, _ = visit(base, "validation", route, shot=shot)
                ok = h1 == "Snapshot not built" or route == "#/nope"
                check(ok, f"no-snapshot {route}: h1 '{h1}'")
                check(not any("data/mock" in u for u in reqs), f"no-snapshot {route}: never requests data/mock")
            httpd.shutdown()
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        browser.close()

    for msg in skips:
        print("SKIP", msg)
    for ok, msg in results:
        if not ok:
            print("FAIL", msg)
    print(f"BROWSER SMOKE {'PASS' if not failures else 'FAIL'} {len(results) - len(failures)}/{len(results)}"
          + (f" ({len(skips)} SKIP groups)" if skips else ""))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
