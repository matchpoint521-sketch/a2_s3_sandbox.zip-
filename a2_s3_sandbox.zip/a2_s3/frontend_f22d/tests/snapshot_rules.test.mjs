// F2.2a negative controls for the snapshot rules (tests/helpers/snapshot-rules.mjs).
// Every case uses a small synthetic snapshot in a temporary folder; nothing is written
// inside the frontend. Each mutation is re-hashed unless the hash itself is under test,
// so a case passes only because the targeted rule catches it.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, existsSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { inspectSnapshot, buildIdOf } from './helpers/snapshot-rules.mjs';
import { writeFixture, writeFile, editJson, editManifest, rehash, readFixture } from './helpers/snapshot-fixtures.mjs';

const msgs = (dir) => inspectSnapshot(dir).map((p) => `${p.cat}: ${p.msg}`);
function rejects(dir, pattern) {
  const got = msgs(dir);
  assert.ok(got.some((x) => pattern.test(x)), `expected ${pattern} in:\n${got.join('\n') || '(no problems)'}`);
  rmSync(dir, { recursive: true, force: true });
}
function accepts(dir) {
  assert.deepEqual(msgs(dir), []);
  rmSync(dir, { recursive: true, force: true });
}

test('positive controls: F1 and F2.2 fixture layouts are accepted', () => {
  accepts(writeFixture());
  accepts(writeFixture({ games: true }));
});

test('missing file listed in the manifest is rejected', () => {
  const d = writeFixture({ games: true });
  rmSync(path.join(d, 'games/2002.json'));
  rejects(d, /^files: missing file listed in outputs: games\/2002\.json/);
});

test('missing required curated file is rejected even if unlisted', () => {
  const d = writeFixture();
  rmSync(path.join(d, 'leagues.json'));
  rehash(d, ['seasons.json', 'franchises.json', 'identities.json', 'merged_seasons.json']);
  rejects(d, /^files: required curated file not listed: leagues\.json/);
});

test('extra files are rejected: unlisted shard, non-JSON file, hidden file', () => {
  for (const [rel, body] of [['games/2003.json', '{}'], ['notes.txt', 'x'], ['.hidden.json', '{}'], ['games/.cache', 'x']]) {
    const d = writeFixture({ games: true });
    writeFile(d, rel, body);
    rejects(d, new RegExp(`^files: extra file not in manifest outputs: ${rel.replace(/\./g, '\\.')}`));
  }
});

test('only .DS_Store is ignored on disk', () => {
  const d = writeFixture();
  writeFile(d, '.DS_Store', 'finder');
  accepts(d);
});

test('audit files are rejected inside the served snapshot, listed or not', () => {
  const unlisted = writeFixture({ games: true });
  writeFile(unlisted, 'audit/games_dispositions.json', { records: [] });
  rejects(unlisted, /^files: audit file inside the served snapshot: audit\/games_dispositions\.json/);
  // F2.1 staging shape: audit files listed in outputs with correct hashes.
  const listed = writeFixture({ games: true });
  writeFile(listed, 'audit/mapping_report.json', { rows: [] });
  rehash(listed, [...Object.keys(readFixture(listed, 'manifest.json').outputs), 'audit/mapping_report.json']);
  rejects(listed, /^files: audit file listed in manifest outputs: audit\/mapping_report\.json/);
});

test('incorrect file or record class is rejected even with matching hashes', () => {
  const cases = [
    ['games/2001.json', (b) => { b.class = 'curated'; }, /labels: games\/2001\.json class curated, expected source/],
    ['games/2001.json', (b) => { b.records[0].class = 'demo'; }, /labels: games\/2001\.json\[0\] class demo, expected source/],
    ['team_season_records.json', (b) => { b.class = 'source'; }, /labels: team_season_records\.json class source, expected derived/],
    ['seasons.json', (b) => { b.class = 'demo'; }, /labels: seasons\.json class demo, expected curated/],
    ['franchises.json', (b) => { b.records[1].class = 'derived'; }, /labels: franchises\.json\[1\] class derived, expected curated/],
  ];
  for (const [rel, fn, pattern] of cases) {
    const d = writeFixture({ games: true });
    editJson(d, rel, fn);
    rehash(d);
    rejects(d, pattern);
  }
});

test('pending_review is mandatory on files and records', () => {
  for (const [rel, fn] of [['games/2002.json', (b) => { b.review_status = 'approved'; }], ['team_season_records.json', (b) => { delete b.records[0].review_status; }], ['identities.json', (b) => { b.records[0].review_status = null; }]]) {
    const d = writeFixture({ games: true });
    editJson(d, rel, fn);
    rehash(d);
    rejects(d, /^labels: .*review_status/);
  }
});

test('manifest classes must equal the classes present', () => {
  const d = writeFixture({ games: true });
  editManifest(d, (m) => { m.classes = ['curated']; });
  rejects(d, /^classes: manifest classes \[curated\] but files carry \[curated,derived,source\]/);
  const f1 = writeFixture();
  editManifest(f1, (m) => { m.classes = ['curated', 'source']; });
  rejects(f1, /^classes: /);
});

test('hash, record-count and build-id mismatches are rejected', () => {
  const h = writeFixture({ games: true });
  editJson(h, 'games/2001.json', (b) => { b.records[0].home.score = 11; });
  rejects(h, /^hash: sha256 mismatch: games\/2001\.json/);
  const c = writeFixture({ games: true });
  editManifest(c, (m) => { m.outputs['games/2001.json'].records = 2; m.build_id = buildIdOf(m.outputs); });
  rejects(c, /^hash: games\/2001\.json has 1 records, manifest says 2/);
  const b = writeFixture();
  editManifest(b, (m) => { m.build_id = '0'.repeat(64); });
  rejects(b, /^build: build_id does not match/);
});

test('unknown or unsafe output paths are rejected', () => {
  const u = writeFixture({ games: true });
  writeFile(u, 'head_to_head.json', { schema: 'velora-nfl-frontend/1', class: 'derived', review_status: 'pending_review', records: [] });
  rehash(u, [...Object.keys(readFixture(u, 'manifest.json').outputs), 'head_to_head.json']);
  rejects(u, /^files: unknown output path \(no rule\): head_to_head\.json/);
  const s = writeFixture();
  editManifest(s, (m) => { m.outputs['../escape.json'] = { sha256: '0', records: 0 }; m.build_id = buildIdOf(m.outputs); });
  rejects(s, /^files: unsafe or reserved output key: \.\.\/escape\.json/);
});

test('capabilities must match the layout and keep later features off', () => {
  const off = writeFixture({ games: true });
  editManifest(off, (m) => { m.capabilities.games = false; });
  rejects(off, /^capabilities: games is false but game files are present/);
  const on = writeFixture();
  editManifest(on, (m) => { m.capabilities.games = true; });
  rejects(on, /^capabilities: games is true but game files are absent/);
  for (const k of ['headToHead', 'compare', 'players']) {
    const d = writeFixture({ games: true });
    editManifest(d, (m) => { m.capabilities[k] = true; });
    rejects(d, new RegExp(`^capabilities: ${k} must be false`));
  }
  const extra = writeFixture();
  editManifest(extra, (m) => { m.capabilities.betting = false; });
  rejects(extra, /^capabilities: capability keys/);
});

test('a partial game layout is rejected', () => {
  const d = writeFixture({ games: true });
  rmSync(path.join(d, 'games/index.json'));
  rehash(d, Object.keys(readFixture(d, 'manifest.json').outputs).filter((k) => k !== 'games/index.json'));
  rejects(d, /^games: game build without games\/index\.json/);
});

test('game integrity: shard season, index, coverage, duplicate ids, records label', () => {
  const cases = [
    ['games/2002.json', (b) => { b.records[0].season = 2001; }, /^games: games\/2002\.json: game g_000000000002 has season 2001/],
    ['games/index.json', (b) => { b.records.pop(); }, /^games: game g_000000000002 is missing from the index/],
    ['games/index.json', (b) => { b.records[0].season = 2002; }, /^games: index entry g_000000000001→2002/],
    ['games/2002.json', (b) => { b.records[0].game_id = 'g_000000000001'; }, /^games: duplicate game id/],
    ['games/2001.json', (b) => { b.records[0].game_id = 'dg_2001_001'; }, /^games: games\/2001\.json: bad game id dg_2001_001/],
    ['team_season_records.json', (b) => { b.label = 'Team records.'; }, /^games: records label lacks/],
  ];
  for (const [rel, fn, pattern] of cases) {
    const d = writeFixture({ games: true });
    editJson(d, rel, fn);
    rehash(d);
    rejects(d, pattern);
  }
  const gap = writeFixture({ games: true });
  editManifest(gap, (m) => { m.coverage.games.to = 2003; });
  rejects(gap, /^games: shards do not equal coverage 2001–2003/);
  const stale = writeFixture();
  editManifest(stale, (m) => { m.coverage.games = { league: 'NFL', from: 2001, to: 2002 }; m.counts.games = 0; });
  rejects(stale, /^games: (coverage\.games|counts\.games) present without game files/);
});

test('inputs must equal the pins; the games CSV only in a game build', () => {
  const seed = writeFixture();
  editManifest(seed, (m) => { m.inputs['season_seed.csv'].sha256 = 'f'.repeat(64); });
  rejects(seed, /^inputs: seed pin differs: season_seed\.csv/);
  const unpinned = writeFixture({ games: true });
  editManifest(unpinned, (m) => { m.inputs['other.csv'] = { sha256: '0', rows: 1 }; });
  rejects(unpinned, /^inputs: unpinned input: other\.csv/);
  const digest = writeFixture({ games: true });
  editManifest(digest, (m) => { const k = Object.keys(m.inputs).find((n) => n.includes('games')); m.inputs[k].slice_digest = '0'; });
  rejects(digest, /^inputs: games input differs from the F2\.1 pin/);
  const f1 = writeFixture({ games: true });
  editManifest(f1, (m) => { const k = Object.keys(m.inputs).find((n) => n.includes('games')); delete m.inputs[k]; });
  rejects(f1, /^inputs: game build without the pinned games input/);
});

test('Version A ids in Version B data are rejected', () => {
  const d = writeFixture({ games: true });
  editJson(d, 'franchises.json', (b) => { b.records[0].franchise_id = 'dm_lan'; });
  rehash(d);
  rejects(d, /^isolation: franchises\.json contains demonstration id dm_lan/);
});

// Optional real-data check: set VELORA_F21_STAGING to the F2.1 staging snapshot folder
// (the --out folder of the F2.1 staging build). Read only; copies go to a temp folder.
const STAGING = process.env.VELORA_F21_STAGING;
test('F2.1 staging output: rejected as served; accepted once audit is removed and games enabled', {
  skip: STAGING && existsSync(path.join(STAGING, 'manifest.json')) ? false : 'SKIP: set VELORA_F21_STAGING to the F2.1 staging snapshot folder',
}, () => {
  const asIs = msgs(STAGING);
  assert.ok(asIs.some((x) => /^files: audit file inside the served snapshot: audit\/games_dispositions\.json/.test(x)), asIs.join('\n'));
  assert.ok(asIs.some((x) => /^files: audit file listed in manifest outputs/.test(x)));
  assert.ok(asIs.some((x) => /^capabilities: games is false but game files are present/.test(x)));
  // Simulated F2.2 served layout: same game and record bytes, audit relocated, games on.
  const sim = path.join(mkdtempSync(path.join(tmpdir(), 'velora-f22a-sim-')), 'snapshot');
  cpSync(STAGING, sim, { recursive: true });
  rmSync(path.join(sim, 'audit'), { recursive: true });
  editManifest(sim, (m) => {
    for (const k of Object.keys(m.outputs)) if (k.startsWith('audit/')) delete m.outputs[k];
    m.capabilities.games = true;
    m.build_id = buildIdOf(m.outputs);
  });
  assert.deepEqual(msgs(sim), []);
  rmSync(path.dirname(sim), { recursive: true, force: true });
});
