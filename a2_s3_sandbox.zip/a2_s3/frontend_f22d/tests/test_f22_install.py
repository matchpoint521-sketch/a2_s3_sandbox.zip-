"""F2.2b tests for the snapshot install mode (tools/build_snapshot.py --install).

Standard library only. Needs the same two inputs as tests/test_f2_games.py:
  VELORA_SEED_SOURCE   folder holding the six curated seed CSVs (or a seed/ subfolder)
  VELORA_GAMES_SOURCE  the pinned nflverse games CSV (sha256 24d55c06…)
Without them every test reports SKIP.

Every build runs against a temporary copy of this frontend, so the real
frontend/data/snapshot is never written. Test ids: I-01 … I-13 (F2.2b, see
F22B_CHANGE_REPORT.md); they complement T-61, T-62, T-63 and T-70.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

FRONTEND = Path(__file__).resolve().parent.parent
SEEDS = os.environ.get("VELORA_SEED_SOURCE")
GAMES = os.environ.get("VELORA_GAMES_SOURCE")
SKIP_MSG = "SKIP: set VELORA_SEED_SOURCE (seed CSV folder) and VELORA_GAMES_SOURCE (pinned games CSV)"

F15_BUILD_ID = "50dfae255ff610ad738593fc8a98b131d209837c70ff59fd1d851e953b790c2a"
F21_STAGING_BUILD_ID = "dca7bad746883593fa059d0ebdad03076b277ce9b85de3116cf24a14d5419499"
F22_INSTALL_BUILD_ID = "5913437cb58123df413f4738967cdd9a57ee51d4fe4331856c1b371863101876"
CURATED = ["franchises.json", "identities.json", "leagues.json", "merged_seasons.json", "seasons.json"]
SERVED = sorted(CURATED + [f"games/{y}.json" for y in range(1999, 2026)] + ["games/index.json", "team_season_records.json"])
AUDIT = ["audit_manifest.json", "games_dispositions.json", "mapping_report.json"]
BETTING = re.compile(r"moneyline|spread_line|_odds\b|total_line|over_odds|under_odds|\bwager|\bsportsbook", re.I)
DATABASE = re.compile(r"postgres|psql|pg_dump|:5432|velora_nfl_dev|velora_nfl_test|tipoff_|matchpoint_db", re.I)
URL_RE = re.compile(r"\bhttps?://", re.I)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tree(folder):
    folder = Path(folder)
    return {p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob("*")) if p.is_file()}


def copy_frontend(dest):
    """Temporary frontend copy without any built snapshot or caches."""
    shutil.copytree(FRONTEND, dest, ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    shutil.rmtree(dest / "data" / "snapshot", ignore_errors=True)
    return dest


@unittest.skipUnless(SEEDS and GAMES, SKIP_MSG)
class F22Install(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp(prefix="velora-f22b-"))
        cls.fe = copy_frontend(cls.tmp / "frontend")
        cls.snap = cls.fe / "data" / "snapshot"
        cls.audit_dir = cls.tmp / "audit"
        r = cls.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", cls.audit_dir)
        assert r.returncode == 0, r.stderr
        cls.stdout = r.stdout
        cls.files = tree(cls.snap)
        cls.audit = tree(cls.audit_dir)
        cls.manifest = json.loads(cls.files["manifest.json"])
        r = cls.run_builder("--source", SEEDS, "--games", GAMES, "--out", cls.tmp / "staging")
        assert r.returncode == 0, r.stderr
        cls.staging = tree(cls.tmp / "staging")
        cls.staging_manifest = json.loads(cls.staging["manifest.json"])

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    @classmethod
    def run_builder(cls, *args, frontend=None):
        builder = (frontend or cls.fe) / "tools" / "build_snapshot.py"
        return subprocess.run([sys.executable, str(builder), *map(str, args)], capture_output=True, text=True)

    def assertRefused(self, result, code, text=None):
        self.assertEqual(result.returncode, code, result.stderr + result.stdout)
        if text:
            self.assertIn(text, result.stderr)

    # I-01 layout
    def test_I01_served_layout_is_exactly_the_approved_set(self):
        self.assertEqual(sorted(k for k in self.files if k != "manifest.json"), SERVED)
        self.assertFalse(any("audit" in k or "dispositions" in k or "mapping_report" in k for k in self.files))
        self.assertIn(f"SNAPSHOT OK build_id={F22_INSTALL_BUILD_ID}", self.stdout)

    # I-02 provenance: data bytes are the F2.1 staging bytes
    def test_I02_served_files_byte_identical_to_staging(self):
        self.assertEqual(self.staging_manifest["build_id"], F21_STAGING_BUILD_ID)
        for k in SERVED:
            self.assertEqual(self.files[k], self.staging[k], k)
        for k, v in self.manifest["outputs"].items():
            self.assertEqual(v, self.staging_manifest["outputs"][k], k)

    # I-03 manifest
    def test_I03_manifest(self):
        m, s = self.manifest, self.staging_manifest
        self.assertEqual(sorted(m["outputs"]), SERVED)
        for k, v in m["outputs"].items():
            self.assertEqual(v["sha256"], sha(self.files[k]), k)
            self.assertEqual(v["records"], len(json.loads(self.files[k])["records"]), k)
        bid = sha("".join(f"{k}:{v['sha256']}\n" for k, v in sorted(m["outputs"].items())).encode())
        self.assertEqual(m["build_id"], bid)
        self.assertEqual(m["build_id"], F22_INSTALL_BUILD_ID)
        self.assertEqual(m["builder"]["milestone"], "F2.2")
        self.assertEqual(m["provider"], "snapshot")
        self.assertEqual(m["classes"], ["curated", "derived", "source"])
        self.assertEqual(m["capabilities"], {**s["capabilities"], "games": True})
        for k in ("headToHead", "players", "playerStats", "statCoverage", "compare"):
            self.assertIs(m["capabilities"][k], False, k)
        self.assertEqual(m["derived_from"]["staging_build_id"], F21_STAGING_BUILD_ID)
        self.assertEqual(sorted(m["game_types"]), ["CON", "DIV", "REG", "SB", "WC"])
        self.assertTrue(m["f22_config"]["packaged_config"])
        self.assertTrue(m["authorization"].startswith(s["authorization"]))
        self.assertIn("F2.2b install mode authorized", m["authorization"])
        self.assertNotIn("staging build", m["build_kind"].split(".")[0].lower())
        # Carried over unchanged: provenance, licensing, certification, inputs, coverage, counts.
        for k in ("schema", "license_status", "certification", "inputs", "coverage", "counts", "games_source",
                  "f2_config", "dispositions"):
            self.assertEqual(m[k], s[k], k)
        self.assertIn("Development only", m["license_status"])
        self.assertIn("pending review", m["certification"])
        self.assertEqual(set(m) - set(s), {"game_types", "derived_from", "f22_config", "audit"})

    # I-04 audit folder
    def test_I04_audit_reports_outside_and_hashed(self):
        self.assertEqual(sorted(self.audit), AUDIT)
        self.assertEqual(self.audit["games_dispositions.json"], self.staging["audit/games_dispositions.json"])
        self.assertEqual(self.audit["mapping_report.json"], self.staging["audit/mapping_report.json"])
        files = self.manifest["audit"]["files"]
        self.assertEqual(sorted(files), ["games_dispositions.json", "mapping_report.json"])
        for name, info in files.items():
            self.assertEqual(info["sha256"], sha(self.audit[name]), name)
        self.assertEqual(files["games_dispositions.json"]["rows"], 7548)
        am = json.loads(self.audit["audit_manifest.json"])
        self.assertEqual((am["snapshot_build_id"], am["staging_build_id"]), (F22_INSTALL_BUILD_ID, F21_STAGING_BUILD_ID))
        self.assertEqual(am["files"], {k: v["sha256"] for k, v in files.items()})

    # I-05 determinism and replacement
    def test_I05_reinstall_is_byte_identical(self):
        r = self.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", self.audit_dir)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(tree(self.snap), self.files)
        self.assertEqual(tree(self.audit_dir), self.audit)

    # I-06 earlier modes unchanged
    def test_I06_default_and_staging_build_ids_unchanged(self):
        r = self.run_builder("--source", SEEDS, "--out", self.tmp / "plain")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn(F15_BUILD_ID, r.stdout)
        plain = tree(self.tmp / "plain")
        for k in CURATED:
            self.assertEqual(plain[k], self.files[k], k)
        self.assertFalse(json.loads(plain["manifest.json"])["capabilities"]["games"])
        self.assertEqual(self.staging_manifest["build_id"], F21_STAGING_BUILD_ID)
        self.assertFalse(self.staging_manifest["capabilities"]["games"])

    # I-07 refusals
    def test_I07_mode_and_location_refusals_write_nothing(self):
        fe = copy_frontend(self.tmp / "fe07")
        snap = fe / "data" / "snapshot"
        keep = self.tmp / "keep07"
        keep.mkdir()
        (keep / "notes.txt").write_text("unrelated")
        afile = self.tmp / "afile07"
        afile.write_text("x")
        base = ["--source", SEEDS, "--games", GAMES, "--install"]
        cases = [
            (["--source", SEEDS, "--install", "--audit-out", self.tmp / "a1"], "needs --games"),
            (base, "needs --audit-out"),
            (base + ["--audit-out", self.tmp / "a2", "--out", self.tmp / "o2"], "do not pass --out"),
            (base + ["--audit-out", self.tmp / "a3", "--report", self.tmp / "r3.json"], "do not pass --report"),
            (base + ["--audit-out", snap / "audit"], "outside the frontend"),
            (base + ["--audit-out", fe / "tools" / "audit"], "outside the frontend"),
            (base + ["--audit-out", fe], "outside the frontend"),
            (base + ["--audit-out", fe.parent], "parent of the frontend"),
            (base + ["--audit-out", keep], "other than earlier audit reports"),
            (base + ["--audit-out", afile], "not a folder"),
            (["--source", SEEDS, "--audit-out", self.tmp / "a4"], "only used with --install"),
        ]
        for args, text in cases:
            with self.subTest(text=text):
                self.assertRefused(self.run_builder(*args, frontend=fe), 4, text)
        self.assertFalse(snap.exists())
        self.assertEqual(sorted(p.name for p in keep.iterdir()), ["notes.txt"])
        self.assertEqual(afile.read_text(), "x")
        for name in ("a1", "a2", "a3", "a4", "o2", "r3.json"):
            self.assertFalse((self.tmp / name).exists(), name)
        self.assertFalse((fe / "tools" / "audit").exists())

    # I-08 --check
    def test_I08_check_writes_nothing(self):
        fe = copy_frontend(self.tmp / "fe08")
        r = self.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", self.tmp / "a08", "--check", frontend=fe)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn(f"CHECK OK build_id={F22_INSTALL_BUILD_ID} staging_build_id={F21_STAGING_BUILD_ID}", r.stdout)
        self.assertFalse((fe / "data" / "snapshot").exists())
        self.assertFalse((self.tmp / "a08").exists())

    # I-09 a refused install keeps the previous snapshot and audit folder
    def test_I09_refusal_keeps_previous_install(self):
        fe = copy_frontend(self.tmp / "fe09")
        audit = self.tmp / "a09"
        self.assertEqual(self.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", audit, frontend=fe).returncode, 0)
        before, before_audit = tree(fe / "data" / "snapshot"), tree(audit)
        bad = self.tmp / "t09.csv"
        bad.write_bytes(Path(GAMES).read_bytes()[:-10])
        self.assertRefused(self.run_builder("--source", SEEDS, "--games", bad, "--install", "--audit-out", audit, frontend=fe), 2)
        self.assertEqual(tree(fe / "data" / "snapshot"), before)
        self.assertEqual(tree(audit), before_audit)

    # I-10 install config is validated and pins the staging build
    def test_I10_install_config_validation(self):
        good = json.loads((FRONTEND / "tools" / "f22_snapshot.json").read_text("utf-8"))
        bad_cases = [
            ({**good, "expected_staging_build_id": "0" * 64}, 3, "not the pinned"),
            ({**good, "extra": "x"}, 2, "keys must be exactly"),
            ({k: v for k, v in good.items() if k != "audit_note"}, 2, "keys must be exactly"),
            ({**good, "game_types": {k: v for k, v in good["game_types"].items() if k != "SB"}}, 2, "game_types"),
            ({**good, "game_types": {**good["game_types"], "REG": " "}}, 2, "game_types"),
            ({**good, "expected_staging_build_id": "abc"}, 2, "not a SHA-256"),
            ({**good, "authorization": ""}, 2, "authorization is empty"),
        ]
        fe = copy_frontend(self.tmp / "fe10")
        for i, (cfg, code, text) in enumerate(bad_cases):
            with self.subTest(text=text):
                p = self.tmp / f"cfg10_{i}.json"
                p.write_text(json.dumps(cfg), "utf-8")
                r = self.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", self.tmp / f"a10_{i}",
                                     "--install-config", p, frontend=fe)
                self.assertRefused(r, code, text)
                self.assertFalse((self.tmp / f"a10_{i}").exists())
        self.assertFalse((fe / "data" / "snapshot").exists())
        r = self.run_builder("--source", SEEDS, "--games", GAMES, "--install", "--audit-out", self.tmp / "a10x", "--install-config",
                             self.tmp / "missing.json", "--check", frontend=fe)
        self.assertRefused(r, 2, "unreadable")

    # I-11 forbidden content in served and audit files
    def test_I11_no_betting_database_urls_or_forbidden_keys(self):
        sys.path.insert(0, str(FRONTEND / "tools"))
        import build_snapshot as B  # noqa: E402

        def keys(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    yield k
                    yield from keys(v)
            elif isinstance(o, list):
                for v in o:
                    yield from keys(v)
        for name, body in {**self.files, **{f"audit/{k}": v for k, v in self.audit.items()}}.items():
            text = body.decode("utf-8")
            self.assertIsNone(BETTING.search(text), name)
            self.assertIsNone(DATABASE.search(text), name)
            self.assertIsNone(URL_RE.search(text), name)
            for k in keys(json.loads(body)):
                self.assertIsNone(B.FORBIDDEN_KEY.search(k), f"{name}: {k}")

    # I-12 Version A untouched and isolated
    def test_I12_version_a_untouched(self):
        sums = {name.strip(): h for h, name in (line.split(None, 1) for line in (FRONTEND / "SHA256SUMS").read_text().splitlines())}
        for p in sorted((self.fe / "data" / "mock").iterdir()):
            self.assertEqual(sha(p.read_bytes()), sums[f"data/mock/{p.name}"], p.name)
        blob = b"".join(self.files.values())
        for demo in (b'"dm_', b'"di_', b'"dg_', b'"dp_', b'"dmrg_'):
            self.assertNotIn(demo, blob)

    # I-13 the F2.2a Node rules accept the installed snapshot (skips without node)
    @unittest.skipUnless(shutil.which("node"), "SKIP: node not found")
    def test_I13_f22a_snapshot_rules_accept_install(self):
        script = ("import { inspectSnapshot } from './tests/helpers/snapshot-rules.mjs';"
                  "const p = inspectSnapshot('data/snapshot'); console.log(JSON.stringify(p)); process.exit(p.length ? 1 : 0);")
        r = subprocess.run(["node", "--input-type=module", "-e", script], cwd=self.fe, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertEqual(json.loads(r.stdout), [])


if __name__ == "__main__":
    unittest.main()
