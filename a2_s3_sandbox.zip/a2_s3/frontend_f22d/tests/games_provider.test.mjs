// F2.2d-A1 S3: the snapshot provider's game methods over the real installed snapshot.
// Tampering happens only in temporary copies; data/snapshot is never written.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { nodeLoader, FRONTEND } from './helpers/node-loader.mjs';
import { SNAPSHOT_BUILT } from './helpers/files.mjs';
import { kindOf } from './helpers/snapshot-rules.mjs';
import { createSnapshotProvider } from '../providers/snapshot/index.js';
import { createMockProvider } from '../providers/mock/index.js';
import { validateEnvelope } from '../src/core/envelope.js';
import { DataLoadError, FileMissingError } from '../src/core/errors.js';
import { reasonFor } from '../src/core/capabilities.js';

const SNAP = path.join(FRONTEND, 'data/snapshot');
const SKIP = SNAPSHOT_BUILT && kindOf(SNAP) === 'f2' ? false : 'SKIP: no game snapshot in data/snapshot';
const GAME_FILES = /games\/|team_season_records/;

function ok(env, label) {
  assert.deepEqual(validateEnvelope(env), [], `${label}: invalid envelope`);
  return env;
}
function provider(root = FRONTEND, log = []) {
  return createSnapshotProvider(nodeLoader(root, log));
}
// A temporary frontend-shaped folder holding a copy of the real snapshot.
function tempSnapshot() {
  const root = mkdtempSync(path.join(tmpdir(), 'velora-a1-'));
  cpSync(SNAP, path.join(root, 'data/snapshot'), { recursive: true });
  const file = (rel) => path.join(root, 'data/snapshot', rel);
  return {
    root,
    read: (rel) => JSON.parse(readFileSync(file(rel), 'utf8')),
    write: (rel, body) => writeFileSync(file(rel), JSON.stringify(body)),
    remove: (rel) => rmSync(file(rel)),
  };
}

test('P01 getGame returns the stored game with names, season and label; meta per D-A1-10', { skip: SKIP }, async () => {
  const env = ok(await provider().getGame('g_4bf81cf6cdc9'), 'getGame');
  assert.equal(env.status, 'ok');
  const stored = JSON.parse(readFileSync(path.join(SNAP, 'games/1999.json'), 'utf8')).records.find((g) => g.game_id === 'g_4bf81cf6cdc9');
  assert.deepEqual(env.data.game, stored, 'the game is returned exactly as stored');
  assert.deepEqual(Object.keys(env.data).sort(), ['away_identity', 'game', 'game_type_label', 'home_identity', 'season']);
  assert.equal(env.data.away_identity.identity_id, 'id_ari_04');
  assert.equal(env.data.home_identity.franchise_id, 'fr_phi');
  assert.equal(env.data.season.season_id, 'NFL-1999');
  assert.equal(env.data.game_type_label, 'Regular season');
  assert.deepEqual(env.meta.classes, ['curated', 'source']);
  assert.deepEqual(env.meta.sources, ['velora_curated_seed', 'nflverse_games']);
  assert.equal(env.meta.verification, null, 'mixed classes: per-item verification stays in the data');
  assert.deepEqual(env.meta.coverage, { from: 1999, league: 'NFL', note: env.meta.coverage.note, to: 2025 });
});

test('P02 getGame: source keys, malformed and unknown ids are not_found with a reason', { skip: SKIP }, async () => {
  const p = provider();
  for (const idv of ['1999_01_ARI_PHI', 'g_4BF81CF6CDC9', 'g_4bf81cf6cdc', 'g_ffffffffffff', '', undefined, 42]) {
    const env = ok(await p.getGame(idv), `getGame ${idv}`);
    assert.equal(env.status, 'not_found', String(idv));
    assert.ok(env.meta.reason);
  }
});

test('P03 listSeasonGames: totals, filters, empty, coverage states (D-A1-7)', { skip: SKIP }, async () => {
  const p = provider();
  let total = 0;
  for (let y = 1999; y <= 2025; y += 1) total += ok(await p.listSeasonGames('NFL', y), `${y}`).data.games.length;
  assert.equal(total, 7276);
  const sb = ok(await p.listSeasonGames('NFL', 2025, { type: 'SB' }), 'SB');
  assert.equal(sb.data.games.length, 1);
  assert.deepEqual(sb.data.filters, { week: null, type: 'SB' });
  assert.ok(sb.data.identities.every((i) => i && i.class === 'curated'), 'names for every team in the list');
  const wk = ok(await p.listSeasonGames('NFL', 2010, { week: 1 }), 'week 1').data.games;
  assert.ok(wk.length >= 15 && wk.every((g) => g.week === 1 && g.game_type === 'REG'));
  const none = ok(await p.listSeasonGames('NFL', 2010, { week: 1, type: 'SB' }), 'empty');
  assert.equal(none.status, 'empty');
  assert.deepEqual(none.data.games, []);
  assert.deepEqual(none.meta.classes, ['curated']);
  for (const f of [{ week: 0 }, { type: 'PRE' }, { team: 'x' }, { week: '1' }]) assert.equal(ok(await p.listSeasonGames('NFL', 2010, f), 'bad filter').status, 'not_found');
  for (const [l, y] of [['NFL', 1998], ['NFL', 1943], ['NFL', 1945], ['AFL', 1965]]) {
    const env = ok(await p.listSeasonGames(l, y), `${l} ${y}`);
    assert.equal(env.status, 'unavailable', `${l} ${y} is missing data, never an empty list`);
    assert.match(env.meta.reason, /missing data, not zero games/);
  }
  const now = ok(await p.listSeasonGames('NFL', 2026), '2026');
  assert.equal(now.status, 'unavailable');
  assert.match(now.meta.reason, /not completed/);
  for (const [l, y] of [['NFL', 1800], ['XFL', 2001]]) assert.equal(ok(await p.listSeasonGames(l, y), 'unknown').status, 'not_found');
});

test('P04 getTeamSeason: results and games, notes, relocations, coverage gaps', { skip: SKIP }, async () => {
  const p = provider();
  const buf = ok(await p.getTeamSeason('fr_buf', 2022), 'BUF 2022');
  assert.equal(buf.data.results.state, 'available');
  assert.equal(buf.data.results.record.status, 'complete_with_note');
  assert.deepEqual(buf.data.results.record.note_ref, { field: 'schedule_note', id: 'E-2022-01', season_id: 'NFL-2022' });
  assert.match(buf.data.results.label, /Not official league standings/);
  assert.ok(buf.data.results.formula);
  assert.equal(buf.data.games.length, 16 + 2);
  assert.ok(buf.data.games.every((g) => g.home.franchise_id === 'fr_buf' || g.away.franchise_id === 'fr_buf'));
  assert.deepEqual(buf.meta.classes, ['curated', 'derived', 'source']);
  assert.equal(buf.meta.verification, null);
  const lar = ok(await p.getTeamSeason('fr_lar', 2016), 'LAR 2016');
  assert.equal(lar.data.results.record.identity_id, 'id_lar_04');
  assert.ok(lar.data.games.every((g) => [g.home, g.away].some((t) => t.franchise_id === 'fr_lar' && t.identity_id === 'id_lar_04')));
  const cases = [['fr_ari', 1998, 'outside_coverage'], ['fr_pit', 1943, 'outside_coverage'], ['fr_ari', 2026, 'not_completed']];
  for (const [fid, y, state] of cases) {
    const env = ok(await p.getTeamSeason(fid, y), `${fid} ${y}`);
    assert.equal(env.data.results.state, state);
    assert.equal(env.data.results.record, null);
    assert.equal(env.data.games, null, 'never an empty games list for missing data');
    assert.ok(env.data.results.reason);
    assert.deepEqual(env.meta.classes, ['curated']);
  }
  const hou = ok(await p.getTeamSeason('fr_hou', 2001), 'HOU 2001');
  assert.equal(hou.status, 'empty');
  assert.equal(hou.data.results.state, 'no_games');
  assert.equal(hou.data.games, null);
});

test('P05 getFranchiseRecords: season by season, names per season, no totals (D-A1-6)', { skip: SKIP }, async () => {
  const p = provider();
  const env = ok(await p.getFranchiseRecords('fr_lar'), 'LAR');
  assert.deepEqual(Object.keys(env.data).sort(), ['formula', 'franchise', 'label', 'rows'], 'no aggregate fields');
  assert.equal(env.data.rows.length, 27);
  assert.deepEqual(env.data.rows.map((r) => r.record.season), Array.from({ length: 27 }, (_, i) => 1999 + i));
  assert.ok(env.data.rows.every((r) => r.identity.identity_id === r.record.identity_id));
  assert.equal(env.data.rows.find((r) => r.record.season === 2015).identity.identity_id, 'id_lar_03');
  assert.equal(env.data.rows.find((r) => r.record.season === 2016).identity.identity_id, 'id_lar_04');
  assert.deepEqual(env.meta.classes, ['curated', 'derived']);
  assert.equal(ok(await p.getFranchiseRecords('fr_hou'), 'HOU').data.rows[0].record.season, 2002);
  const old = ok(await p.getFranchiseRecords('fr_d_akr'), 'defunct');
  assert.equal(old.status, 'empty');
  assert.deepEqual(old.data.rows, []);
  assert.match(old.meta.reason, /cover NFL 1999–2025 only/);
  assert.equal(ok(await p.getFranchiseRecords('fr_nope'), 'unknown').status, 'not_found');
});

test('P06 lazy loading: game files are read on first use only, one shard per season', { skip: SKIP }, async () => {
  const log = [];
  const p = provider(FRONTEND, log);
  await p.getManifest();
  await p.getTeamSeason('fr_ari', 1998);
  assert.deepEqual(log.filter((r) => GAME_FILES.test(r)), [], 'no game file before a game is needed');
  await p.getGame('g_4bf81cf6cdc9');
  assert.deepEqual(log.filter((r) => GAME_FILES.test(r)).sort(), ['data/snapshot/games/1999.json', 'data/snapshot/games/index.json', 'data/snapshot/team_season_records.json']);
  await p.getGame('g_4bf81cf6cdc9');
  await p.listSeasonGames('NFL', 1999, { type: 'REG' });
  await p.getFranchiseRecords('fr_ari');
  await p.getTeamSeason('fr_ari', 1999);
  assert.equal(log.filter((r) => GAME_FILES.test(r)).length, 3, 'cached: nothing re-read');
  await p.listSeasonGames('NFL', 2000);
  assert.deepEqual(log.filter((r) => GAME_FILES.test(r)).slice(3), ['data/snapshot/games/2000.json']);
});

test('P07 mock provider stays fail-closed for games', async () => {
  const log = [];
  const p = createMockProvider(nodeLoader(FRONTEND, log));
  for (const env of [await p.getGame('g_4bf81cf6cdc9'), await p.listSeasonGames('NFL', 2000), await p.getFranchiseRecords('fr_x')]) {
    assert.equal(ok(env, 'mock').status, 'unavailable');
    assert.equal(env.meta.reason, reasonFor('mock', 'games'));
  }
  const franchises = (await p.listFranchises()).data;
  const ts = ok(await p.getTeamSeason(franchises[0].franchise_id, franchises[0].first_nfl_season), 'mock team season');
  assert.equal(ts.data.results.state, 'unavailable');
  assert.equal(ts.data.games, null);
  assert.ok(log.every((r) => r.startsWith('data/mock/')), 'mock reads only its own folder');
  assert.ok(!log.some((r) => GAME_FILES.test(r)));
});

test('P08 a snapshot with games switched off stays fail-closed and reads no game file', { skip: SKIP }, async () => {
  const t = tempSnapshot();
  const m = t.read('manifest.json');
  m.capabilities.games = false;
  t.write('manifest.json', m);
  const log = [];
  const p = provider(t.root, log);
  for (const env of [await p.getGame('g_4bf81cf6cdc9'), await p.listSeasonGames('NFL', 2000), await p.getFranchiseRecords('fr_ari')]) {
    assert.equal(ok(env, 'off').status, 'unavailable');
    assert.equal(env.meta.reason, reasonFor('snapshot', 'games'));
  }
  const ts = ok(await p.getTeamSeason('fr_ari', 2000), 'off team season');
  assert.equal(ts.data.results.state, 'unavailable');
  assert.equal(ts.data.games, null);
  assert.ok(!log.some((r) => GAME_FILES.test(r)), `no game files requested: ${log}`);
});

test('P09 invalid or missing game files reject with DataLoadError; nothing partial is returned', { skip: SKIP }, async () => {
  const bad = [
    ['shard: impossible score', (t) => { const b = t.read('games/2003.json'); b.records[0].home.score = -1; t.write('games/2003.json', b); }, (p) => p.listSeasonGames('NFL', 2003), /score -1/],
    ['shard: impossible week with matching key', (t) => { const b = t.read('games/2003.json'); const g = b.records[0]; g.week = 30; g.source_ref.key = g.source_ref.key.replace(/_\d{2}_/, '_30_'); t.write('games/2003.json', b); }, (p) => p.listSeasonGames('NFL', 2003), /week 30 is impossible for REG/],
    ['shard missing', (t) => t.remove('games/2003.json'), (p) => p.listSeasonGames('NFL', 2003), /file not found/],
    ['index: duplicate id', (t) => { const b = t.read('games/index.json'); b.records[1].game_id = b.records[0].game_id; t.write('games/index.json', b); }, (p) => p.getGame('g_4bf81cf6cdc9'), /listed twice/],
    ['index missing', (t) => t.remove('games/index.json'), (p) => p.getGame('g_4bf81cf6cdc9'), /file not found/],
    ['index disagrees with shard (game missing)', (t) => { const b = t.read('games/index.json'); const id = t.read('games/2003.json').records[0].game_id; b.records = b.records.filter((r) => r.game_id !== id); t.write('games/index.json', b); }, (p) => p.listSeasonGames('NFL', 2003), /missing from the index/],
    ['index disagrees with shard (wrong season)', (t) => { const b = t.read('games/index.json'); const id = t.read('games/2003.json').records[0].game_id; b.records.find((r) => r.game_id === id).season = 2004; t.write('games/index.json', b); }, (p) => p.listSeasonGames('NFL', 2003), /index puts g_[0-9a-f]{12} in 2004, not 2003/],
    ['records: label lost', (t) => { const b = t.read('team_season_records.json'); b.label = 'Standings'; t.write('team_season_records.json', b); }, (p) => p.getFranchiseRecords('fr_ari'), /Not official league standings/],
    ['records disagree with games', (t) => { const b = t.read('team_season_records.json'); const r = b.records.find((x) => x.record_id === '2003-fr_ari'); r.regular_season.wins += 1; r.regular_season.losses -= 1; t.write('team_season_records.json', b); }, (p) => p.listSeasonGames('NFL', 2003), /2003-fr_ari regular season wins/],
    ['records file missing', (t) => t.remove('team_season_records.json'), (p) => p.getTeamSeason('fr_ari', 2003), /file not found/],
  ];
  for (const [label, edit, call, re] of bad) {
    const t = tempSnapshot();
    edit(t);
    const p = provider(t.root);
    await assert.rejects(call(p), (e) => e instanceof DataLoadError && re.test(e.message), label);
    if (/^shard|disagree/.test(label)) {
      assert.equal(ok(await p.listSeasonGames('NFL', 2010), `${label}: other season`).status, 'ok', 'a season-level problem affects only its own season');
    } else {
      await assert.rejects(p.listSeasonGames('NFL', 2010), DataLoadError, `${label}: a bad shared file fails every season closed`);
    }
  }
  const t = tempSnapshot();
  t.remove('games/2003.json');
  await assert.rejects(provider(t.root).listSeasonGames('NFL', 2003), FileMissingError);
});

test('P10 concurrent calls share one load; a concurrent failure rejects every caller once', { skip: SKIP }, async () => {
  const log = [];
  const p = provider(FRONTEND, log);
  const results = await Promise.all(Array.from({ length: 6 }, () => p.listSeasonGames('NFL', 2012)));
  assert.equal(log.filter((r) => r === 'data/snapshot/games/2012.json').length, 1, 'one read for six concurrent callers');
  for (const env of results) assert.deepEqual(env, results[0]);
  const t = tempSnapshot();
  const b = t.read('games/2012.json');
  b.records[0].overtime = 'no';
  t.write('games/2012.json', b);
  const log2 = [];
  const q = provider(t.root, log2);
  const settled = await Promise.allSettled(Array.from({ length: 4 }, () => q.listSeasonGames('NFL', 2012)));
  assert.ok(settled.every((x) => x.status === 'rejected' && x.reason instanceof DataLoadError));
  assert.equal(log2.filter((r) => r === 'data/snapshot/games/2012.json').length, 1, 'the failing shard was read once for all callers');
});
