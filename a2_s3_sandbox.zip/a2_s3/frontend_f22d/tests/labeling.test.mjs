// Demonstration data must be fictional and labeled. Snapshot data must carry the class its path
// requires (F2.2a: curated, source or derived) and stay pending review.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { FRONTEND } from './helpers/node-loader.mjs';
import { readFileSync } from 'node:fs';
import { walk, read, SNAPSHOT_BUILT } from './helpers/files.mjs';
import { inspectSnapshot, only, listAll, ruleFor, sha256 } from './helpers/snapshot-rules.mjs';

// Current and historical NFL nicknames that must not appear in demonstration data.
const NFL_NICKNAMES = ['Cardinals', 'Falcons', 'Ravens', 'Bills', 'Panthers', 'Bears', 'Bengals', 'Browns', 'Cowboys', 'Broncos',
  'Lions', 'Packers', 'Texans', 'Colts', 'Jaguars', 'Chiefs', 'Raiders', 'Chargers', 'Rams', 'Dolphins', 'Vikings', 'Patriots',
  'Saints', 'Giants', 'Jets', 'Eagles', 'Steelers', '49ers', 'Seahawks', 'Buccaneers', 'Titans', 'Commanders', 'Redskins',
  'Oilers', 'Yanks', 'Steagles', 'Spartans', 'Staleys', 'Pirates', 'Redskins', 'Bulldogs', 'Eskimos', 'Packers', 'Football Team'];

const mockFiles = walk(path.join(FRONTEND, 'data/mock'), ['.json']);
const records = (f) => JSON.parse(read(f)).records ?? [];

test('mock data exists and every file is labeled demo', () => {
  assert.equal(mockFiles.length, 7);
  for (const f of mockFiles) assert.equal(JSON.parse(read(f)).class ?? 'demo', 'demo', f);
});

test('every mock record, including nested identities, is class demo', () => {
  const visit = (o, where) => {
    if (Array.isArray(o)) o.forEach((x, i) => visit(x, `${where}[${i}]`));
    else if (o && typeof o === 'object') {
      if ('class' in o) assert.equal(o.class, 'demo', where);
      for (const [k, v] of Object.entries(o)) visit(v, `${where}.${k}`);
    }
  };
  for (const f of mockFiles) for (const r of records(f)) { assert.equal(r.class, 'demo', f); visit(r, f); }
});

test('no real NFL franchise nickname appears in mock data', () => {
  let names = [...NFL_NICKNAMES];
  if (SNAPSHOT_BUILT) names = names.concat(records(path.join(FRONTEND, 'data/snapshot/identities.json')).map((i) => i.nickname));
  const text = mockFiles.map(read).join('\n');
  for (const n of new Set(names)) assert.ok(!new RegExp(`\\b${n}\\b`).test(text), `mock data contains "${n}"`);
});

test('mock league is not presented as the NFL', () => {
  const leagues = records(path.join(FRONTEND, 'data/mock/leagues.json'));
  assert.deepEqual(leagues.map((l) => l.league_code), ['DEMO']);
  assert.equal(leagues[0].recognized_by_nfl, false);
});

test('snapshot records are curated and pending review', { skip: SNAPSHOT_BUILT ? false : 'SKIP: data/snapshot not built' }, () => {
  // F2.2a: every served file has the class its path requires (curated, source or derived),
  // every record matches its file, and pending_review is mandatory throughout.
  const dir = path.join(FRONTEND, 'data/snapshot');
  assert.deepEqual(only(inspectSnapshot(dir), 'labels', 'classes', 'isolation'), []);
  for (const rel of listAll(dir)) {
    if (rel === 'manifest.json') continue;
    const rule = ruleFor(rel);
    assert.ok(rule, `${rel} has no labeling rule`);
    const body = JSON.parse(read(path.join(dir, rel)));
    assert.equal(body.class, rule.cls, rel);
    assert.equal(body.review_status, 'pending_review', rel);
    if (rule.kind === 'index') continue; // id → season lookup rows carry no class of their own
    for (const r of body.records) {
      assert.equal(r.class, rule.cls, rel);
      assert.equal(r.review_status, 'pending_review', rel);
      if (r.identity) assert.equal(r.identity.review_status, 'pending_review');
    }
  }
});

test('mock files match the mock manifest exactly and carry no real ids', () => {
  // Version A integrity: the files on disk are exactly the manifest outputs, byte for byte,
  // and no value looks like a Version B id (franchise, identity, merged key or game id).
  const dir = path.join(FRONTEND, 'data/mock');
  const m = JSON.parse(read(path.join(dir, 'manifest.json')));
  assert.equal(m.provider, 'mock');
  assert.deepEqual(m.classes, ['demo']);
  assert.deepEqual(listAll(dir).filter((f) => f !== 'manifest.json'), Object.keys(m.outputs).sort());
  for (const [rel, info] of Object.entries(m.outputs)) {
    const buf = readFileSync(path.join(dir, rel));
    assert.equal(sha256(buf), info.sha256, rel);
    assert.equal(JSON.parse(buf).records.length, info.records, rel);
  }
  const REAL_ID = /^(fr|id|mrg)_|^g_[0-9a-f]{12}$/;
  const strings = (o, out = []) => {
    if (Array.isArray(o)) o.forEach((x) => strings(x, out));
    else if (o && typeof o === 'object') Object.values(o).forEach((x) => strings(x, out));
    else if (typeof o === 'string') out.push(o);
    return out;
  };
  for (const f of mockFiles) {
    const hit = strings(JSON.parse(read(f))).find((x) => REAL_ID.test(x));
    assert.equal(hit, undefined, `${f} contains ${hit}`);
  }
});
