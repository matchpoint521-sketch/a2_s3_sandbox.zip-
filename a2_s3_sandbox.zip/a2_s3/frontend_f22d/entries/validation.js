// Version B entry: binds the shared app to the approved snapshot provider only.
import { boot } from '../src/app/boot.js';
import { browserLoader } from '../src/core/loader.js';
import { createSnapshotProvider } from '../providers/snapshot/index.js';

boot(document.getElementById('app'), createSnapshotProvider(browserLoader()), { mode: 'validation' });
