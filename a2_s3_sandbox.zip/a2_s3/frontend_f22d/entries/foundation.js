// Version A entry: binds the shared app to the demonstration provider only.
import { boot } from '../src/app/boot.js';
import { browserLoader } from '../src/core/loader.js';
import { createMockProvider } from '../providers/mock/index.js';

boot(document.getElementById('app'), createMockProvider(browserLoader()), { mode: 'foundation' });
