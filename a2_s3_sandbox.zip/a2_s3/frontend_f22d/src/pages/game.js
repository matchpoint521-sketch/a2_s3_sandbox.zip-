import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { classBadge } from '../components/data-badge.js';
import { unavailableState } from '../components/states.js';
import { href } from '../app/router.js';
import { crumb, notFoundPage } from './common.js';
import { sideName, stageText, matchupTitle, finalText, outcomeText, gameOutcome, formatGameDate, isPostseason } from '../core/game-view.js';

// Game detail (F2.2d-A2). Shows only fields present in the verified snapshot: teams under the
// names used that season, final score, season, round or week, date, overtime and neutral-site
// flags, and provenance. No venue, quarter scores or player data exist in the source files.
export async function render({ provider, route }) {
  const env = await provider.getGame(route.params.game);
  if (env.status === 'not_found') {
    return notFoundPage('Game not found', env.meta.reason, [crumb('Seasons', 'seasons'), crumb('Not found')]);
  }
  if (env.status !== 'ok') {
    const node = h('div', {},
      pageHeader({ crumbs: [crumb('Seasons', 'seasons'), crumb('Game')], title: 'Game', lede: `Game id ${route.params.game}`, badges: [classBadge('unavailable')] }),
      unavailableState('Game details', env.meta.reason));
    return { title: 'Game', node };
  }

  const manifest = (await provider.getManifest()).data;
  const { game: g, home_identity: homeId, away_identity: awayId, season, game_type_label: typeLabel } = env.data;
  const labels = { ...(manifest.game_types ?? {}), [g.game_type]: typeLabel };
  const away = sideName(awayId);
  const home = sideName(homeId);
  const stage = stageText(g, labels);
  const title = matchupTitle(g, away, home);
  const date = formatGameDate(g.game_date);
  const outcome = gameOutcome(g);

  const row = (sideKey, name) => {
    const result = outcome.tie ? 'tie' : outcome.winner === sideKey ? 'won' : 'lost';
    const word = result === 'tie' ? 'Tie' : result === 'won' ? 'Won' : 'Lost';
    return h('div', { class: 'scoreline__row', 'data-result': result },
      h('dt', {}, h('span', { class: 'scoreline__team' }, name),
        h('span', { class: 'scoreline__meta' }, `${sideKey === 'home' ? 'Home' : 'Away'} · ${word}`)),
      h('dd', { class: 'scoreline__score num' }, String(g[sideKey].score)));
  };

  const seasonLabel = `${g.league_code} ${g.season}`;
  const source = manifest.games_source ?? null;
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Seasons', 'seasons'), crumb(seasonLabel, 'season', { league: g.league_code, year: g.season }), crumb(stage)],
      title,
      lede: [typeLabel, isPostseason(g) ? null : stage, date].filter(Boolean).join(' · '),
      badges: [classBadge('source'), h('span', { class: 'badge badge--review' }, 'Pending review')],
    }),
    h('section', { class: 'scoreline', 'aria-labelledby': 'scoreline-title' },
      h('h2', { id: 'scoreline-title', class: 'visually-hidden' }, 'Final score'),
      h('dl', { class: 'scoreline__teams' }, row('away', away), row('home', home)),
      h('p', { class: 'scoreline__status' }, `${finalText(g)} · ${outcomeText(g, away, home)}`)),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'Season'), h('dd', {}, h('a', { href: href('season', { league: g.league_code, year: g.season }) }, season ? `${g.league_code} ${season.year}` : seasonLabel))),
      // S3 fix: postseason games show "Postseason" here and the round below, instead of the round twice.
      h('div', {}, h('dt', {}, 'Game type'), h('dd', {}, isPostseason(g) ? 'Postseason' : typeLabel)),
      h('div', {}, h('dt', {}, isPostseason(g) ? 'Round' : 'Week'), h('dd', { class: 'num' }, isPostseason(g) ? stage : String(g.week))),
      h('div', {}, h('dt', {}, 'Date'), h('dd', {}, date)),
      h('div', {}, h('dt', {}, 'Overtime'), h('dd', {}, g.overtime ? 'Yes' : 'No')),
      h('div', {}, h('dt', {}, 'Neutral site'), h('dd', {}, g.neutral_site ? 'Yes' : 'No'))),
    g.neutral_site ? h('p', {}, 'Played at a neutral site, as marked by the source. Home and away follow the source’s designation.') : null,
    h('h2', {}, 'Team seasons'),
    h('ul', { class: 'game-links' },
      h('li', {}, h('a', { href: href('team-season', { franchise: g.away.franchise_id, year: g.season }) }, `${away}, ${g.season} season`)),
      h('li', {}, h('a', { href: href('team-season', { franchise: g.home.franchise_id, year: g.season }) }, `${home}, ${g.season} season`))),
    h('section', { class: 'panel source-panel', 'aria-labelledby': 'source-title' },
      h('h2', { id: 'source-title' }, 'Source'),
      h('p', { class: 'page-header__badges' }, classBadge('source'), h('span', { class: 'badge' }, 'Verified against one pinned source'), h('span', { class: 'badge badge--review' }, 'Pending review')),
      source ? h('p', {}, source.attribution) : null,
      h('p', {}, 'Team names are curated date ranges, pending review. Nothing here is historically certified.'),
      manifest.license_status ? h('p', {}, manifest.license_status) : null,
      h('details', {}, h('summary', {}, 'Source reference'),
        h('dl', { class: 'facts' },
          h('div', {}, h('dt', {}, 'Source key'), h('dd', { class: 'mono-hash' }, g.source_ref.key)),
          h('div', {}, h('dt', {}, 'Game id'), h('dd', { class: 'mono-hash' }, g.game_id))))));
  return { title, node };
}
