import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { recordBadges } from '../components/data-badge.js';
import { emptyState } from '../components/states.js';
import { yearSpan, identityName } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb } from './common.js';

export async function render({ provider, route }) {
  const q = route.query.q ?? '';
  const env = await provider.search(q);
  const { franchises = [], seasons = [], players = [], notes = [] } = env.data ?? {};
  const group = (title, items, render) => (items.length ? h('section', {}, h('h2', {}, `${title} (${items.length})`), h('ul', { class: 'rules' }, items.map((x) => h('li', {}, render(x))))) : null);
  const node = h('div', {},
    pageHeader({ crumbs: [crumb('Explore', 'explore'), crumb('Search')], title: q ? `Search: ${q}` : 'Search' }),
    env.status === 'empty' ? emptyState(q.trim().length < 2 ? 'Type something to search' : 'No results', env.meta.reason) : null,
    group('Teams', franchises, (f) => [h('a', { href: href('team', { franchise: f.franchise_id }) }, f.display_name), ` ${yearSpan(f.first_nfl_season, f.last_season)}`,
      f.latest_identity && identityName(f.latest_identity) !== f.display_name ? ` (latest name ${identityName(f.latest_identity)})` : '', ' ', recordBadges(f)]),
    group('Seasons', seasons, (s) => h('a', { href: href('season', { league: s.league_code, year: s.year }) }, `${s.year} ${s.league_code}`)),
    group('Players', players, (p) => h('a', { href: href('player', { player: p.player_id }) }, `${p.display_name}, ${p.position}`)),
    notes.map((n) => h('p', { class: 'result-count' }, n)));
  return { title: 'Search', node };
}
