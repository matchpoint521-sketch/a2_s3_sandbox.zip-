import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { dataTable } from '../components/table.js';
import { DATA_CLASSES } from '../core/data-class.js';
import { CAPABILITY_KEYS, reasonFor } from '../core/capabilities.js';
import { crumb } from './common.js';

const CAP_LABELS = {
  franchises: 'Franchises and names', seasons: 'Seasons', games: 'Game results', headToHead: 'Series records',
  players: 'Players', playerStats: 'Player statistics', statCoverage: 'Statistic coverage', compare: 'Comparisons', search: 'Search',
};

export async function render({ provider, mode }) {
  const m = (await provider.getManifest()).data;
  const isSnap = m.provider === 'snapshot';
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Explore', 'explore'), crumb('About the data')], title: 'About the data',
      lede: isSnap
        ? 'This is the data-validation version. It reads only a local development snapshot built from curated seed files.'
        : 'This is the foundation version. It reads only fictional demonstration data.',
    }),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'Version'), h('dd', {}, mode === 'foundation' ? 'Foundation (A)' : 'Data validation (B)')),
      h('div', {}, h('dt', {}, 'Provider'), h('dd', {}, m.provider)),
      isSnap ? h('div', {}, h('dt', {}, 'Build'), h('dd', { class: 'mono-hash' }, m.build_id)) : null,
      h('div', {}, h('dt', {}, 'Seasons covered'), h('dd', { class: 'num' }, `${m.coverage.seasons.from}–${m.coverage.seasons.to}`))),
    isSnap ? h('p', {}, m.license_status) : h('p', {}, m.notice),
    isSnap ? h('p', {}, m.certification) : null,
    isSnap ? h('p', {}, `Authorization: ${m.authorization}.`) : null,
    h('h2', {}, 'What is available'),
    dataTable({
      caption: 'Features are switched on only when this version has the data for them.',
      columns: [
        { label: 'Feature', cell: (k) => CAP_LABELS[k] ?? k },
        { label: 'Status', cell: (k) => (m.capabilities[k] ? 'Available' : 'Not available') },
        { label: 'Why', cell: (k) => (m.capabilities[k] ? '' : reasonFor(m.provider, k)) },
      ],
      rows: CAPABILITY_KEYS,
    }),
    h('h2', {}, 'Record counts'),
    dataTable({
      caption: 'Counts from the manifest.',
      columns: [{ label: 'Records', cell: ([k]) => k.replaceAll('_', ' ') }, { label: 'Count', numeric: true, cell: ([, v]) => String(v) }],
      rows: Object.entries(m.counts),
    }),
    isSnap ? [h('h2', {}, 'Inputs'), dataTable({
      caption: 'Source files, verified by SHA-256 before the build. They are read, never modified.',
      columns: [{ label: 'File', cell: ([k]) => k }, { label: 'Rows', numeric: true, cell: ([, v]) => String(v.rows) }, { label: 'SHA-256', cell: ([, v]) => h('span', { class: 'mono-hash' }, v.sha256) }],
      rows: Object.entries(m.inputs),
    })] : null,
    h('h2', {}, 'Kinds of data'),
    h('dl', { class: 'legend' }, Object.entries(DATA_CLASSES).map(([k, c]) => h('div', {}, h('dt', {}, h('span', { class: `badge badge--${k}` }, c.label)), h('dd', {}, c.description)))));
  return { title: 'About the data', node };
}
