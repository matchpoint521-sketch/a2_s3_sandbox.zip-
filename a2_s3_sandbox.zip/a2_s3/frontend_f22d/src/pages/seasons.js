import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { classBadge } from '../components/data-badge.js';
import { emptyState } from '../components/states.js';
import { fieldStrip } from '../components/field-strip.js';
import { decadeOf, yearSpan } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb } from './common.js';

const reduceMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

// The schedule lengths that occur in a decade, from the season records.
function scheduleNote(list) {
  const lengths = [...new Set(list.map((s) => s.regular_season_games))];
  const known = lengths.filter((g) => g != null).sort((a, b) => a - b);
  const parts = [];
  if (known.length) parts.push(`${known.join(', ').replace(/, (\d+)$/, ' and $1')} games`);
  if (lengths.includes(null)) parts.push('no uniform schedule');
  return parts.join('; ');
}

export async function render({ provider, route }) {
  const all = (await provider.listSeasons()).data ?? [];
  const leagues = [...new Set(all.map((s) => s.league_code))];
  let league = leagues.includes(route.query.league) ? route.query.league : 'all';
  const cls = provider.id === 'mock' ? 'demo' : 'curated';
  const body = h('div', {});
  const nav = h('nav', { class: 'decade-nav', 'aria-label': 'Jump to a decade' });
  const radios = new Map();

  function draw() {
    history.replaceState(null, '', href('seasons', {}, { league: league === 'all' ? null : league }));
    for (const [v, input] of radios) input.checked = v === league;
    const rows = all.filter((s) => league === 'all' || s.league_code === league);
    if (!rows.length) { nav.replaceChildren(); body.replaceChildren(emptyState('No seasons', 'No seasons match this league.')); return; }
    const byDecade = new Map();
    for (const s of rows) {
      const d = decadeOf(s.year);
      if (!byDecade.has(d)) byDecade.set(d, []);
      byDecade.get(d).push(s);
    }
    const sections = [...byDecade.entries()].map(([d, list]) => {
      const heading = h('h2', { id: `dec-${d}`, tabindex: '-1' }, `${d}s`);
      const section = h('section', { class: 'decade', 'aria-labelledby': `dec-${d}` },
        h('div', {}, heading, h('p', { class: 'decade__note' }, `${list.length} ${list.length === 1 ? 'season' : 'seasons'}; ${scheduleNote(list)}`)),
        h('ul', {}, list.map((s) => h('li', {}, h('a', {
          class: 'season-tile', 'data-league': s.league_code,
          href: href('season', { league: s.league_code, year: s.year }),
          'aria-label': `${s.year} ${s.league_code} season`,
        }, h('strong', { class: 'num' }, `${s.year}`),
        h('small', {}, s.league_code, s.regular_season_games != null ? `, ${s.regular_season_games} games` : ''))))));
      return { d, heading, section };
    });
    nav.replaceChildren(h('ul', {}, sections.map(({ d, heading, section }) => h('li', {}, h('button', {
      type: 'button',
      onclick: () => { section.scrollIntoView({ behavior: reduceMotion() ? 'auto' : 'smooth', block: 'start' }); heading.focus({ preventScroll: true }); },
    }, `${d}s`)))));
    body.replaceChildren(h('div', { class: 'decades' }, sections.map((x) => x.section)));
  }

  const counts = { all: all.length };
  for (const l of leagues) counts[l] = all.filter((s) => s.league_code === l).length;
  const seg = leagues.length > 1 ? h('fieldset', { class: 'segmented' }, h('legend', {}, 'League'),
    [['all', 'All'], ...leagues.map((l) => [l, l])].map(([v, label]) => {
      const input = h('input', { type: 'radio', name: 'league', value: v, checked: v === league, onchange: () => { league = v; draw(); } });
      radios.set(v, input);
      return h('label', {}, input, h('span', {}, label, h('small', { class: 'num' }, String(counts[v]))));
    })) : null;

  // League timeline: the same field strip as Explore, one lane per league.
  const spans = leagues.map((l) => {
    const ys = all.filter((s) => s.league_code === l).map((s) => s.year);
    return { l, from: Math.min(...ys), to: Math.max(...ys) };
  }).sort((a, b) => a.from - b.from);
  const from = Math.min(...spans.map((x) => x.from));
  const to = Math.max(...spans.map((x) => x.to));
  const field = all.length ? fieldStrip({
    from, to, selected: league === 'all' ? null : league,
    lanes: spans.map((x) => ({ label: `${x.l} ${yearSpan(x.from, x.to)}`, segments: [{ id: x.l, label: x.l, from: x.from, to: x.to, kind: 'identity', cls }] })),
    lineLabel: league === 'all' ? `Latest season ${to}` : undefined,
    label: `Leagues from ${from} to ${to}`,
    caption: leagues.length > 1
      ? 'Each band is a league. Select one to move the gold line to its first season; use the League filter below to list its seasons.'
      : 'The band is the league in this data. The gold line marks the latest season.',
  }) : null;

  draw();
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Explore', 'explore'), crumb('Seasons')], title: 'Seasons',
      lede: leagues.includes('AFL') ? 'Every season by decade. From 1960 to 1969 the AFL and NFL played separate seasons.' : 'Every season by decade.',
      badges: [classBadge(cls)],
      scene: true,
    }),
    field ? field.element : null,
    seg ? h('div', { class: 'filters' }, seg) : null,
    nav, body);
  return { title: 'Seasons', node };
}
