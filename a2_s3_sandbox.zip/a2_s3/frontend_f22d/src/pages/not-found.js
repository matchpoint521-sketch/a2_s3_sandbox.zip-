import { notFoundPage, crumb } from './common.js';

export async function render({ route }) {
  return notFoundPage('Page not found', `There is no page at "${route.path}".`, [crumb('Explore', 'explore'), crumb('Not found')]);
}
