import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { recordBadges, classBadge } from '../components/data-badge.js';
import { dataTable } from '../components/table.js';
import { emptyState, unavailableState } from '../components/states.js';
import { identityName, yearSpan } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb, notFoundPage } from './common.js';
import { recordView, resolveSeasonNote, splitGames, teamResult, stageText, formatGameDate, sideName, identityMap } from '../core/game-view.js';

// Team-season page. F2.2d-A2: results come only from env.data.results and env.data.games.
// Record numbers appear only when results.state is "available"; every other state shows the
// provider's reason, so a season without game data never reads as 0 games or a winless season.
export async function render({ provider, route }) {
  const { franchise: fid, year } = route.params;
  const env = await provider.getTeamSeason(fid, year);
  if (env.status === 'not_found') return notFoundPage('Season not found', env.meta.reason, [crumb('Teams', 'teams'), crumb('Not found')]);
  const { franchise: f, identities, merged, seasons } = env.data;
  const crumbs = [crumb('Teams', 'teams'), crumb(f.display_name, 'team', { franchise: fid }), crumb(String(year))];
  const { span } = env.data;
  const nav = h('p', {},
    year > span.from ? h('a', { href: href('team-season', { franchise: fid, year: year - 1 }) }, `Previous: ${year - 1}`) : null,
    year > span.from && year < span.to ? '   ' : null,
    year < span.to ? h('a', { href: href('team-season', { franchise: fid, year: year + 1 }) }, `Next: ${year + 1}`) : null);

  if (env.status === 'empty') {
    return {
      title: `${f.display_name}, ${year}`,
      node: h('div', {}, pageHeader({ crumbs, title: `${f.display_name}, ${year}` }),
        emptyState('No name recorded for this season', env.meta.reason, [h('a', { href: href('team', { franchise: fid }) }, `See all names for the ${f.display_name}`)]), nav),
    };
  }

  const m = merged[0];
  const name = m ? m.common_name : identityName(identities[0]);
  const node = h('div', {},
    pageHeader({
      crumbs, title: `${name}, ${year}`,
      lede: m ? `In ${year} the ${f.display_name} franchise played as part of a merged team.` : `Season ${year} of the ${f.display_name} franchise.`,
      badges: recordBadges(m ?? identities[0]),
    }),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'Name in use'), h('dd', {}, name)),
      m ? h('div', {}, h('dt', {}, 'Merged with'), h('dd', {}, m.members.filter((x) => x.franchise_id !== fid).map((x) => h('a', { href: href('team-season', { franchise: x.franchise_id, year }) }, x.display_name)))) : null,
      identities[0] ? h('div', {}, h('dt', {}, 'Name used'), h('dd', { class: 'num' }, yearSpan(identities[0].first_season, identities[0].last_season))) : null,
      h('div', {}, h('dt', {}, 'Season pages'), h('dd', {}, seasons.length
        ? seasons.map((s, i) => [i ? ', ' : '', h('a', { href: href('season', { league: s.league_code, year }) }, `${s.league_code} ${year}`)])
        : 'None'))),
    h('p', {}, 'Names come from curated date ranges and are pending review.'),
    await resultsSection(provider, fid, year, name, env.data),
    nav);
  return { title: `${name}, ${year}`, node };
}

async function resultsSection(provider, fid, year, name, data) {
  const results = data.results;
  if (!results || results.state !== 'available') {
    if (results && results.state === 'no_games') return emptyState('No games in this data', results.reason);
    return unavailableState('Games and record', results ? results.reason : 'Game results are not available.');
  }
  const manifest = (await provider.getManifest()).data;
  const labels = manifest.game_types ?? {};
  const view = recordView(results, labels);
  const games = data.games ?? [];
  const league = games[0] ? games[0].league_code : 'NFL';
  const seasonGames = await provider.listSeasonGames(league, year);
  const names = identityMap(seasonGames.status === 'ok' ? seasonGames.data.identities : []);
  const { regular, postseason } = splitGames(games);
  const seasonNote = resolveSeasonNote(view.noteRef, data.seasons);

  const resultCell = (g, r) => h('a', { href: href('game', { game: g.game_id }), class: 'result-link' },
    h('span', { class: 'result-letter', 'data-result': r.letter, 'aria-hidden': 'true' }, r.letter),
    h('span', { class: 'visually-hidden' }, `${r.word}, `),
    h('span', { class: 'num' }, r.score),
    h('span', { class: 'visually-hidden' }, ', game details'));
  const columns = (firstLabel) => [
    { label: firstLabel, cell: (g) => stageText(g, labels) },
    // S3 fix: opponent and result come before the date so a phone shows them without scrolling the table.
    { label: 'Opponent', cell: (g) => { const r = teamResult(g, fid); return `${r.prefix} ${sideName(names.get(r.opponentIdentityId))}${r.neutral ? ' (neutral site)' : ''}`; } },
    { label: 'Result', cell: (g) => resultCell(g, teamResult(g, fid)) },
    { label: 'Date', cell: (g) => h('span', { class: 'num' }, formatGameDate(g.game_date)) },
    { label: 'Overtime', cell: (g) => (g.overtime ? 'Yes' : 'No') },
  ];

  return h('section', { class: 'results', 'aria-labelledby': 'record-title' },
    h('h2', { id: 'record-title' }, 'Record'),
    h('p', { class: 'page-header__badges' }, classBadge('derived'), classBadge('source'), h('span', { class: 'badge badge--review' }, 'Pending review')),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'Regular season'), h('dd', { class: 'num' }, view.regular),
        h('dd', { class: 'facts__sub' }, `Wins ${view.wins} · Losses ${view.losses} · Ties ${view.ties}`)),
      h('div', {}, h('dt', {}, 'Postseason'), view.postseason
        ? [h('dd', { class: 'num' }, view.postseason.record), h('dd', { class: 'facts__sub' }, view.postseason.rounds)]
        : h('dd', {}, 'No postseason games in this data'))),
    h('p', {}, view.label),
    h('details', {}, h('summary', {}, 'How this record is calculated'), h('p', {}, view.formula)),
    view.countNote ? h('p', { class: 'note' }, view.countNote) : null,
    seasonNote ? h('details', {}, h('summary', {}, 'Season note'), h('p', {}, seasonNote)) : null,
    h('h2', {}, 'Regular season'),
    dataTable({ caption: `${name}, ${year} regular-season games in date order. Opponent names are those used that season.`, columns: columns('Week'), rows: regular }),
    postseason.length ? [h('h2', {}, 'Postseason'),
      dataTable({ caption: `${name}, ${year} postseason games in date order.`, columns: columns('Round'), rows: postseason })] : null,
    h('section', { class: 'panel source-panel', 'aria-labelledby': 'ts-source-title' },
      h('h2', { id: 'ts-source-title' }, 'Source'),
      manifest.games_source ? h('p', {}, manifest.games_source.attribution) : null,
      h('p', {}, 'Game results are verified against one pinned source only. The record is calculated by Velora from those results and is not official league standings.'),
      manifest.license_status ? h('p', {}, manifest.license_status) : null));
}
