import { h } from '../components/dom.js';
import { classBadge } from '../components/data-badge.js';
import { fieldStrip } from '../components/field-strip.js';
import { unavailableState } from '../components/states.js';
import { reasonFor } from '../core/capabilities.js';
import { count, yearSpan } from '../core/format.js';
import { href } from '../app/router.js';

// Consecutive seasons of one league with the same regular-season length.
// Derived from the season records; no era names are invented.
function scheduleRuns(seasons) {
  const runs = [];
  const sorted = [...seasons].sort((a, b) => a.league_code.localeCompare(b.league_code) || a.year - b.year);
  for (const s of sorted) {
    const last = runs[runs.length - 1];
    if (last && last.league === s.league_code && last.games === s.regular_season_games && last.to === s.year - 1) last.to = s.year;
    else runs.push({ league: s.league_code, games: s.regular_season_games, from: s.year, to: s.year });
  }
  return runs;
}

const gamesLabel = (g) => (g == null ? 'No uniform schedule' : `${g} games`);

export async function render({ provider, mode }) {
  const [man, seasonsEnv] = await Promise.all([provider.getManifest(), provider.listSeasons()]);
  const m = man.data;
  const seasons = seasonsEnv.data ?? [];
  const { from, to } = m.coverage.seasons;
  const cls = m.provider === 'mock' ? 'demo' : 'curated';

  const byLeague = new Map();
  for (const s of seasons) {
    const r = byLeague.get(s.league_code) ?? { from: s.year, to: s.year };
    r.from = Math.min(r.from, s.year); r.to = Math.max(r.to, s.year);
    byLeague.set(s.league_code, r);
  }
  const leagueOrder = [...byLeague.entries()].sort((a, b) => a[1].from - b[1].from);
  const lanes = leagueOrder.map(([code, r]) => ({
    label: `${code} seasons`, segments: [{ id: code, label: code, from: r.from, to: r.to, kind: 'identity', cls }],
  }));
  const field = fieldStrip({
    from, to, lanes, lineLabel: `Latest season ${to}`, label: `Seasons from ${from} to ${to}`,
    caption: mode === 'foundation'
      ? 'Each band is a league in the demonstration data. The gold line marks the latest season.'
      : 'Each band is a league in the snapshot. The AFL ran alongside the NFL from 1960 to 1969. The gold line marks the latest season.',
  });

  const lede = mode === 'foundation'
    ? `A fictional demonstration league, ${from} to ${to}, used to build and test the interface.`
    : `Every franchise and every name it played under, ${from} to ${to}, compiled from cited references and pending review.`;

  // Schedule eras for the longest-running league, drawn as a run chart.
  const mainLeague = leagueOrder.length ? leagueOrder[0][0] : null;
  const runs = scheduleRuns(seasons.filter((s) => s.league_code === mainLeague));
  const maxGames = Math.max(1, ...runs.map((r) => r.games ?? 0));
  const totalYears = runs.reduce((n, r) => n + (r.to - r.from + 1), 0) || 1;
  const lengths = new Set(runs.map((r) => r.games));
  const runArt = h('div', { class: 'art-runs' }, runs.map((r) => h('span', {
    'data-empty': String(r.games == null),
    style: { width: `${((r.to - r.from + 1) / totalYears) * 100}%`, height: `${r.games == null ? 18 : 18 + (r.games / maxGames) * 82}%` },
  })));
  const recentRuns = runs.slice(-4).reverse();

  const gate = (id, title, art, countText, body) => h('li', { class: 'gate' },
    h('div', { class: 'gate__art', 'aria-hidden': 'true' }, art),
    h('div', { class: 'gate__body' },
      h('h3', {}, h('a', { href: href(id) }, title)),
      countText != null ? h('p', { class: 'gate__count num' }, countText) : null,
      body));

  const playersAvailable = m.capabilities.players;
  const node = h('div', {},
    h('section', { class: 'hero', 'aria-labelledby': 'hero-title' },
      h('h1', { id: 'hero-title', class: 'hero__title', tabindex: '-1', 'data-page-title': '' }, 'Pro football history, laid out on the field.'),
      h('p', { class: 'hero__lede' }, lede),
      h('div', { class: 'page-header__badges' }, classBadge(cls)),
      h('dl', { class: 'scoreboard' },
        h('div', {}, h('dt', {}, 'Franchises'), h('dd', { class: 'num' }, m.counts.franchises)),
        h('div', {}, h('dt', {}, 'Team names'), h('dd', { class: 'num' }, m.counts.identities + m.counts.merged_seasons)),
        h('div', {}, h('dt', {}, 'Seasons'), h('dd', { class: 'num' }, m.counts.seasons))),
      field.element),

    h('h2', { class: 'section-title' }, 'Start exploring'),
    h('ul', { class: 'gates' },
      gate('teams', 'Franchises', h('div', { class: 'art-plates' }, h('span'), h('span'), h('span')), m.counts.franchises,
        h('p', {}, `${m.counts.franchises_active} active and ${m.counts.franchises_defunct} defunct, with every recorded name and relocation.`)),
      gate('seasons', 'Seasons', h('div', { class: 'art-yards' }), m.counts.seasons,
        h('p', {}, `${yearSpan(from, to)}, by decade and league.`)),
      gate('seasons', 'Schedule lengths', runArt, null, [
        h('p', {}, `${mainLeague ?? 'League'} seasons ran under ${count(lengths.size, 'schedule length')}. Most recent first:`),
        h('ul', { class: 'eras' }, recentRuns.map((r) => h('li', {}, h('span', {}, gamesLabel(r.games)), h('span', { class: 'num' }, yearSpan(r.from, r.to))))),
      ])),

    h('h2', { class: 'section-title' }, 'In later milestones'),
    h('ul', { class: 'later' },
      h('li', {}, h('a', { href: href('players') }, 'Players'),
        h('p', {}, playersAvailable ? `${count(m.counts.players ?? 0, 'demonstration player')} with team history.` : reasonFor(m.provider, 'players')),
        playersAvailable ? classBadge('demo') : classBadge('unavailable')),
      h('li', {}, h('a', { href: href('compare') }, 'Compare'),
        h('p', {}, reasonFor(m.provider, 'compare')), classBadge('unavailable'))),
    unavailableState('Rivalries and championship history', reasonFor(m.provider, 'headToHead')));
  return { title: 'Explore', node };
}
