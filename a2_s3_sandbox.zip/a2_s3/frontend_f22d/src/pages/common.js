// Small helpers shared by pages.
import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { notFoundState } from '../components/states.js';
import { href } from '../app/router.js';

export const crumb = (label, id, params, query) => ({ label, href: id ? href(id, params, query) : null });

export function notFoundPage(title, reason, crumbs = []) {
  return {
    title,
    node: h('div', {}, pageHeader({ crumbs, title }),
      notFoundState(reason, [h('a', { href: '#/' }, 'Go to Explore'), ' or ', h('a', { href: '#/teams' }, 'browse teams'), '.'])),
  };
}

export function link(label, id, params, query) {
  return h('a', { href: href(id, params, query) }, label);
}

// Year ranges with no curated name, between a franchise's names.
export function nameGaps(identities) {
  const gaps = [];
  for (let i = 1; i < identities.length; i += 1) {
    const prevEnd = identities[i - 1].last_season;
    if (prevEnd !== null && identities[i].first_season > prevEnd + 1) {
      gaps.push({ from: prevEnd + 1, to: identities[i].first_season - 1 });
    }
  }
  return gaps;
}
