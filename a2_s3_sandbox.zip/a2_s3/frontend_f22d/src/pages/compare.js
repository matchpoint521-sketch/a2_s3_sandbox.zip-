import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { classBadge } from '../components/data-badge.js';
import { unavailableState } from '../components/states.js';
import { reasonFor } from '../core/capabilities.js';
import { href } from '../app/router.js';
import { crumb } from './common.js';

const TYPES = [
  { id: 'compare-teams', label: 'Team vs team', text: 'Records and per-game scoring over the seasons you choose, with head-to-head history.' },
  { id: 'compare-seasons', label: 'Season vs season', text: 'League context across eras: schedule length, scoring and structure.' },
  { id: 'compare-players', label: 'Player vs player', text: 'Same position group only, using per-game and per-opportunity measures.' },
];

// Decorative marks for each comparison type (hidden from assistive tech).
const GLYPHS = {
  'compare-teams': () => h('span', { class: 'glyph glyph--teams', 'aria-hidden': 'true' }, h('i', { class: 'o' }), h('i', { class: 'los' }), h('i', { class: 'x' })),
  'compare-seasons': () => h('span', { class: 'glyph glyph--seasons', 'aria-hidden': 'true' }, h('i', { class: 'bar' }), h('i', { class: 'bar' })),
  'compare-players': () => h('span', { class: 'glyph glyph--players', 'aria-hidden': 'true' }, h('i', { class: 'who' }, h('i', { class: 'head' })), h('i', { class: 'los' }), h('i', { class: 'who' }, h('i', { class: 'head' }))),
};

const RULES = [
  'Players are compared only within the same position group. There is no all-positions score.',
  'Results are shown category by category with the size of each edge. There is no single winner.',
  'A statistic that was not recorded is shown as not recorded, never as zero.',
  'Counting stats are shown per game when schedules differ in length.',
  'No hypothetical matchups, projections or odds.',
];

export async function render({ provider, route }) {
  const current = TYPES.find((t) => t.id === route.id);
  const crumbs = current ? [crumb('Compare', 'compare'), crumb(current.label)] : [crumb('Explore', 'explore'), crumb('Compare')];
  const manifest = (await provider.getManifest()).data; // every page reads its provider first (fails closed in B)
  let selected = null;
  if (route.id === 'compare-teams' && route.query.a) {
    const env = await provider.getFranchise(route.query.a);
    if (env.status === 'ok') selected = env.data.franchise.display_name;
  }
  if (route.id === 'compare-players' && route.query.a) {
    const env = await provider.getPlayer(route.query.a);
    if (env.status === 'ok') selected = env.data.display_name;
  }
  const playersOff = route.id === 'compare-players' && !manifest.capabilities.players;
  // Same gating as F1: every type is unavailable; Player vs player also needs player data.
  const statusFor = (t) => (t.id === 'compare-players' && !manifest.capabilities.players ? reasonFor(provider.id, 'players') : reasonFor(provider.id, 'compare'));

  const node = h('div', {},
    pageHeader({
      crumbs, title: current ? current.label : 'Compare',
      lede: current ? current.text : 'Choose what to compare. Every comparison explains its method and the data it uses.',
      badges: current ? [classBadge('unavailable')] : [],
      scene: true,
    }),
    h('ul', { class: 'chooser' }, TYPES.map((t) => h('li', {}, h('a', { href: href(t.id, {}, route.query.a && t.id === route.id ? { a: route.query.a } : {}), 'aria-current': t.id === route.id ? 'page' : null },
      GLYPHS[t.id](), h('strong', {}, t.label), h('span', {}, t.text),
      h('span', { class: 'chooser__status' }, classBadge('unavailable'), h('span', {}, statusFor(t))))))),
    selected ? h('p', {}, `Selected: ${selected}. Choosing the second side arrives with comparisons.`) : null,
    current ? unavailableState(`${current.label} is not available yet`, playersOff ? reasonFor(provider.id, 'players') : reasonFor(provider.id, 'compare')) : null,
    h('section', { class: 'panel', 'aria-labelledby': 'rules-title' },
      h('h2', { id: 'rules-title' }, 'How comparisons work'),
      h('ul', { class: 'rules' }, RULES.map((r) => h('li', {}, r)))));
  return { title: current ? current.label : 'Compare', node };
}
