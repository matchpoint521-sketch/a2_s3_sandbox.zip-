import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { recordBadges } from '../components/data-badge.js';
import { unavailableState } from '../components/states.js';
import { reasonFor } from '../core/capabilities.js';
import { href } from '../app/router.js';
import { crumb, notFoundPage } from './common.js';

export async function render({ provider, route }) {
  const { league, year } = route.params;
  const env = await provider.getSeason(league, year);
  if (env.status === 'not_found') return notFoundPage('Season not found', env.meta.reason, [crumb('Seasons', 'seasons'), crumb('Not found')]);
  // F2.2d-A2 (D-A2-6b): when the data has game results, say what this page does not show yet
  // instead of claiming the results are absent. The coverage note comes from the manifest.
  const manifest = (await provider.getManifest()).data;
  const gameCoverage = manifest.capabilities && manifest.capabilities.games && manifest.coverage ? manifest.coverage.games : null;
  const { season: s, league: lg, other_leagues_same_year: others, previous, next, merged_seasons: merged } = env.data;
  const leagueName = lg?.name ?? league;
  const games = s.regular_season_games;
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Seasons', 'seasons'), crumb(`${year} ${league}`)],
      title: `${leagueName}, ${year}`,
      lede: games ? `${games} regular-season games per team.` : 'No uniform regular-season schedule.',
      badges: recordBadges(s),
    }),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'League'), h('dd', {}, leagueName)),
      h('div', {}, h('dt', {}, 'Regular-season games per team'), h('dd', { class: 'num' }, games ?? 'Not uniform')),
      others.length ? h('div', {}, h('dt', {}, 'Also played in ' + year), h('dd', {}, others.map((o, i) => [i ? ', ' : '', h('a', { href: href('season', { league: o.league_code, year }) }, `${o.league_code} ${year}`)]))) : null),
    s.schedule_note ? h('p', {}, s.schedule_note) : null,
    merged.length ? h('p', {}, 'Merged teams this season: ', merged.map((m, i) => [i ? '; ' : '', m.common_name, ' (', m.members.map((mb, j) => [j ? ' and ' : '', h('a', { href: href('team-season', { franchise: mb.franchise_id, year }) }, mb.display_name)]), ')']), '.') : null,
    s.evidence ? h('details', {}, h('summary', {}, 'Evidence'), h('p', {}, s.evidence)) : null,
    gameCoverage
      ? unavailableState('Standings and playoffs', [
        `Season standings and playoff brackets are not shown on this page yet. ${gameCoverage.note}`,
        'Where a season has game data, each team’s games and calculated record are on its team-season page.'])
      : unavailableState('Results, standings and playoffs', reasonFor(provider.id, 'games')),
    h('p', {},
      previous ? h('a', { href: href('season', { league, year: previous.year }) }, `Previous: ${previous.year}`) : null,
      previous && next ? '   ' : null,
      next ? h('a', { href: href('season', { league, year: next.year }) }, `Next: ${next.year}`) : null));
  return { title: `${leagueName}, ${year}`, node };
}
