import { h, append } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { dataTable } from '../components/table.js';
import { recordBadges, classBadge } from '../components/data-badge.js';
import { fieldStrip } from '../components/field-strip.js';
import { yearSpan, identityName } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb, notFoundPage, nameGaps } from './common.js';

export async function render({ provider, route }) {
  const env = await provider.getFranchise(route.params.franchise);
  if (env.status === 'not_found') return notFoundPage('Team not found', env.meta.reason, [crumb('Teams', 'teams'), crumb('Not found')]);
  const { franchise: f, identities, merged_seasons: merged, span } = env.data;

  const segments = identities.map((i) => ({ id: i.identity_id, label: identityName(i), from: i.first_season, to: i.last_season, kind: 'identity', cls: i.class, record: i }));
  const mergedSegs = merged.map((m) => ({ id: m.merged_key, label: m.common_name, from: m.season, to: m.season, kind: 'merged', cls: m.class, record: m }));
  const lanes = [{ label: 'Names', segments }];
  if (mergedSegs.length) lanes.push({ label: 'Merged seasons', segments: mergedSegs });
  const initial = segments[segments.length - 1];

  const detail = h('div', { class: 'panel', 'aria-live': 'polite' });
  const rowsById = new Map();

  function showDetail(seg) {
    const r = seg.record;
    const isMerged = seg.kind === 'merged';
    detail.replaceChildren();
    append(detail, [
      h('h2', {}, seg.label),
      h('p', { class: 'num' }, isMerged ? `Merged team, ${r.season} season only` : yearSpan(r.first_season, r.last_season)),
      h('p', { class: 'page-header__badges' }, recordBadges(r)),
      isMerged ? h('p', {}, 'Played as one team representing ', r.members.map((mb, i) => [i ? ' and ' : '', h('a', { href: href('team', { franchise: mb.franchise_id }) }, mb.display_name)]), '.') : null,
      isMerged && r.identity?.aliases_note ? h('p', {}, r.identity.aliases_note) : null,
      h('p', {}, h('a', { href: href('team-season', { franchise: f.franchise_id, year: seg.from }) }, `Open the ${seg.from} season`)),
      r.evidence ? h('details', {}, h('summary', {}, 'Evidence'), h('p', {}, r.evidence)) : null]);
    for (const [id, tr] of rowsById) tr.setAttribute('aria-selected', String(id === seg.id));
  }

  const field = fieldStrip({
    from: Math.min(span.from, ...segments.map((s) => s.from)), to: span.to, lanes, selected: initial.id,
    label: `${f.display_name}: names by season`,
    caption: 'Select a name to move the gold line to its first season. Gaps are seasons with no recorded name.',
    onSelect: showDetail,
  });

  const nameTable = dataTable({
    caption: 'Names in order. Ranges are curated and pending review.',
    columns: [
      { label: 'Name', cell: (i) => h('button', { type: 'button', class: 'action', onclick: () => field.select(i.identity_id) }, identityName(i)) },
      { label: 'Seasons', cell: (i) => h('span', { class: 'num' }, yearSpan(i.first_season, i.last_season)) },
      { label: 'First season', cell: (i) => h('a', { href: href('team-season', { franchise: f.franchise_id, year: i.first_season }) }, String(i.first_season)) },
      { label: 'Record', cell: (i) => h('span', { class: 'page-header__badges' }, recordBadges(i)) },
    ],
    rows: identities,
    rowAttrs: (i) => { const tr = { 'data-id': i.identity_id }; return tr; },
  });
  nameTable.querySelectorAll('tbody tr').forEach((tr) => rowsById.set(tr.dataset.id, tr));

  const gaps = nameGaps(identities);
  const years = [];
  for (let y = span.from; y <= span.to; y += 1) years.push(y);
  const yearSelect = h('select', { id: 'season-jump' }, years.map((y) => h('option', { value: y, selected: y === initial.from }, y)));

  showDetail(initial);
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Explore', 'explore'), crumb('Teams', 'teams'), crumb(f.display_name)],
      title: f.display_name,
      lede: f.status === 'active' ? `Active franchise since ${f.first_nfl_season}.` : `Defunct franchise, ${yearSpan(f.first_nfl_season, f.last_season)}.`,
      badges: recordBadges(f),
      actions: [h('a', { class: 'action', href: href('compare-teams', {}, { a: f.franchise_id }) }, 'Compare with another team')],
    }),
    h('dl', { class: 'facts' },
      h('div', {}, h('dt', {}, 'Seasons'), h('dd', { class: 'num' }, yearSpan(f.first_nfl_season, f.last_season))),
      h('div', {}, h('dt', {}, 'Status'), h('dd', {}, f.status === 'active' ? 'Active' : 'Defunct')),
      h('div', {}, h('dt', {}, 'Origin league'), h('dd', {}, f.origin_league)),
      h('div', {}, h('dt', {}, 'Names used'), h('dd', { class: 'num' }, String(identities.length + merged.length)))),
    f.origin_note ? h('p', {}, f.origin_note) : null,
    field.element,
    h('div', { class: 'split' },
      h('div', {},
        h('h2', {}, 'Names'), nameTable,
        gaps.length ? h('p', {}, `No team name is recorded for ${gaps.map((g) => yearSpan(g.from, g.to)).join(' and ')}. The club may not have played in those seasons. This comes from the curated ranges and is pending review.`) : null,
        merged.length ? h('p', {}, `In ${merged.map((m) => m.season).join(' and ')}, this franchise played as part of a merged team.`) : null,
        h('form', { class: 'filters', onsubmit: (e) => { e.preventDefault(); window.location.hash = href('team-season', { franchise: f.franchise_id, year: Number(yearSelect.value) }); } },
          h('label', { for: 'season-jump' }, 'Go to a season', yearSelect),
          h('button', { type: 'submit', class: 'action' }, 'Open season'))),
      h('aside', { 'aria-label': 'Selected name' }, detail)),
    f.evidence ? h('details', {}, h('summary', {}, 'Franchise evidence'), h('p', {}, f.evidence)) : null,
    h('p', {}, classBadge('unavailable'), ' Season records, championships and rosters arrive with game data in later milestones.'));
  return { title: f.display_name, node };
}
