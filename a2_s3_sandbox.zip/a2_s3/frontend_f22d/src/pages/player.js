import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { dataTable } from '../components/table.js';
import { classBadge, recordBadges } from '../components/data-badge.js';
import { unavailableState } from '../components/states.js';
import { reasonFor } from '../core/capabilities.js';
import { yearSpan } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb, notFoundPage } from './common.js';

export async function render({ provider, route }) {
  const env = await provider.getPlayer(route.params.player);
  const crumbs = [crumb('Players', 'players'), crumb(env.data?.display_name ?? 'Player')];
  if (env.status === 'unavailable') {
    return { title: 'Player', node: h('div', {}, pageHeader({ crumbs, title: 'Player', badges: [classBadge('unavailable')] }), unavailableState('Player data is not in this version', env.meta.reason)) };
  }
  if (env.status === 'not_found') return notFoundPage('Player not found', env.meta.reason, crumbs);
  const p = env.data;
  const node = h('div', {},
    pageHeader({ crumbs, title: p.display_name, lede: `${p.position}. Born ${p.birth_year}.`, badges: recordBadges(p),
      actions: [h('a', { class: 'action', href: href('compare-players', {}, { a: p.player_id }) }, `Compare with another ${p.position}`)] }),
    h('h2', {}, 'Teams'),
    dataTable({
      caption: 'Stints in order.',
      columns: [
        { label: 'Team', cell: (s) => (s.franchise ? h('a', { href: href('team', { franchise: s.franchise_id }) }, s.franchise.display_name) : s.franchise_id) },
        { label: 'Seasons', cell: (s) => h('span', { class: 'num' }, yearSpan(s.first_season, s.last_season)) },
        { label: 'First season with team', cell: (s) => h('a', { href: href('team-season', { franchise: s.franchise_id, year: s.first_season }) }, String(s.first_season)) },
      ],
      rows: p.stints,
    }),
    unavailableState('Statistics', reasonFor(provider.id, 'playerStats')));
  return { title: p.display_name, node };
}
