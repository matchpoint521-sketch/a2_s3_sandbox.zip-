import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { recordBadges, classBadge } from '../components/data-badge.js';
import { emptyState } from '../components/states.js';
import { yearSpan } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb } from './common.js';

const STATUSES = [['all', 'All'], ['active', 'Active'], ['defunct', 'Defunct']];

export async function render({ provider, route }) {
  let status = STATUSES.some(([v]) => v === route.query.status) ? route.query.status : 'all';
  let query = route.query.q ?? '';
  const man = (await provider.getManifest()).data;
  const cls = man.provider === 'mock' ? 'demo' : 'curated';

  const results = h('div', {});
  const { from: allFrom, to: allTo } = man.coverage.seasons;
  const span = allTo - allFrom + 1;

  // One card per franchise: its latest name, its years, and where those years sit
  // on the full span of seasons in this data. Everything shown comes from the list record.
  function card(f) {
    const latest = f.latest_identity;
    const place = latest?.location_name ?? null;
    const name = latest?.nickname ?? f.display_name;
    const first = f.first_nfl_season;
    const last = f.last_season ?? allTo;
    const run = first == null ? null : h('span', { style: {
      left: `${((first - allFrom) / span) * 100}%`, width: `${((last - first + 1) / span) * 100}%`,
    } });
    return h('li', { class: 'team-card', 'data-status': f.status },
      h('a', { class: 'team-card__link', href: href('team', { franchise: f.franchise_id }) },
        place ? h('span', { class: 'team-card__place' }, place) : null,
        h('span', { class: 'team-card__name' }, name),
        h('span', { class: 'team-card__years' }, yearSpan(f.first_nfl_season, f.last_season))),
      h('span', { class: 'team-card__run', 'aria-hidden': 'true', title: `Seasons within ${allFrom}–${allTo}` }, run),
      h('div', { class: 'team-card__meta' },
        h('span', {}, `${f.identity_count} ${f.identity_count === 1 ? 'name' : 'names'}`),
        h('span', {}, `Origin ${f.origin_league}`),
        recordBadges(f)));
  }
  const countLine = h('p', { class: 'result-count', 'aria-live': 'polite' });

  async function refresh() {
    const env = await provider.listFranchises({ status, query });
    const rows = env.data ?? [];
    countLine.textContent = `Showing ${rows.length} of ${man.counts.franchises} franchises`;
    history.replaceState(null, '', href('teams', {}, { status: status === 'all' ? null : status, q: query || null }));
    if (!rows.length) {
      results.replaceChildren(emptyState('No franchises match', `Nothing matches "${query}" with the status "${status}". Clear the search or choose All.`));
      return;
    }
    results.replaceChildren(h('ul', { class: 'team-grid', 'aria-label': 'Franchises' }, rows.map(card)));
  }

  const totals = { all: man.counts.franchises, active: man.counts.franchises_active, defunct: man.counts.franchises_defunct };
  const search = h('input', { type: 'search', value: query, placeholder: 'Name or city', oninput: (e) => { query = e.target.value; refresh(); } });
  const seg = h('fieldset', { class: 'segmented' }, h('legend', {}, 'Status'),
    STATUSES.map(([value, label]) => h('label', {},
      h('input', { type: 'radio', name: 'status', value, checked: value === status, onchange: () => { status = value; refresh(); } }),
      h('span', {}, label, h('small', { class: 'num' }, String(totals[value]))))));

  await refresh();
  const node = h('div', {},
    pageHeader({
      crumbs: [crumb('Explore', 'explore'), crumb('Teams')],
      title: 'Teams',
      lede: 'Every franchise, including the ones that folded. A franchise keeps its history through relocations and renames.',
      badges: [classBadge(cls)],
      scene: true,
    }),
    h('div', { class: 'filters' }, seg, h('label', {}, 'Filter by name', search)),
    countLine, results);
  return { title: 'Teams', node };
}
