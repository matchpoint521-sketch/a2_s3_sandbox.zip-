import { h } from '../components/dom.js';
import { pageHeader } from '../components/page-header.js';
import { dataTable } from '../components/table.js';
import { classBadge } from '../components/data-badge.js';
import { emptyState, unavailableState } from '../components/states.js';
import { yearSpan } from '../core/format.js';
import { href } from '../app/router.js';
import { crumb } from './common.js';

export async function render({ provider, route }) {
  const env = await provider.listPlayers({ query: route.query.q ?? '' });
  const header = (badges) => pageHeader({
    crumbs: [crumb('Explore', 'explore'), crumb('Players')], title: 'Players',
    lede: 'Careers by team and season. Players are compared only with others in the same position group.', badges, scene: true,
  });
  if (env.status === 'unavailable') {
    return { title: 'Players', node: h('div', {}, header([classBadge('unavailable')]), unavailableState('Player data is not in this version', env.meta.reason)) };
  }
  if (env.status === 'empty') {
    return { title: 'Players', node: h('div', {}, header([]), emptyState('No players', 'This data has no player records.')) };
  }
  const node = h('div', {}, header([classBadge('demo')]),
    dataTable({
      caption: 'Demonstration players. Fictional.',
      columns: [
        { label: 'Player', cell: (p) => h('a', { href: href('player', { player: p.player_id }) }, p.display_name) },
        { label: 'Position', cell: (p) => p.position },
        { label: 'Seasons', cell: (p) => h('span', { class: 'num' }, yearSpan(Math.min(...p.stints.map((s) => s.first_season)), Math.max(...p.stints.map((s) => s.last_season)))) },
        { label: 'Teams', numeric: true, cell: (p) => String(p.stints.length) },
      ],
      rows: env.data,
    }));
  return { title: 'Players', node };
}
