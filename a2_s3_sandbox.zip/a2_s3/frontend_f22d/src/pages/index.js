// Route id → page module. Pages receive ctx.provider and never import a provider.
import * as explore from './explore.js';
import * as compare from './compare.js';
import * as teams from './teams.js';
import * as team from './team.js';
import * as teamSeason from './team-season.js';
import * as players from './players.js';
import * as player from './player.js';
import * as seasons from './seasons.js';
import * as season from './season.js';
import * as game from './game.js';
import * as search from './search.js';
import * as data from './data.js';
import * as notFound from './not-found.js';

export const PAGES = Object.freeze({
  explore, compare, 'compare-teams': compare, 'compare-seasons': compare, 'compare-players': compare,
  teams, team, 'team-season': teamSeason, players, player, seasons, season, game, search, data,
  'not-found': notFound,
});
