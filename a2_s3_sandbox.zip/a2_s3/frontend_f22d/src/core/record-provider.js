// Shared query logic over the common JSON file set. Both providers are thin
// configurations of this factory; they differ in data path, expected data class,
// and what happens when their files are missing. There is no cross-provider fallback.
import { envelope } from './envelope.js';
import { reasonFor } from './capabilities.js';
import { DataLoadError, FileMissingError } from './errors.js';
import { identitiesForYear, identityName, normalize } from './format.js';
import { makeGameContext, validateShard, validateIndex, validateRecords, indexLookup, checkIndexForSeason, shardLookup, recordLookups, checkSeasonRecords, coverageState, validateFilters, filterGames, isGameId } from './games.js';

const RECORD_FILES = ['leagues', 'seasons', 'franchises', 'identities', 'merged_seasons'];

export function createRecordProvider({ id, base, loader, expectedClass, sources, onManifestMissing }) {
  let state = null;
  // Game files (F2.2d-A1): one cached promise per file or season, loaded on first use. A failed
  // load or check removes only its own entry (D-A1-13 option A): the failing season is retried
  // on the next call, other seasons stay cached, and nothing partial is ever returned. The
  // loader keeps its own cache of parsed files, so a retry sees new bytes only after a page
  // reload (or with a loader that re-reads); see the A1 handoff.
  const gameState = new Map();

  async function readFile(name) {
    const body = await loader.json(`${base}${name}.json`);
    if (!body || body.class !== expectedClass || !Array.isArray(body.records)) {
      throw new DataLoadError(`${base}${name}.json`, `expected "${expectedClass}" records, found "${body && body.class}"`);
    }
    for (const r of body.records) {
      if (r.class !== expectedClass) throw new DataLoadError(`${base}${name}.json`, `record of class "${r.class}" in a ${expectedClass} file`);
    }
    return body.records;
  }

  async function readManifest() {
    let m;
    try {
      m = await loader.json(`${base}manifest.json`);
    } catch (e) {
      if (e instanceof FileMissingError && onManifestMissing) onManifestMissing(e);
      throw e;
    }
    if (!m || m.provider !== id) throw new DataLoadError(`${base}manifest.json`, `manifest belongs to "${m && m.provider}", not "${id}"`);
    return m;
  }

  function load() {
    if (!state) {
      state = (async () => {
        const manifest = await readManifest();
        const loaded = await Promise.all(RECORD_FILES.map(readFile));
        const [leagues, seasons, franchises, identities, merged] = loaded;
        const players = manifest.capabilities.players ? await readFile('players') : [];
        const franchiseById = new Map(franchises.map((f) => [f.franchise_id, f]));
        const identitiesByFranchise = new Map();
        for (const i of identities) {
          if (!franchiseById.has(i.franchise_id)) throw new DataLoadError(`${base}identities.json`, `unknown franchise ${i.franchise_id}`);
          if (!identitiesByFranchise.has(i.franchise_id)) identitiesByFranchise.set(i.franchise_id, []);
          identitiesByFranchise.get(i.franchise_id).push(i);
        }
        for (const list of identitiesByFranchise.values()) list.sort((a, b) => a.first_season - b.first_season);
        return {
          manifest, leagues, seasons, franchises, identities, merged, players,
          franchiseById, identitiesByFranchise,
          leagueByCode: new Map(leagues.map((l) => [l.league_code, l])),
          identityById: new Map(identities.map((i) => [i.identity_id, i])),
          seasonByKey: new Map(seasons.map((x) => [`${x.league_code}-${x.year}`, x])),
          gameContext: manifest.capabilities.games ? makeGameContext({ manifest, franchises, identities, seasons }) : null,
          playerById: new Map(players.map((p) => [p.player_id, p])),
          from: manifest.coverage.seasons.from,
          to: manifest.coverage.seasons.to,
        };
      })();
      state.catch(() => { state = null; }); // a later call may retry
    }
    return state;
  }

  const meta = (extra = {}) => ({ classes: [expectedClass], sources, verification: expectedClass === 'curated' ? 'pending_review' : null, ...extra });
  const unavailable = (key) => envelope.unavailable(id, reasonFor(id, key));
  const list = (items, extra) => (items.length ? envelope.ok(id, items, meta(extra)) : envelope.empty(id, items, meta(extra)));

  // ---------------------------------------------------------------- game files (F2.2d-A1)

  function cached(key, make) {
    if (!gameState.has(key)) {
      const p = make();
      gameState.set(key, p);
      p.catch(() => { if (gameState.get(key) === p) gameState.delete(key); });
    }
    return gameState.get(key);
  }

  function refuse(path, problems) {
    if (problems.length) {
      const more = problems.length > 3 ? ` (and ${problems.length - 3} more)` : '';
      throw new DataLoadError(path, problems.slice(0, 3).join('; ') + more);
    }
  }

  function gameIndex(s) {
    return cached('index', async () => {
      const path = `${base}games/index.json`;
      const body = await loader.json(path);
      refuse(path, validateIndex(body, s.gameContext));
      return indexLookup(body);
    });
  }

  function gameRecords(s) {
    return cached('records', async () => {
      const path = `${base}team_season_records.json`;
      const body = await loader.json(path);
      refuse(path, validateRecords(body, s.gameContext));
      const { bySeason, byFranchise } = recordLookups(body);
      return { label: body.label, formula: body.formula, bySeason, byFranchise };
    });
  }

  // One season's games, accepted only after the shard, its index entries and its team-season
  // records have all been checked (D-F22d-9).
  function seasonGames(s, year) {
    return cached(`season:${year}`, async () => {
      const path = `${base}games/${year}.json`;
      const body = await loader.json(path);
      refuse(path, validateShard(body, year, s.gameContext));
      refuse(path, checkIndexForSeason(await gameIndex(s), year, body));
      const records = await gameRecords(s);
      refuse(`${base}team_season_records.json`, checkSeasonRecords(year, body, records.bySeason.get(year) ?? []));
      return { games: body.records, byId: shardLookup(body) };
    });
  }

  // Envelope meta for game payloads (D-A1-10): the exact classes present, every source used,
  // game coverage, and a verification value only when a single class is present.
  function gameMeta(s, classes, extra = {}) {
    const sorted = [...new Set(classes)].sort();
    const single = sorted.length === 1 ? sorted[0] : null;
    const usesGames = sorted.includes('source') || sorted.includes('derived');
    return {
      classes: sorted,
      sources: usesGames ? [...sources, s.manifest.games_source.id] : sources,
      verification: single === 'source' ? 'single_source_pinned' : single === 'curated' ? 'pending_review' : null,
      coverage: s.manifest.coverage.games,
      ...extra,
    };
  }

  function coverageText(s) {
    const c = s.manifest.coverage.games;
    return `Game results in this snapshot cover ${c.league} ${c.from}–${c.to} only`;
  }

  // Coverage reason for a season without game data, or null when the season is covered.
  function gapReason(s, league, year) {
    const where = coverageState(league, year, s.gameContext);
    if (where === 'covered') return null;
    if (where === 'not_completed') return { state: 'not_completed', reason: `The ${league} ${year} season is not completed, so its games are not in this snapshot.` };
    if (where === 'unknown') return { state: 'unknown', reason: `There is no ${league} ${year} season in this data.` };
    return { state: 'outside_coverage', reason: `${coverageText(s)}. ${league} ${year} has no game data here; that is missing data, not zero games.` };
  }

  // Results block for getTeamSeason (no aggregate figures; the record is stored data).
  async function teamResults(s, franchiseId, year, hasName) {
    const none = (state, reason) => ({ results: { state, record: null, reason, label: null, formula: null }, games: null, classes: [] });
    if (!s.manifest.capabilities.games) return none('unavailable', reasonFor(id, 'games'));
    const league = s.seasonByKey.has(`NFL-${year}`) ? 'NFL' : 'AFL';
    const gap = gapReason(s, league, year);
    if (gap) return none(gap.state === 'unknown' ? 'outside_coverage' : gap.state, gap.reason);
    const records = await gameRecords(s);
    const record = (records.bySeason.get(year) ?? []).find((r) => r.franchise_id === franchiseId) ?? null;
    if (!record) {
      const why = hasName ? `No team-season record for this franchise in ${year}.` : `This franchise did not play in ${year}.`;
      return none('no_games', why);
    }
    const season = await seasonGames(s, year);
    const games = season.games.filter((g) => g.home.franchise_id === franchiseId || g.away.franchise_id === franchiseId);
    return { results: { state: 'available', record, reason: null, label: records.label, formula: records.formula }, games, classes: ['derived', 'source'] };
  }

  function gameIdentities(s, games) {
    const seen = new Map();
    for (const g of games) for (const side of [g.home, g.away]) if (!seen.has(side.identity_id)) seen.set(side.identity_id, s.identityById.get(side.identity_id) ?? null);
    return [...seen.values()];
  }

  // Merged seasons carry member franchise names so pages never show raw ids.
  function withMembers(s, m) {
    return { ...m, members: m.franchise_ids.map((fid) => ({ franchise_id: fid, display_name: s.franchiseById.get(fid)?.display_name ?? fid })) };
  }

  function franchiseSummary(s, f) {
    const ids = s.identitiesByFranchise.get(f.franchise_id) ?? [];
    return { ...f, latest_identity: ids[ids.length - 1] ?? null, identity_count: ids.length };
  }

  return {
    id,

    async getManifest() {
      const s = await load();
      return envelope.ok(id, s.manifest, meta({ coverage: { from: s.from, to: s.to } }));
    },

    async listFranchises({ status = 'all', query = '' } = {}) {
      const s = await load();
      const q = normalize(query);
      const items = s.franchises
        .filter((f) => status === 'all' || f.status === status)
        .map((f) => franchiseSummary(s, f))
        .filter((f) => !q || normalize(f.display_name).includes(q)
          || (s.identitiesByFranchise.get(f.franchise_id) ?? []).some((i) => normalize(identityName(i)).includes(q)))
        .sort((a, b) => a.display_name.localeCompare(b.display_name, 'en'));
      return list(items);
    },

    async getFranchise(franchiseId) {
      const s = await load();
      const f = s.franchiseById.get(franchiseId);
      if (!f) return envelope.notFound(id, `No franchise has the id "${franchiseId}".`);
      return envelope.ok(id, {
        franchise: f,
        identities: s.identitiesByFranchise.get(franchiseId) ?? [],
        merged_seasons: s.merged.filter((m) => m.franchise_ids.includes(franchiseId)).map((m) => withMembers(s, m)),
        span: { from: f.first_nfl_season, to: f.last_season ?? s.to },
        coverage: { from: s.from, to: s.to },
      }, meta());
    },

    async getTeamSeason(franchiseId, year) {
      const s = await load();
      const f = s.franchiseById.get(franchiseId);
      if (!f) return envelope.notFound(id, `No franchise has the id "${franchiseId}".`);
      if (!Number.isInteger(year) || year < s.from || year > s.to) {
        return envelope.notFound(id, `${year} is outside the seasons in this data (${s.from}–${s.to}).`);
      }
      const identities = identitiesForYear(s.identitiesByFranchise.get(franchiseId) ?? [], year, s.to);
      const merged = s.merged.filter((m) => m.season === year && m.franchise_ids.includes(franchiseId)).map((m) => withMembers(s, m));
      const seasons = s.seasons.filter((x) => x.year === year);
      const hasName = identities.length > 0 || merged.length > 0;
      const r = await teamResults(s, franchiseId, year, hasName);
      const data = { franchise: f, year, identities, merged, seasons, games: r.games, results: r.results, span: { from: f.first_nfl_season, to: f.last_season ?? s.to } };
      const m = r.classes.length ? gameMeta(s, [expectedClass, ...r.classes]) : meta();
      if (!hasName) {
        return envelope.empty(id, data, { ...m, reason: `No name is recorded for this franchise in ${year}. It may not have played that season.` });
      }
      return envelope.ok(id, data, m);
    },

    async listSeasons({ league = 'all' } = {}) {
      const s = await load();
      return list(s.seasons.filter((x) => league === 'all' || x.league_code === league), { coverage: { from: s.from, to: s.to } });
    },

    async getSeason(leagueCode, year) {
      const s = await load();
      const season = s.seasons.find((x) => x.league_code === leagueCode && x.year === year);
      if (!season) return envelope.notFound(id, `There is no ${leagueCode} ${year} season in this data.`);
      const sameYear = s.seasons.filter((x) => x.year === year && x.league_code !== leagueCode);
      const ofLeague = s.seasons.filter((x) => x.league_code === leagueCode);
      const idx = ofLeague.indexOf(season);
      return envelope.ok(id, {
        season, league: s.leagueByCode.get(leagueCode) ?? null, other_leagues_same_year: sameYear,
        previous: ofLeague[idx - 1] ?? null, next: ofLeague[idx + 1] ?? null,
        merged_seasons: s.merged.filter((m) => m.season === year).map((m) => withMembers(s, m)),
      }, meta());
    },

    async getGame(gameId) {
      const s = await load();
      if (!s.manifest.capabilities.games) return unavailable('games');
      if (!isGameId(gameId)) return envelope.notFound(id, `"${gameId}" is not a game id in this data.`);
      const year = (await gameIndex(s)).get(gameId);
      if (year === undefined) return envelope.notFound(id, `No game has the id "${gameId}".`);
      const game = (await seasonGames(s, year)).byId.get(gameId);
      return envelope.ok(id, {
        game,
        home_identity: s.identityById.get(game.home.identity_id) ?? null,
        away_identity: s.identityById.get(game.away.identity_id) ?? null,
        season: s.seasonByKey.get(`${game.league_code}-${year}`) ?? null,
        game_type_label: s.manifest.game_types[game.game_type] ?? game.game_type,
      }, gameMeta(s, [expectedClass, 'source']));
    },

    async getHeadToHead() {
      const s = await load();
      return s.manifest.capabilities.headToHead ? envelope.unavailable(id, 'Series records are not implemented yet.') : unavailable('headToHead');
    },

    async listPlayers({ query = '' } = {}) {
      const s = await load();
      if (!s.manifest.capabilities.players) return unavailable('players');
      const q = normalize(query);
      return list(s.players.filter((p) => !q || normalize(p.display_name).includes(q))
        .sort((a, b) => a.display_name.localeCompare(b.display_name, 'en')));
    },

    async getPlayer(playerId) {
      const s = await load();
      if (!s.manifest.capabilities.players) return unavailable('players');
      const p = s.playerById.get(playerId);
      if (!p) return envelope.notFound(id, `No player has the id "${playerId}".`);
      const stints = p.stints.map((st) => ({ ...st, franchise: s.franchiseById.get(st.franchise_id) ?? null }));
      return envelope.ok(id, { ...p, stints }, meta());
    },

    async getStatCoverage() {
      await load();
      return unavailable('statCoverage');
    },

    async search(query) {
      const s = await load();
      const q = normalize(query);
      if (q.length < 2) return envelope.empty(id, { franchises: [], seasons: [], players: [], notes: [] }, meta({ reason: 'Type at least two characters.' }));
      const franchises = s.franchises.filter((f) => normalize(f.display_name).includes(q)
        || (s.identitiesByFranchise.get(f.franchise_id) ?? []).some((i) => normalize(identityName(i)).includes(q)))
        .map((f) => franchiseSummary(s, f)).sort((a, b) => a.display_name.localeCompare(b.display_name, 'en'));
      const seasons = /^\d{4}$/.test(q) ? s.seasons.filter((x) => String(x.year) === q) : [];
      const notes = [];
      let players = [];
      if (s.manifest.capabilities.players) players = s.players.filter((p) => normalize(p.display_name).includes(q));
      else notes.push(reasonFor(id, 'players'));
      const data = { franchises, seasons, players, notes };
      const total = franchises.length + seasons.length + players.length;
      return total ? envelope.ok(id, data, meta()) : envelope.empty(id, data, meta({ reason: `Nothing matches "${query}".` }));
    },

    async listSeasonGames(league, year, filters = {}) {
      const s = await load();
      if (!s.manifest.capabilities.games) return unavailable('games');
      const bad = validateFilters(filters);
      if (bad.length) return envelope.notFound(id, `Unknown game filter: ${bad.join('; ')}.`);
      const gap = gapReason(s, league, year);
      if (gap && gap.state === 'unknown') return envelope.notFound(id, gap.reason);
      if (gap) return envelope.unavailable(id, gap.reason, { coverage: s.manifest.coverage.games });
      const games = filterGames((await seasonGames(s, year)).games, filters);
      const data = { season: s.seasonByKey.get(`${league}-${year}`), filters: { week: filters.week ?? null, type: filters.type ?? null }, games, identities: gameIdentities(s, games) };
      if (!games.length) return envelope.empty(id, data, gameMeta(s, [expectedClass], { reason: 'No games match these filters.' }));
      return envelope.ok(id, data, gameMeta(s, [expectedClass, 'source']));
    },

    async getFranchiseRecords(franchiseId) {
      const s = await load();
      if (!s.manifest.capabilities.games) return unavailable('games');
      const f = s.franchiseById.get(franchiseId);
      if (!f) return envelope.notFound(id, `No franchise has the id "${franchiseId}".`);
      const records = await gameRecords(s);
      // Season by season under the name used that season; no totals across seasons (D-A1-6).
      const rows = (records.byFranchise.get(franchiseId) ?? []).map((r) => ({ record: r, identity: s.identityById.get(r.identity_id) ?? null }));
      const data = { franchise: f, rows, label: records.label, formula: records.formula };
      if (!rows.length) return envelope.empty(id, data, gameMeta(s, [expectedClass], { reason: `${coverageText(s)}; this franchise has no team-season in that range.` }));
      return envelope.ok(id, data, gameMeta(s, [expectedClass, 'derived']));
    },
  };
}
