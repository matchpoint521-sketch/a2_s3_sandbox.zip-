// Typed errors shared by providers and pages.
export class DataLoadError extends Error {
  constructor(path, cause) {
    super(`Could not load ${path}${cause ? `: ${cause}` : ''}`);
    this.name = 'DataLoadError';
    this.path = path;
  }
}

export class FileMissingError extends DataLoadError {
  constructor(path) {
    super(path, 'file not found');
    this.name = 'FileMissingError';
  }
}

// Version B only: the snapshot has not been built. Never triggers a fallback.
export class SnapshotUnavailable extends Error {
  constructor(detail) {
    super('The data snapshot has not been built.' + (detail ? ` ${detail}` : ''));
    this.name = 'SnapshotUnavailable';
  }
}
