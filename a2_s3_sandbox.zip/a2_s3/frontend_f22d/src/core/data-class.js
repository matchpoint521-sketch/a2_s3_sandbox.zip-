// The five data classes. Pages render these; they never mix them silently.
export const DATA_CLASSES = Object.freeze({
  source: {
    label: 'Source data',
    description: 'Taken from a pinned source file. The verification level is shown with it.',
  },
  curated: {
    label: 'Curated · pending review',
    description: 'Compiled by Velora from cited references. Not historically certified; every record is pending review.',
  },
  derived: {
    label: 'Derived',
    description: 'Calculated by Velora from other values. The formula is shown with the value.',
  },
  demo: {
    label: 'Demonstration',
    description: 'Fictional teams and players used to develop the interface. Not NFL history.',
  },
  unavailable: {
    label: 'Not available',
    description: 'Not recorded by any source we use, or not loaded yet. Never shown as zero.',
  },
});

export const CLASS_KEYS = Object.keys(DATA_CLASSES);
