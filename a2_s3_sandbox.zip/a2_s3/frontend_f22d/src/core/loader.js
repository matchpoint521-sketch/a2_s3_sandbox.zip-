// Browser loader: reads JSON relative to the page. Providers own their data paths.
import { DataLoadError, FileMissingError } from './errors.js';

export function browserLoader(base = document.baseURI) {
  const cache = new Map();
  return {
    json(path) {
      if (!cache.has(path)) {
        const p = fetch(new URL(path, base), { cache: 'no-store' })
          .then(async (res) => {
            if (res.status === 404) throw new FileMissingError(path);
            if (!res.ok) throw new DataLoadError(path, `HTTP ${res.status}`);
            try { return await res.json(); }
            catch (e) { throw new DataLoadError(path, 'invalid JSON'); }
          }, (e) => { throw new DataLoadError(path, e.message); });
        p.catch(() => cache.delete(path)); // allow retry after failure
        cache.set(path, p);
      }
      return cache.get(path);
    },
  };
}
