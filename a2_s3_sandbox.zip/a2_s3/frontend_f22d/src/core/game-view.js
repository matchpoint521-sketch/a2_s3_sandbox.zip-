// Pure view helpers for the game and team-season pages (F2.2d-A2). No DOM, no I/O, no
// shared state: every function reads its arguments, never changes them, and returns new
// strings or plain objects. Pages turn these into elements; Node tests check them directly.
// Nothing here invents a value: a missing input gives null (or a stated label), never 0.
import { identityName } from './format.js';

export const MONTHS = Object.freeze(['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December']);
export const NAME_MISSING = 'Name not recorded';
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

// "2022-09-08" → "September 8, 2022", read as text (no Date object, so no time-zone shift).
// Anything that is not a calendar-shaped string is returned unchanged rather than guessed.
export function formatGameDate(iso) {
  const m = typeof iso === 'string' ? ISO_DATE.exec(iso) : null;
  if (!m) return typeof iso === 'string' ? iso : null;
  const month = Number(m[2]);
  const day = Number(m[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return iso;
  return `${MONTHS[month - 1]} ${day}, ${m[1]}`;
}

// The name a team used in that game or season, from its identity record (never the current name).
export function sideName(identity) {
  const name = identityName(identity);
  return name ? name : NAME_MISSING;
}

export function isPostseason(game) {
  return game.game_type !== 'REG';
}

// "Week 1" for regular-season games; the round label for postseason games.
export function stageText(game, labels = {}) {
  if (!isPostseason(game)) return `Week ${game.week}`;
  return labels[game.game_type] ?? game.game_type;
}

export function scoreText(a, b) {
  return `${a}–${b}`;
}

// Winner by the approved formula: more points wins, equal points is a tie.
export function gameOutcome(game) {
  if (game.home.score === game.away.score) return { tie: true, winner: null, loser: null };
  const homeWon = game.home.score > game.away.score;
  return { tie: false, winner: homeWon ? 'home' : 'away', loser: homeWon ? 'away' : 'home' };
}

// "Buffalo Bills at Los Angeles Rams"; "vs." when the source marks a neutral site.
export function matchupTitle(game, awayName, homeName) {
  return `${awayName} ${game.neutral_site ? 'vs.' : 'at'} ${homeName}`;
}

// "Final" or "Final, overtime".
export function finalText(game) {
  return game.overtime ? 'Final, overtime' : 'Final';
}

// "Buffalo Bills won" or "Tie".
export function outcomeText(game, awayName, homeName) {
  const o = gameOutcome(game);
  if (o.tie) return 'Tie';
  return `${o.winner === 'home' ? homeName : awayName} won`;
}

// One game from one team's side. Returns null when the franchise did not play in the game.
export function teamResult(game, franchiseId) {
  let side = null;
  if (game.home.franchise_id === franchiseId) side = 'home';
  else if (game.away.franchise_id === franchiseId) side = 'away';
  if (!side) return null;
  const other = side === 'home' ? 'away' : 'home';
  const me = game[side];
  const op = game[other];
  let letter = 'T';
  let word = 'Tie';
  if (me.score > op.score) { letter = 'W'; word = 'Win'; }
  else if (me.score < op.score) { letter = 'L'; word = 'Loss'; }
  const prefix = game.neutral_site || side === 'home' ? 'vs.' : 'at';
  return {
    side, opponentSide: other, opponentFranchiseId: op.franchise_id, opponentIdentityId: op.identity_id,
    letter, word, teamScore: me.score, opponentScore: op.score, score: scoreText(me.score, op.score),
    prefix, neutral: game.neutral_site === true, overtime: game.overtime === true,
  };
}

// Regular season and postseason games, each in the provider's stored order (not re-sorted).
export function splitGames(games) {
  return { regular: games.filter((g) => !isPostseason(g)), postseason: games.filter((g) => isPostseason(g)) };
}

// "13–3", or "9–7–1" when there are ties. Null when there is no record object.
export function regularRecordText(regular) {
  if (!regular) return null;
  return regular.ties > 0 ? `${regular.wins}–${regular.losses}–${regular.ties}` : `${regular.wins}–${regular.losses}`;
}

// { record: '1–1', rounds: 'Wild Card round, Divisional round' }, or null when no postseason games.
export function postseasonSummary(postseason, labels = {}) {
  if (!postseason || postseason.games === 0) return null;
  return { record: `${postseason.wins}–${postseason.losses}`, rounds: postseason.rounds.map((r) => labels[r] ?? r).join(', ') };
}

// The record fields to show, or null unless results are available. This is the single gate
// that keeps unavailable, outside-coverage and not-completed seasons from showing numbers.
export function recordView(results, labels = {}) {
  if (!results || results.state !== 'available' || !results.record) return null;
  const r = results.record;
  const short = r.status === 'complete_with_note';
  return {
    regular: regularRecordText(r.regular_season),
    wins: r.regular_season.wins, losses: r.regular_season.losses, ties: r.regular_season.ties,
    postseason: postseasonSummary(r.postseason, labels),
    label: results.label, formula: results.formula,
    countNote: short ? `${r.regular_season.games} of ${r.expected_regular_season_games} expected regular-season games are in this data.` : null,
    noteRef: short ? r.note_ref : null,
  };
}

// The season note a record points at (note_ref → seasons[].schedule_note), or null.
export function resolveSeasonNote(noteRef, seasons) {
  if (!noteRef || !Array.isArray(seasons)) return null;
  const s = seasons.find((x) => x.season_id === noteRef.season_id);
  const text = s ? s[noteRef.field] : null;
  return typeof text === 'string' && text.trim() ? text : null;
}

// identity_id → identity, from a list (as returned by listSeasonGames). A new Map.
export function identityMap(identities) {
  return new Map((identities ?? []).filter(Boolean).map((i) => [i.identity_id, i]));
}
