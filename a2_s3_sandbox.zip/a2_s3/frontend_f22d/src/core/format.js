// Formatting helpers. Pure functions, shared by both versions.
export function yearSpan(first, last, openLabel = 'present') {
  if (first == null) return 'Unknown';
  if (last == null) return `${first}–${openLabel}`;
  return first === last ? `${first}` : `${first}–${last}`;
}

export function identityName(identity) {
  if (!identity) return '';
  if (identity.display_name) return identity.display_name;
  return [identity.location_name, identity.nickname].filter(Boolean).join(' ');
}

export function count(n, singular, plural = `${singular}s`) {
  return `${n.toLocaleString('en-US')} ${n === 1 ? singular : plural}`;
}

// Identities in effect in a year, using curated ranges. openEnd is the latest season.
export function identitiesForYear(identities, year, openEnd) {
  return identities.filter((i) => i.first_season <= year && year <= (i.last_season ?? openEnd));
}

export function decadeOf(year) {
  return Math.floor(year / 10) * 10;
}

export function normalize(s) {
  return String(s ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}
