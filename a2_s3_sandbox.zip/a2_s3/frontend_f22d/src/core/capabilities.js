// Capability flags gate features. A page checks the flag; it never guesses.
export const CAPABILITY_KEYS = Object.freeze([
  'franchises', 'seasons', 'games', 'headToHead', 'players', 'playerStats', 'statCoverage', 'compare', 'search',
]);

// Plain-language reasons shown when a capability is off.
export const UNAVAILABLE_REASONS = Object.freeze({
  mock: {
    games: 'Demonstration game results arrive with the game pages in milestone F2.',
    headToHead: 'Demonstration series records arrive with Explore and Compare in milestone F4.',
    playerStats: 'Demonstration statistics arrive with player profiles in milestone F5.',
    statCoverage: 'Statistic coverage arrives with player profiles in milestone F5.',
    compare: 'Comparisons arrive in milestone F4.',
  },
  snapshot: {
    games: 'Game results are not in this development snapshot. They are planned for milestone F2, pending approval of the game source.',
    headToHead: 'Series records need game results, which are not in this development snapshot yet.',
    players: 'Player data is not part of this development snapshot. Adding it requires a separate approval (D-F4).',
    playerStats: 'Player statistics are not part of this development snapshot (D-F4).',
    statCoverage: 'Statistic coverage tables are not part of this development snapshot.',
    compare: 'Comparisons need game results and arrive in milestone F4.',
  },
});

export function reasonFor(providerId, key) {
  return UNAVAILABLE_REASONS[providerId]?.[key] ?? 'This feature is not available yet.';
}
