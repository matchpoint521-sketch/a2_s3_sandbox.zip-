// Every provider method resolves to an envelope. validateEnvelope is used by tests.
import { CLASS_KEYS } from './data-class.js';

export const STATUSES = ['ok', 'empty', 'not_found', 'unavailable'];

function meta(provider, m = {}) {
  return {
    provider,
    classes: m.classes ?? [],
    verification: m.verification ?? null,
    coverage: m.coverage ?? null,
    sources: m.sources ?? [],
    reason: m.reason ?? null,
  };
}

export const envelope = {
  ok: (provider, data, m) => ({ status: 'ok', data, meta: meta(provider, m) }),
  empty: (provider, data, m) => ({ status: 'empty', data, meta: meta(provider, m) }),
  notFound: (provider, reason) => ({ status: 'not_found', data: null, meta: meta(provider, { reason }) }),
  unavailable: (provider, reason, m = {}) =>
    ({ status: 'unavailable', data: null, meta: meta(provider, { ...m, classes: ['unavailable'], reason }) }),
};

export function validateEnvelope(env) {
  const problems = [];
  if (!env || typeof env !== 'object') return ['envelope is not an object'];
  if (!STATUSES.includes(env.status)) problems.push(`bad status ${env.status}`);
  const m = env.meta;
  if (!m) return [...problems, 'missing meta'];
  if (!['mock', 'snapshot'].includes(m.provider)) problems.push(`bad provider ${m.provider}`);
  if (!Array.isArray(m.classes)) problems.push('classes not an array');
  else for (const c of m.classes) if (!CLASS_KEYS.includes(c)) problems.push(`unknown class ${c}`);
  if (['unavailable', 'not_found'].includes(env.status) && !m.reason) problems.push(`${env.status} without reason`);
  if (env.status === 'ok' && env.data == null) problems.push('ok without data');
  if (env.status === 'unavailable' && env.data !== null) problems.push('unavailable with data');
  return problems;
}
