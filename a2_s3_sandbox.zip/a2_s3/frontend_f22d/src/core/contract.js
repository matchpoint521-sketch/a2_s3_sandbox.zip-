// The provider contract shared by Version A (mock) and Version B (snapshot).
export const PROVIDER_METHODS = Object.freeze([
  'getManifest',
  'listFranchises', 'getFranchise', 'getTeamSeason',
  'listSeasons', 'getSeason',
  'getGame', 'getHeadToHead',
  'listPlayers', 'getPlayer',
  'getStatCoverage',
  'search',
  'listSeasonGames', 'getFranchiseRecords',
]);

export function assertProvider(p) {
  if (!p || (p.id !== 'mock' && p.id !== 'snapshot')) throw new Error('provider id must be mock or snapshot');
  const missing = PROVIDER_METHODS.filter((m) => typeof p[m] !== 'function');
  if (missing.length) throw new Error(`provider ${p.id} is missing: ${missing.join(', ')}`);
  return p;
}
