// Pure validation and lookup functions for the F2.2 game files (season shards, the game
// index and team-season records). No I/O, no imports, no shared state: every function
// reads its arguments, never changes them, and returns new values. Validators return a
// list of problems (empty means valid); the provider decides what to do with them (S3).
// The rules encode the schema verified in F2.2d-A1 S1 (build 5913437c…); nothing is added.

export const GAME_TYPES = Object.freeze(['REG', 'WC', 'DIV', 'CON', 'SB']);
export const POSTSEASON_TYPES = Object.freeze(['WC', 'DIV', 'CON', 'SB']);
export const GAME_ID_PATTERN = /^g_[0-9a-f]{12}$/;
export const NOT_OFFICIAL_TEXT = 'Not official league standings';
export const RECORD_STATUSES = Object.freeze(['complete', 'complete_with_note']);

const PENDING = 'pending_review';
const SHARD_KEYS = ['class', 'league_code', 'records', 'review_status', 'schema', 'season', 'source', 'verification'];
const GAME_KEYS = ['away', 'class', 'game_date', 'game_id', 'game_type', 'home', 'league_code', 'neutral_site', 'overtime', 'review_status', 'season', 'source_ref', 'verification', 'week'];
const SIDE_KEYS = ['franchise_id', 'identity_id', 'score'];
const SOURCE_REF_KEYS = ['key', 'source'];
const INDEX_KEYS = ['class', 'description', 'records', 'review_status', 'schema'];
const INDEX_ROW_KEYS = ['game_id', 'season'];
const RECORDS_KEYS = ['class', 'formula', 'label', 'records', 'review_status', 'schema'];
const RECORD_KEYS = ['class', 'expected_regular_season_games', 'franchise_id', 'identity_id', 'league_code', 'note_ref', 'postseason', 'record_id', 'regular_season', 'review_status', 'season', 'status', 'verification', 'withheld_reason'];
const REGULAR_KEYS = ['games', 'losses', 'ties', 'wins'];
const POSTSEASON_KEYS = ['games', 'losses', 'rounds', 'wins'];
const NOTE_REF_KEYS = ['field', 'id', 'season_id'];
const SOURCE_KEY_PATTERN = /^(\d{4})_(\d{2})_[A-Z]{2,3}_[A-Z]{2,3}$/;
const DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
const TYPE_ORDER = Object.freeze({ REG: 0, WC: 1, DIV: 2, CON: 3, SB: 4 });

// ------------------------------------------------------------------ small helpers

function isPlainObject(x) {
  return x !== null && typeof x === 'object' && !Array.isArray(x);
}

function hasExactKeys(obj, keys) {
  if (!isPlainObject(obj)) return false;
  const own = Object.keys(obj).sort();
  return own.length === keys.length && own.every((k, i) => k === keys[i]);
}

function isCount(n) {
  return Number.isInteger(n) && n >= 0;
}

function isNonEmptyString(s) {
  return typeof s === 'string' && s.trim().length > 0;
}

function daysInMonth(year, month) {
  if (month === 2) return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28;
  return [4, 6, 9, 11].includes(month) ? 30 : 31;
}

// A real calendar date string, compared as text only (no Date objects, no time zones).
export function isCalendarDate(s) {
  const m = typeof s === 'string' ? DATE_PATTERN.exec(s) : null;
  if (!m) return false;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  return mo >= 1 && mo <= 12 && d >= 1 && d <= daysInMonth(y, mo);
}

export function isGameId(id) {
  return typeof id === 'string' && GAME_ID_PATTERN.test(id);
}

function identityCovers(identity, season) {
  return identity.first_season <= season && (identity.last_season === null || season <= identity.last_season);
}

function compareText(a, b) {
  if (a < b) return -1;
  return a > b ? 1 : 0;
}

// Permitted week for a game type, derived from the season's regular_season_games (G):
// regular season 1..G+1 (one bye week), then Wild Card G+2, Divisional G+3, Conference G+4,
// Super Bowl G+5. Verified for every season 1999–2025 in build 5913437c… (F2.2d-A1 S3, I-4);
// not asserted for seasons outside game coverage. Returns [min, max] or null.
export function weekRange(gameType, regularSeasonGames) {
  if (!Number.isInteger(regularSeasonGames) || regularSeasonGames < 1) return null;
  const last = regularSeasonGames + 1;
  if (gameType === 'REG') return [1, last];
  const k = POSTSEASON_TYPES.indexOf(gameType);
  return k < 0 ? null : [last + k + 1, last + k + 1];
}

// ------------------------------------------------------------------ context

// Builds the lookups the validators need from the manifest and the curated files.
// Returns new Maps; the inputs are only read.
export function makeGameContext({ manifest, franchises, identities, seasons }) {
  const games = manifest && manifest.coverage ? manifest.coverage.games : null;
  return Object.freeze({
    schema: manifest ? manifest.schema : null,
    sourceId: manifest && manifest.games_source ? manifest.games_source.id : null,
    coverage: games ? Object.freeze({ league: games.league, from: games.from, to: games.to }) : null,
    franchiseIds: new Set((franchises ?? []).map((f) => f.franchise_id)),
    identityById: new Map((identities ?? []).map((i) => [i.identity_id, i])),
    seasonById: new Map((seasons ?? []).map((s) => [s.season_id, s])),
  });
}

// Where a requested league season sits relative to game coverage (D-A1-7):
// 'covered', 'outside' (before coverage, other leagues, merged seasons), 'not_completed'
// (a known season after coverage) or 'unknown' (no such season in the curated data).
export function coverageState(league, year, ctx) {
  if (!ctx.seasonById.has(`${league}-${year}`)) return 'unknown';
  const c = ctx.coverage;
  if (!c || league !== c.league || year < c.from) return 'outside';
  if (year > c.to) return 'not_completed';
  return 'covered';
}

// ------------------------------------------------------------------ team side of a game

function sideProblems(where, side, season, ctx) {
  const out = [];
  if (!hasExactKeys(side, SIDE_KEYS)) return [`${where}: keys must be ${SIDE_KEYS.join(', ')}`];
  if (!isCount(side.score)) out.push(`${where}: score ${JSON.stringify(side.score)} is not a whole number >= 0`);
  if (!ctx.franchiseIds.has(side.franchise_id)) out.push(`${where}: unknown franchise ${side.franchise_id}`);
  const identity = ctx.identityById.get(side.identity_id);
  if (!identity) out.push(`${where}: unknown identity ${side.identity_id}`);
  else {
    if (identity.franchise_id !== side.franchise_id) out.push(`${where}: identity ${side.identity_id} belongs to ${identity.franchise_id}, not ${side.franchise_id}`);
    if (!identityCovers(identity, season)) out.push(`${where}: identity ${side.identity_id} does not cover ${season}`);
  }
  return out;
}

// ------------------------------------------------------------------ season shard

// Validates games/<year>.json. `year` is the season the caller asked for (from the path).
export function validateShard(body, year, ctx) {
  const file = `games/${year}.json`;
  const out = [];
  if (!hasExactKeys(body, SHARD_KEYS)) return [`${file}: envelope keys must be ${SHARD_KEYS.join(', ')}`];
  if (body.class !== 'source') out.push(`${file}: class ${body.class}, expected source`);
  if (body.review_status !== PENDING) out.push(`${file}: review_status ${body.review_status}, expected ${PENDING}`);
  if (body.verification !== 'single_source_pinned') out.push(`${file}: verification ${body.verification}, expected single_source_pinned`);
  if (body.schema !== ctx.schema) out.push(`${file}: schema ${body.schema}, expected ${ctx.schema}`);
  if (body.source !== ctx.sourceId) out.push(`${file}: source ${body.source}, expected ${ctx.sourceId}`);
  if (!ctx.coverage || body.league_code !== ctx.coverage.league) out.push(`${file}: league ${body.league_code} is not the covered league`);
  if (body.season !== year) out.push(`${file}: envelope season ${body.season}, expected ${year}`);
  if (!ctx.coverage || !Number.isInteger(year) || year < ctx.coverage.from || year > ctx.coverage.to) out.push(`${file}: ${year} is outside game coverage`);
  if (!Array.isArray(body.records)) return [...out, `${file}: records is not a list`];

  const seasonRow = ctx.seasonById.get(`${body.league_code}-${year}`);
  const regularGames = seasonRow ? seasonRow.regular_season_games : null;
  if (!Number.isInteger(regularGames)) out.push(`${file}: no regular_season_games for ${body.league_code}-${year}, so game weeks cannot be checked`);
  const seen = new Set();
  let previous = null;
  body.records.forEach((g, i) => {
    const at = `${file}[${i}]`;
    if (!hasExactKeys(g, GAME_KEYS)) { out.push(`${at}: game keys must be ${GAME_KEYS.join(', ')}`); return; }
    if (!isGameId(g.game_id)) out.push(`${at}: bad game id ${JSON.stringify(g.game_id)}`);
    else if (seen.has(g.game_id)) out.push(`${at}: duplicate game id ${g.game_id}`);
    seen.add(g.game_id);
    if (g.season !== year) out.push(`${at}: season ${g.season}, expected ${year}`);
    if (g.league_code !== body.league_code) out.push(`${at}: league ${g.league_code}`);
    if (g.class !== 'source') out.push(`${at}: class ${g.class}, expected source`);
    if (g.review_status !== PENDING) out.push(`${at}: review_status ${g.review_status}, expected ${PENDING}`);
    if (g.verification !== body.verification) out.push(`${at}: verification ${g.verification}`);
    if (!GAME_TYPES.includes(g.game_type)) out.push(`${at}: unknown game type ${JSON.stringify(g.game_type)}`);
    if (!Number.isInteger(g.week) || g.week < 1) out.push(`${at}: week ${JSON.stringify(g.week)} is not a whole number >= 1`);
    else {
      const range = weekRange(g.game_type, regularGames);
      if (range && (g.week < range[0] || g.week > range[1])) out.push(`${at}: week ${g.week} is impossible for ${g.game_type} in a ${regularGames}-game season (allowed ${range[0] === range[1] ? range[0] : `${range[0]}–${range[1]}`})`);
    }
    if (!isCalendarDate(g.game_date)) out.push(`${at}: game_date ${JSON.stringify(g.game_date)} is not a YYYY-MM-DD calendar date`);
    else {
      const dy = Number(g.game_date.slice(0, 4));
      const dm = Number(g.game_date.slice(5, 7));
      if (!(dy === year || (dy === year + 1 && dm <= 2))) out.push(`${at}: game_date ${g.game_date} is outside the ${year} season`);
    }
    if (typeof g.neutral_site !== 'boolean') out.push(`${at}: neutral_site is not true/false`);
    if (typeof g.overtime !== 'boolean') out.push(`${at}: overtime is not true/false`);
    if (!hasExactKeys(g.source_ref, SOURCE_REF_KEYS)) out.push(`${at}: source_ref keys must be ${SOURCE_REF_KEYS.join(', ')}`);
    else {
      if (g.source_ref.source !== body.source) out.push(`${at}: source_ref.source ${g.source_ref.source}`);
      const k = typeof g.source_ref.key === 'string' ? SOURCE_KEY_PATTERN.exec(g.source_ref.key) : null;
      if (!k) out.push(`${at}: source key ${JSON.stringify(g.source_ref.key)} has an unexpected form`);
      else if (Number(k[1]) !== g.season || Number(k[2]) !== g.week) out.push(`${at}: source key ${g.source_ref.key} disagrees with season ${g.season} week ${g.week}`);
    }
    const sideIssues = [...sideProblems(`${at}.home`, g.home, year, ctx), ...sideProblems(`${at}.away`, g.away, year, ctx)];
    out.push(...sideIssues);
    if (!sideIssues.length) {
      if (g.home.franchise_id === g.away.franchise_id) out.push(`${at}: a franchise cannot play itself`);
      if (POSTSEASON_TYPES.includes(g.game_type) && g.home.score === g.away.score) out.push(`${at}: postseason game ${g.game_id} is tied, which the record format cannot represent`);
    }
    if (GAME_TYPES.includes(g.game_type) && typeof g.game_date === 'string' && g.source_ref && typeof g.source_ref.key === 'string') {
      const key = [g.game_date, TYPE_ORDER[g.game_type], g.source_ref.key];
      if (previous && (compareText(previous[0], key[0]) || previous[1] - key[1] || compareText(previous[2], key[2])) >= 0) out.push(`${at}: games are not in (date, round, source key) order`);
      previous = key;
    }
  });
  return out;
}

// ------------------------------------------------------------------ game index

export function validateIndex(body, ctx) {
  const file = 'games/index.json';
  const out = [];
  if (!hasExactKeys(body, INDEX_KEYS)) return [`${file}: envelope keys must be ${INDEX_KEYS.join(', ')}`];
  if (body.class !== 'source') out.push(`${file}: class ${body.class}, expected source`);
  if (body.review_status !== PENDING) out.push(`${file}: review_status ${body.review_status}, expected ${PENDING}`);
  if (body.schema !== ctx.schema) out.push(`${file}: schema ${body.schema}, expected ${ctx.schema}`);
  if (!isNonEmptyString(body.description)) out.push(`${file}: description missing`);
  if (!Array.isArray(body.records)) return [...out, `${file}: records is not a list`];
  const seen = new Set();
  let previous = null;
  body.records.forEach((r, i) => {
    const at = `${file}[${i}]`;
    if (!hasExactKeys(r, INDEX_ROW_KEYS)) { out.push(`${at}: row keys must be ${INDEX_ROW_KEYS.join(', ')}`); return; }
    if (!isGameId(r.game_id)) out.push(`${at}: bad game id ${JSON.stringify(r.game_id)}`);
    else {
      if (seen.has(r.game_id)) out.push(`${at}: ${r.game_id} listed twice`);
      if (previous !== null && compareText(previous, r.game_id) >= 0) out.push(`${at}: index is not sorted by game id`);
      previous = r.game_id;
      seen.add(r.game_id);
    }
    if (!ctx.coverage || !Number.isInteger(r.season) || r.season < ctx.coverage.from || r.season > ctx.coverage.to) out.push(`${at}: season ${r.season} is outside game coverage`);
  });
  return out;
}

// game id → season, as a new Map. Call only after validateIndex reported no problems.
export function indexLookup(body) {
  return new Map(body.records.map((r) => [r.game_id, r.season]));
}

// Index ↔ shard: the index lists exactly the shard's games for that season.
export function checkIndexForSeason(seasonOf, year, shardBody) {
  const file = `games/${year}.json`;
  const out = [];
  const ids = new Set();
  for (const g of shardBody.records) {
    ids.add(g.game_id);
    const s = seasonOf.get(g.game_id);
    if (s === undefined) out.push(`${file}: ${g.game_id} is missing from the index`);
    else if (s !== year) out.push(`${file}: index puts ${g.game_id} in ${s}, not ${year}`);
  }
  for (const [id, s] of seasonOf) if (s === year && !ids.has(id)) out.push(`games/index.json: ${id} is listed for ${year} but is not in ${file}`);
  return out;
}

// game id → game for one shard, as a new Map of the (unchanged) game objects.
export function shardLookup(shardBody) {
  return new Map(shardBody.records.map((g) => [g.game_id, g]));
}

// ------------------------------------------------------------------ team-season records

function noteProblems(at, r, ctx) {
  const n = r.note_ref;
  if (!hasExactKeys(n, NOTE_REF_KEYS)) return [`${at}: note_ref keys must be ${NOTE_REF_KEYS.join(', ')}`];
  const out = [];
  if (n.season_id !== `${r.league_code}-${r.season}`) out.push(`${at}: note_ref points at ${n.season_id}, not ${r.league_code}-${r.season}`);
  if (n.field !== 'schedule_note') out.push(`${at}: note_ref field ${n.field}, expected schedule_note`);
  if (!isNonEmptyString(n.id)) out.push(`${at}: note_ref id missing`);
  const season = ctx.seasonById.get(n.season_id);
  if (!season || !isNonEmptyString(season[n.field])) out.push(`${at}: note_ref does not resolve to a season note`);
  return out;
}

export function validateRecords(body, ctx) {
  const file = 'team_season_records.json';
  const out = [];
  if (!hasExactKeys(body, RECORDS_KEYS)) return [`${file}: envelope keys must be ${RECORDS_KEYS.join(', ')}`];
  if (body.class !== 'derived') out.push(`${file}: class ${body.class}, expected derived`);
  if (body.review_status !== PENDING) out.push(`${file}: review_status ${body.review_status}, expected ${PENDING}`);
  if (body.schema !== ctx.schema) out.push(`${file}: schema ${body.schema}, expected ${ctx.schema}`);
  if (typeof body.label !== 'string' || !body.label.includes(NOT_OFFICIAL_TEXT)) out.push(`${file}: label must say "${NOT_OFFICIAL_TEXT}"`);
  if (!isNonEmptyString(body.formula)) out.push(`${file}: formula missing`);
  if (!Array.isArray(body.records)) return [...out, `${file}: records is not a list`];
  const seen = new Set();
  let previous = null;
  body.records.forEach((r, i) => {
    const at = `${file}[${i}]`;
    if (!hasExactKeys(r, RECORD_KEYS)) { out.push(`${at}: record keys must be ${RECORD_KEYS.join(', ')}`); return; }
    if (r.class !== 'derived') out.push(`${at}: class ${r.class}, expected derived`);
    if (r.review_status !== PENDING) out.push(`${at}: review_status ${r.review_status}, expected ${PENDING}`);
    if (r.verification !== 'derived_from_source') out.push(`${at}: verification ${r.verification}, expected derived_from_source`);
    if (!ctx.coverage || r.league_code !== ctx.coverage.league) out.push(`${at}: league ${r.league_code} is not the covered league`);
    if (!ctx.coverage || !Number.isInteger(r.season) || r.season < ctx.coverage.from || r.season > ctx.coverage.to) out.push(`${at}: season ${r.season} is outside game coverage`);
    if (r.record_id !== `${r.season}-${r.franchise_id}`) out.push(`${at}: record_id ${r.record_id} does not match season and franchise`);
    else if (seen.has(r.record_id)) out.push(`${at}: duplicate record ${r.record_id}`);
    seen.add(r.record_id);
    const key = [r.season, String(r.franchise_id)];
    if (previous && (previous[0] - key[0] || compareText(previous[1], key[1])) >= 0) out.push(`${at}: records are not in (season, franchise) order`);
    previous = key;
    if (!ctx.franchiseIds.has(r.franchise_id)) out.push(`${at}: unknown franchise ${r.franchise_id}`);
    const identity = ctx.identityById.get(r.identity_id);
    if (!identity) out.push(`${at}: unknown identity ${r.identity_id}`);
    else if (identity.franchise_id !== r.franchise_id || !identityCovers(identity, r.season)) out.push(`${at}: identity ${r.identity_id} does not name ${r.franchise_id} in ${r.season}`);

    const rs = r.regular_season;
    const regularOk = hasExactKeys(rs, REGULAR_KEYS) && REGULAR_KEYS.every((k) => isCount(rs[k]));
    if (!regularOk) out.push(`${at}: regular_season must hold whole-number games, wins, losses, ties`);
    else if (rs.wins + rs.losses + rs.ties !== rs.games) out.push(`${at}: regular season wins + losses + ties is not games`);
    const ps = r.postseason;
    if (!hasExactKeys(ps, POSTSEASON_KEYS) || !isCount(ps.games) || !isCount(ps.wins) || !isCount(ps.losses) || !Array.isArray(ps.rounds)) {
      out.push(`${at}: postseason must hold whole-number games, wins, losses and a rounds list`);
    } else {
      if (ps.wins + ps.losses !== ps.games) out.push(`${at}: postseason wins + losses is not games`);
      if (ps.rounds.length !== ps.games) out.push(`${at}: postseason lists ${ps.rounds.length} rounds for ${ps.games} games`);
      ps.rounds.forEach((round, j) => {
        if (!POSTSEASON_TYPES.includes(round)) out.push(`${at}: unknown round ${JSON.stringify(round)}`);
        else if (j > 0 && POSTSEASON_TYPES.includes(ps.rounds[j - 1]) && TYPE_ORDER[ps.rounds[j - 1]] >= TYPE_ORDER[round]) out.push(`${at}: rounds are not in WC, DIV, CON, SB order`);
      });
    }

    const season = ctx.seasonById.get(`${r.league_code}-${r.season}`);
    if (!season || r.expected_regular_season_games !== season.regular_season_games) out.push(`${at}: expected_regular_season_games ${r.expected_regular_season_games} differs from the season's ${season ? season.regular_season_games : 'missing'}`);
    if (!RECORD_STATUSES.includes(r.status)) out.push(`${at}: status ${JSON.stringify(r.status)} is not in the verified schema`);
    else if (regularOk) {
      if (r.withheld_reason !== null) out.push(`${at}: withheld_reason must be null for status ${r.status}`);
      const short = rs.games !== r.expected_regular_season_games;
      if (r.status === 'complete') {
        if (short) out.push(`${at}: complete record has ${rs.games} regular-season games, expected ${r.expected_regular_season_games}`);
        if (r.note_ref !== null) out.push(`${at}: complete record carries a note_ref`);
      } else {
        if (!short) out.push(`${at}: complete_with_note record has the expected number of games`);
        out.push(...noteProblems(at, r, ctx));
      }
    }
  });
  return out;
}

// season → [records] and franchise → [records], as new Maps of new arrays (records unchanged).
export function recordLookups(body) {
  const bySeason = new Map();
  const byFranchise = new Map();
  for (const r of body.records) {
    if (!bySeason.has(r.season)) bySeason.set(r.season, []);
    bySeason.get(r.season).push(r);
    if (!byFranchise.has(r.franchise_id)) byFranchise.set(r.franchise_id, []);
    byFranchise.get(r.franchise_id).push(r);
  }
  return { bySeason, byFranchise };
}

// ------------------------------------------------------------------ recompute (D-F22d-9)

// Results per franchise for one season's games, using the approved formula: a win when the
// team scored more points, a loss when fewer, a tie when equal; regular season and postseason
// counted separately; rounds listed in game order. Returns a new Map of new objects.
export function recomputeSeason(games) {
  const out = new Map();
  for (const g of games) {
    for (const [me, op] of [[g.home, g.away], [g.away, g.home]]) {
      if (!out.has(me.franchise_id)) {
        out.set(me.franchise_id, { identity_ids: [], regular_season: { games: 0, wins: 0, losses: 0, ties: 0 }, postseason: { games: 0, wins: 0, losses: 0, rounds: [] } });
      }
      const t = out.get(me.franchise_id);
      if (!t.identity_ids.includes(me.identity_id)) t.identity_ids.push(me.identity_id);
      const part = g.game_type === 'REG' ? t.regular_season : t.postseason;
      part.games += 1;
      if (me.score > op.score) part.wins += 1;
      else if (me.score < op.score) part.losses += 1;
      else if (part === t.regular_season) part.ties += 1;
      if (part === t.postseason) part.rounds.push(g.game_type);
    }
  }
  return out;
}

// Compares one season's records with the results recomputed from that season's games.
export function checkSeasonRecords(year, shardBody, records) {
  const file = 'team_season_records.json';
  const out = [];
  const calc = recomputeSeason(shardBody.records);
  const mine = records.filter((r) => r.season === year);
  const seen = new Set();
  for (const r of mine) {
    seen.add(r.franchise_id);
    const c = calc.get(r.franchise_id);
    if (!c) { out.push(`${file}: ${r.record_id} has no games in games/${year}.json`); continue; }
    if (c.identity_ids.length !== 1 || c.identity_ids[0] !== r.identity_id) out.push(`${file}: ${r.record_id} identity ${r.identity_id}, games use ${c.identity_ids.join(', ')}`);
    for (const k of REGULAR_KEYS) if (r.regular_season[k] !== c.regular_season[k]) out.push(`${file}: ${r.record_id} regular season ${k} ${r.regular_season[k]}, games give ${c.regular_season[k]}`);
    for (const k of ['games', 'wins', 'losses']) if (r.postseason[k] !== c.postseason[k]) out.push(`${file}: ${r.record_id} postseason ${k} ${r.postseason[k]}, games give ${c.postseason[k]}`);
    if (r.postseason.rounds.join(',') !== c.postseason.rounds.join(',')) out.push(`${file}: ${r.record_id} rounds ${r.postseason.rounds.join(',')}, games give ${c.postseason.rounds.join(',')}`);
  }
  for (const fid of calc.keys()) if (!seen.has(fid)) out.push(`${file}: ${fid} played in ${year} but has no record`);
  return out;
}

// ------------------------------------------------------------------ browsing helpers

export function validateFilters(filters) {
  const out = [];
  if (!isPlainObject(filters)) return ['filters must be an object'];
  for (const k of Object.keys(filters)) if (k !== 'week' && k !== 'type') out.push(`unknown filter ${k}`);
  if (filters.week !== undefined && (!Number.isInteger(filters.week) || filters.week < 1)) out.push(`week ${JSON.stringify(filters.week)} is not a whole number >= 1`);
  if (filters.type !== undefined && !GAME_TYPES.includes(filters.type)) out.push(`unknown game type ${JSON.stringify(filters.type)}`);
  return out;
}

// A new array of the games matching the filters, in their stored order.
export function filterGames(games, filters = {}) {
  return games.filter((g) => (filters.week === undefined || g.week === filters.week)
    && (filters.type === undefined || g.game_type === filters.type));
}
