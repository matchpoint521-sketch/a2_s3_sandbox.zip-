// Hash router. parseHash and href are pure so they can be tested in Node.
import { ROUTES, PARAM_RULES } from './routes.js';

const compiled = ROUTES.map((r) => ({ ...r, parts: r.pattern === '' ? [] : r.pattern.split('/') }));

export function parseHash(hash) {
  let raw = String(hash ?? '').replace(/^#/, '');
  if (!raw.startsWith('/')) raw = `/${raw}`;
  const [pathPart, queryPart = ''] = raw.slice(1).split('?');
  let segments;
  try {
    segments = pathPart.split('/').filter(Boolean).map(decodeURIComponent);
  } catch {
    return notFound(raw);
  }
  const query = Object.fromEntries(new URLSearchParams(queryPart));
  for (const r of compiled) {
    if (r.parts.length !== segments.length) continue;
    const params = {};
    let ok = true;
    r.parts.forEach((part, i) => {
      if (!ok) return;
      if (part.startsWith(':')) {
        const name = part.slice(1);
        const rule = PARAM_RULES[name];
        if (rule && !rule.test(segments[i])) ok = false;
        else params[name] = name === 'year' ? Number(segments[i]) : segments[i];
      } else if (part !== segments[i]) ok = false;
    });
    if (ok) return { id: r.id, section: r.section, params, query, path: raw };
  }
  return notFound(raw);
}

function notFound(path) {
  return { id: 'not-found', section: null, params: {}, query: {}, path };
}

export function href(id, params = {}, query = {}) {
  const r = compiled.find((x) => x.id === id);
  if (!r) throw new Error(`unknown route ${id}`);
  const path = r.parts.map((p) => (p.startsWith(':') ? encodeURIComponent(String(params[p.slice(1)])) : p)).join('/');
  const qs = new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '')).toString();
  return `#/${path}${qs ? `?${qs}` : ''}`;
}

export function startRouter(onRoute) {
  const handle = () => onRoute(parseHash(window.location.hash));
  window.addEventListener('hashchange', handle);
  handle();
  return () => window.removeEventListener('hashchange', handle);
}
