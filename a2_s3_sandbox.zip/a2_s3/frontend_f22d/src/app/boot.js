// Starts the app with whichever provider the entry point supplies. Pages only ever
// see ctx.provider; they never import a provider themselves.
import { assertProvider } from '../core/contract.js';
import { startRouter } from './router.js';
import { createShell } from './shell.js';
import { PAGES } from '../pages/index.js';

export function boot(root, provider, { mode }) {
  assertProvider(provider);
  document.documentElement.dataset.mode = mode;
  const shell = createShell(root, mode);
  let token = 0;

  async function show(route) {
    const mine = ++token;
    shell.setActive(route.section, route.id);
    shell.setSearch(route.id === 'search' ? route.query.q : '');
    shell.showLoading();
    const page = PAGES[route.id] ?? PAGES['not-found'];
    try {
      const { title, node } = await page.render({ provider, route, mode });
      if (mine === token) shell.show(node, title);
    } catch (err) {
      if (mine !== token) return;
      console.error(err);
      shell.showError(err, () => show(route));
    }
  }

  startRouter(show);
}
