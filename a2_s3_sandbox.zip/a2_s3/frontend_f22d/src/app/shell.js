// The persistent frame: skip link, header, mode bar, main region, footer.
import { h } from '../components/dom.js';
import { primaryNav } from '../components/nav.js';
import { modeBar } from '../components/mode-badge.js';
import { loadingState, errorState, snapshotMissingState } from '../components/states.js';
import { pageHeader } from '../components/page-header.js';
import { SnapshotUnavailable } from '../core/errors.js';
import { href } from './router.js';

const MODE_SUFFIX = { foundation: 'demonstration', validation: 'data validation' };

// Decorative scene layers. CSS shows the ones that belong to the current section
// (body[data-scene]); none carries content, so the whole backdrop is hidden from assistive tech.
function backdrop() {
  const layer = (name, ...kids) => h('div', { class: `bd bd--${name}` }, ...kids);
  const marks = (cls) => [1, 2, 3, 4, 5].map(() => h('span', { class: cls })).concat(h('span', { class: `${cls} is-back` }));
  return h('div', { class: 'backdrop', 'aria-hidden': 'true' },
    layer('sky'), layer('stands'), layer('floor'), layer('split'),
    layer('formation', marks('o'), marks('x')),
    layer('tunnel'), layer('spot'), layer('overhead'),
    h('div', { class: 'bd bd--tower bd--tower-l' }), h('div', { class: 'bd bd--tower bd--tower-r' }),
    layer('veil'), layer('fade'));
}

// Index pages get the full scene; detail pages get a quieter version of it.
const INDEX_ROUTES = new Set(['explore', 'compare', 'compare-teams', 'compare-seasons', 'compare-players', 'teams', 'players', 'seasons']);

export function createShell(root, mode) {
  const nav = primaryNav();
  const search = h('input', { type: 'search', name: 'q', id: 'site-search', placeholder: 'Search teams or a year', autocomplete: 'off' });
  const form = h('form', {
    class: 'header-search', role: 'search',
    onsubmit: (e) => { e.preventDefault(); window.location.hash = href('search', {}, { q: search.value.trim() }); },
  }, h('label', { for: 'site-search', class: 'visually-hidden' }, 'Search teams, names and seasons'), search);

  const main = h('main', { id: 'main', class: 'site-main', tabindex: '-1' });
  root.replaceChildren(
    backdrop(),
    h('a', { class: 'skip-link', href: '#main', onclick: (e) => { e.preventDefault(); main.focus(); } }, 'Skip to content'),
    h('header', { class: 'site-header' },
      h('div', { class: 'site-header__inner' },
        h('a', { class: 'brand', href: '#/' }, h('span', { class: 'brand__mark' }, 'Velora'), h('span', { class: 'brand__sub' }, 'Pro football archive (working title)')),
        nav.element, form),
      modeBar(mode)),
    main,
    h('footer', { class: 'site-footer' }, h('div', { class: 'site-footer__inner' },
      h('p', {}, 'Velora is an independent project. It is not affiliated with or endorsed by the National Football League. Team names identify historical facts only; no logos or marks are used.'),
      h('p', {}, mode === 'foundation' ? 'Foundation version: fictional demonstration data.' : 'Data-validation version: local development snapshot, not for publication.', ' ', h('a', { href: '#/data' }, 'About the data')))),
  );

  let first = true;
  let loadingTimer = null;

  function place(node, title) {
    clearTimeout(loadingTimer);
    main.replaceChildren(node);
    main.removeAttribute('aria-busy');
    document.title = `${title} | Velora (${MODE_SUFFIX[mode]})`;
    if (!first) (main.querySelector('[data-page-title]') ?? main).focus();
    first = false;
  }

  return {
    setActive(section, routeId) {
      nav.setActive(section);
      document.body.dataset.scene = section ?? 'plain';
      document.body.dataset.depth = INDEX_ROUTES.has(routeId) ? 'index' : 'detail';
    },
    setSearch: (q) => { search.value = q ?? ''; },
    showLoading() {
      main.setAttribute('aria-busy', 'true');
      clearTimeout(loadingTimer);
      loadingTimer = setTimeout(() => main.replaceChildren(loadingState()), 120);
    },
    show: place,
    showError(err, retry) {
      if (err instanceof SnapshotUnavailable) {
        place(h('div', {}, pageHeader({ title: 'Snapshot not built' }), snapshotMissingState()), 'Snapshot not built');
      } else {
        place(h('div', {}, pageHeader({ title: 'Something went wrong' }), errorState(err, retry)), 'Error');
      }
    },
  };
}
