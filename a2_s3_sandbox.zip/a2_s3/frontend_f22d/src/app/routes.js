// Route table. Patterns are matched against the hash path (without "#/").
export const ROUTES = Object.freeze([
  { id: 'explore', pattern: '', section: 'explore' },
  { id: 'compare', pattern: 'compare', section: 'compare' },
  { id: 'compare-teams', pattern: 'compare/teams', section: 'compare' },
  { id: 'compare-seasons', pattern: 'compare/seasons', section: 'compare' },
  { id: 'compare-players', pattern: 'compare/players', section: 'compare' },
  { id: 'teams', pattern: 'teams', section: 'teams' },
  { id: 'team', pattern: 'teams/:franchise', section: 'teams' },
  { id: 'team-season', pattern: 'teams/:franchise/:year', section: 'teams' },
  { id: 'players', pattern: 'players', section: 'players' },
  { id: 'player', pattern: 'players/:player', section: 'players' },
  { id: 'seasons', pattern: 'seasons', section: 'seasons' },
  { id: 'season', pattern: 'seasons/:league/:year', section: 'seasons' },
  { id: 'game', pattern: 'games/:game', section: 'seasons' },
  { id: 'search', pattern: 'search', section: null },
  { id: 'data', pattern: 'data', section: null },
]);

export const SECTIONS = Object.freeze([
  { id: 'explore', label: 'Explore', href: '#/' },
  { id: 'compare', label: 'Compare', href: '#/compare' },
  { id: 'teams', label: 'Teams', href: '#/teams' },
  { id: 'players', label: 'Players', href: '#/players' },
  { id: 'seasons', label: 'Seasons', href: '#/seasons' },
]);

// Parameter validators: a route only matches when every parameter is well formed.
export const PARAM_RULES = Object.freeze({
  franchise: /^[a-z][a-z0-9_]{1,40}$/,
  player: /^[a-z][a-z0-9_]{1,40}$/,
  game: /^[A-Za-z0-9_-]{1,40}$/,
  league: /^[A-Z]{2,8}$/,
  year: /^\d{4}$/,
});
