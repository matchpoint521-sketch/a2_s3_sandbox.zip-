// Loading, empty, error, unavailable and not-built states. Each says what happened and what to do.
import { h } from './dom.js';

function state(kind, title, body, extra = []) {
  const mark = kind === 'unavailable' || kind === 'empty' ? h('span', { class: 'state__mark', 'aria-hidden': 'true' }) : null;
  return h('section', { class: `state state--${kind}`, role: kind === 'error' ? 'alert' : 'status' },
    mark,
    h('h2', { class: 'state__title' }, title),
    ...(Array.isArray(body) ? body : [body]).filter(Boolean).map((b) => (b instanceof Node ? b : h('p', {}, b))),
    ...extra);
}

export const loadingState = (what = 'this page') => state('loading', `Loading ${what}`, null);

export const emptyState = (title, body, actions = []) =>
  state('empty', title, body, actions.length ? [h('p', {}, ...actions)] : []);

export const unavailableState = (title, reason) => state('unavailable', title, reason);

export const notFoundState = (reason, actions = []) =>
  state('empty', 'Nothing here', reason, actions.length ? [h('p', {}, ...actions)] : []);

export function errorState(err, onRetry) {
  return state('error', 'This page could not load its data',
    [err?.message ?? String(err), 'Check that the local server is running from the frontend folder, then try again.'],
    onRetry ? [h('p', {}, h('button', { type: 'button', class: 'action', onclick: onRetry }, 'Try again'))] : []);
}

export function snapshotMissingState() {
  return state('unavailable', 'The data snapshot has not been built', [
    'This is the data-validation version. It only shows records from the approved development snapshot, and it never substitutes demonstration data.',
    'Build the snapshot from the frontend folder, then reload this page:',
    h('pre', {}, h('code', {}, 'python3 tools/build_snapshot.py --source "<folder with the seed CSVs>"')),
    h('p', {}, 'For the interface with demonstration data, open ', h('a', { href: 'foundation.html' }, 'the foundation version'), '.'),
  ]);
}
