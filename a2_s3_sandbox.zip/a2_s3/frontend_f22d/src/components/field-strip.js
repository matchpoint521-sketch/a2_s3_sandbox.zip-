// The field: seasons laid out end zone to end zone, with the gold line to gain
// marking the current selection. Bars are buttons; the same information is always
// available in a table on the page, so the strip itself is an enhancement.
import { h } from './dom.js';

export function fieldStrip({ from, to, lanes = [], selected = null, lineLabel, caption, label, onSelect }) {
  const span = to - from + 1;
  const pos = (year) => ((year - from) / span) * 100;
  const surface = h('div', { class: 'field__surface' });

  const firstYard = Math.ceil(from / 10) * 10;
  for (let y = firstYard; y <= to; y += 10) {
    surface.append(h('div', { class: 'field__yard', 'data-minor': String(y % 20 !== 0), style: { left: `${pos(y)}%` }, 'aria-hidden': 'true' }, h('span', {}, `${y}`)));
  }
  for (let y = from; y <= to; y += 1) {
    if (y % 10 !== 0) surface.append(h('div', { class: 'field__hash', style: { left: `${pos(y)}%` }, 'aria-hidden': 'true' }));
  }

  const buttons = [];
  for (const lane of lanes) {
    const laneEl = h('div', { class: 'field__lane', role: 'group', 'aria-label': lane.label },
      h('span', { class: 'field__lane-label', 'aria-hidden': 'true' }, lane.label));
    for (const seg of lane.segments) {
      const last = seg.to ?? to;
      const short = seg.kind === 'merged' && (last - seg.from + 1) / span < 0.06;
      const btn = h('button', {
        type: 'button', class: 'field__segment', 'data-kind': seg.kind, 'data-class': seg.cls,
        'aria-pressed': String(seg.id === selected),
        'aria-label': `${seg.label}, ${seg.from === last ? seg.from : `${seg.from} to ${seg.to ?? 'present'}`}`,
        title: `${seg.label} (${seg.from === last ? seg.from : `${seg.from}–${seg.to ?? 'present'}`})`,
        style: { left: `${pos(seg.from)}%`, width: `${((last - seg.from + 1) / span) * 100}%` },
        onclick: () => select(seg),
      }, short ? '' : seg.label);
      btn._seg = seg;
      buttons.push(btn);
      laneEl.append(btn);
      // Short segments (a single merged season, say) get their name beside the bar instead of inside it.
      if (short) laneEl.append(h('span', { class: 'field__tag', 'aria-hidden': 'true', style: { left: `calc(${pos(last + 1)}% + 6px)` } }, seg.label));
    }
    surface.append(laneEl);
  }

  const lineText = h('span', { class: 'field__line-label' });
  const line = h('div', { class: 'field__line', 'aria-hidden': 'true' }, lineText);
  surface.append(line);
  const live = h('p', { class: 'visually-hidden', 'aria-live': 'polite' });

  function placeLine(year, text) {
    line.style.left = `${pos(year) + 50 / span}%`;
    line.classList.toggle('is-right', pos(year) > 70);
    lineText.textContent = text;
  }

  function select(seg) {
    for (const b of buttons) b.setAttribute('aria-pressed', String(b._seg === seg));
    placeLine(seg.from, `${seg.from}`);
    live.textContent = `Selected ${seg.label}, from ${seg.from}.`;
    if (onSelect) onSelect(seg);
  }

  const figure = h('figure', { class: 'field', 'aria-label': label ?? 'Season field' }, surface, live,
    caption ? h('figcaption', { class: 'field__caption' }, caption) : null);

  // Start at the left goal line, then sweep to the starting selection (the one orchestrated motion).
  const start = buttons.find((b) => b._seg.id === selected)?._seg;
  const target = start ? start.from : to;
  placeLine(from, lineLabel ?? `${target}`);
  requestAnimationFrame(() => requestAnimationFrame(() => placeLine(target, lineLabel ?? `${target}`)));

  return { element: figure, select: (id) => { const b = buttons.find((x) => x._seg.id === id); if (b) select(b._seg); } };
}
