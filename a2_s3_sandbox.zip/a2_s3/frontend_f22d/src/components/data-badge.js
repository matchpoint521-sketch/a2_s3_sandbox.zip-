import { h } from './dom.js';
import { DATA_CLASSES } from '../core/data-class.js';

const VERIFICATION = {
  data_corroborated: 'Corroborated by game data',
  needs_review: 'Needs review',
  reference_only: 'Reference only',
};

export function classBadge(cls) {
  const c = DATA_CLASSES[cls];
  return h('span', { class: `badge badge--${cls}`, title: c?.description ?? '' }, c?.label ?? cls);
}

export function verificationBadge(value) {
  if (!value) return null;
  const review = value === 'needs_review';
  return h('span', { class: `badge${review ? ' badge--review' : ''}`, title: 'Verification level recorded in the curated seed' },
    VERIFICATION[value] ?? value.replaceAll('_', ' '));
}

// The badges every record shows: its class, plus verification for curated rows.
export function recordBadges(record) {
  return [classBadge(record.class), record.class === 'curated' ? verificationBadge(record.verification) : null];
}
