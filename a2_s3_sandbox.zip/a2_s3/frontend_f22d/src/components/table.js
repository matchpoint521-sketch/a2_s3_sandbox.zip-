import { h } from './dom.js';

// columns: [{label, cell(row) -> node|string, numeric?, header?}]
export function dataTable({ caption, columns, rows, rowAttrs }) {
  return h('div', { class: 'table-wrap', role: 'region', 'aria-label': caption, tabindex: '0' },
    h('table', {},
      caption ? h('caption', {}, caption) : null,
      h('thead', {}, h('tr', {}, columns.map((c) => h('th', { scope: 'col', class: c.numeric ? 'is-numeric' : null }, c.label)))),
      h('tbody', {}, rows.map((r) => h('tr', rowAttrs ? rowAttrs(r) : {},
        columns.map((c, i) => h(i === 0 ? 'th' : 'td', { scope: i === 0 ? 'row' : null, class: c.numeric ? 'is-numeric' : null }, c.cell(r))))))));
}
