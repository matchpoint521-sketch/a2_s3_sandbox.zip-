import { h } from './dom.js';

const MODES = {
  foundation: {
    title: 'Demonstration data',
    body: 'Every team, player and season in this version is fictional. Nothing here is NFL history.',
  },
  validation: {
    title: 'Data validation',
    body: 'Development snapshot of curated records. Every record is pending review and nothing is historically certified.',
  },
};

export function modeBar(mode) {
  const m = MODES[mode];
  return h('div', { class: 'mode-bar', 'data-mode': mode, role: 'note', 'aria-label': 'Data mode' },
    h('div', { class: 'mode-bar__inner' },
      h('strong', {}, m.title),
      h('span', {}, m.body),
      h('a', { href: '#/data' }, 'About the data')));
}
