import { h } from './dom.js';

// crumbs: [{label, href}] (last one is the current page and is not a link)
// scene: true sets the section's title large over its backdrop (index pages only).
export function pageHeader({ crumbs = [], title, lede, badges = [], actions = [], scene = false }) {
  return h('header', { class: scene ? 'page-header page-header--scene' : 'page-header' },
    crumbs.length ? h('nav', { class: 'breadcrumbs', 'aria-label': 'Breadcrumb' },
      h('ol', {}, crumbs.map((c, i) => h('li', {}, i < crumbs.length - 1 && c.href ? h('a', { href: c.href }, c.label) : h('span', { 'aria-current': 'page' }, c.label))))) : null,
    h('h1', { tabindex: '-1', 'data-page-title': '' }, title),
    lede ? h('p', { class: 'page-header__lede' }, lede) : null,
    badges.filter(Boolean).length ? h('div', { class: 'page-header__badges' }, badges.filter(Boolean)) : null,
    actions.length ? h('div', { class: 'page-header__actions' }, actions) : null);
}
