import { h } from './dom.js';
import { SECTIONS } from '../app/routes.js';

export function primaryNav() {
  const links = SECTIONS.map((s) => h('a', { href: s.href, 'data-section': s.id }, s.label));
  const el = h('nav', { class: 'primary-nav', 'aria-label': 'Primary' }, h('ul', {}, links.map((a) => h('li', {}, a))));
  return {
    element: el,
    setActive(section) {
      for (const a of links) {
        if (a.dataset.section === section) a.setAttribute('aria-current', 'page');
        else a.removeAttribute('aria-current');
      }
    },
  };
}
