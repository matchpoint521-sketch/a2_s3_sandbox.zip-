// Version A provider: fictional demonstration data only. Reads data/mock/ and nothing else.
import { createRecordProvider } from '../../src/core/record-provider.js';

export function createMockProvider(loader) {
  return createRecordProvider({
    id: 'mock',
    base: 'data/mock/',
    loader,
    expectedClass: 'demo',
    sources: ['velora_demonstration'],
    onManifestMissing: null, // a missing demo file is a packaging error, shown as an error state
  });
}
