// Version B provider: the approved development snapshot only. Reads data/snapshot/ and nothing else.
// If the snapshot has not been built, every call fails with SnapshotUnavailable. There is no fallback.
import { createRecordProvider } from '../../src/core/record-provider.js';
import { SnapshotUnavailable } from '../../src/core/errors.js';

export function createSnapshotProvider(loader) {
  return createRecordProvider({
    id: 'snapshot',
    base: 'data/snapshot/',
    loader,
    expectedClass: 'curated',
    sources: ['velora_curated_seed'],
    onManifestMissing() {
      throw new SnapshotUnavailable('Run tools/build_snapshot.py to create data/snapshot/.');
    },
  });
}
