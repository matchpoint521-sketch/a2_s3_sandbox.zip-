"""F2.1 historical game builder (imported by build_snapshot.py). Standard library only.

Reads one hash-pinned nflverse games CSV, keeps the approved 11 fields, gives every
source row exactly one disposition, maps teams through the reviewed season-scoped
code map and the curated seed identities, and produces season-sharded game records,
a game index, derived team-season records and audit reports.

It makes no network or database connections and never writes anything itself:
build_snapshot.py owns output. Every refusal raises Refused(code, message):
  2  input refused (hash, header, historical-slice digest, config files)
  3  integrity failure (unapproved quarantine, mapping or reconciliation failure)
"""
import csv
import datetime
import hashlib
import io
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

SOURCE_ID = "nflverse_games"
GAME_TYPES = ("REG", "WC", "DIV", "CON", "SB")
POST_TYPES = GAME_TYPES[1:]
TYPE_ORDER = {t: i for i, t in enumerate(GAME_TYPES)}
PENDING = "pending_review"

# Disposition codes (data contract §4).
INCLUDED = "INCLUDED"
X1 = "X1_SEASON_NOT_COMPLETED"
X2 = "X2_OUT_OF_SCOPE"
Q1 = "Q1_MISSING_SCORE"
Q2 = "Q2_INVALID_VALUE"
Q3 = "Q3_UNMAPPED_CODE"
Q4 = "Q4_AMBIGUOUS"
Q5 = "Q5_DUPLICATE"
Q6 = "Q6_IMPOSSIBLE"
QUARANTINE = (Q1, Q2, Q3, Q4, Q5, Q6)

SCORE_RE = re.compile(r"\d{1,2}")
INT_RE = re.compile(r"\d{1,4}")


class Refused(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def sha256(data):
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------- configuration

def load_config(config_path):
    """Read the F2 config and the two pinned files it names (resolved next to it)."""
    path = Path(config_path)
    try:
        raw = path.read_bytes()
        cfg = json.loads(raw.decode("utf-8"))
    except (OSError, ValueError) as exc:
        raise Refused(2, f"F2 config unreadable: {path}: {exc}")
    base = path.parent
    pinned = {}
    for key in ("team_code_map", "exceptions"):
        entry = cfg[key]
        f = base / entry["file"]
        if not f.is_file():
            raise Refused(2, f"F2 {key} file missing: {f}")
        data = f.read_bytes()
        got = sha256(data)
        if got != entry["sha256"]:
            raise Refused(2, f"hash mismatch: {entry['file']}\n  expected {entry['sha256']}\n  actual   {got}")
        pinned[key] = data
    try:
        exceptions = json.loads(pinned["exceptions"].decode("utf-8"))["approved_quarantines"]
    except (ValueError, KeyError) as exc:
        raise Refused(2, f"exceptions file is malformed: {exc}")
    return {
        "cfg": cfg,
        "config_sha256": sha256(raw),
        "map_rows": list(csv.DictReader(io.StringIO(pinned["team_code_map"].decode("utf-8"), newline=""))),
        "exceptions": exceptions,
    }


def structure_for(cfg, season):
    for s in cfg["season_structure"]:
        if s["from"] <= season <= s["to"]:
            return s
    raise Refused(3, f"no season_structure entry covers {season}")


# ---------------------------------------------------------------- source file

def read_source(games_path, cfg):
    """Verify raw hash, header and historical-slice digest; return (rows, input_report)."""
    path = Path(games_path)
    if not path.is_file():
        raise Refused(2, f"missing game source: {path}")
    raw = path.read_bytes()
    pin = cfg["file"]
    got = sha256(raw)
    if got != pin["sha256"]:
        raise Refused(2, f"hash mismatch: {path.name}\n  expected {pin['sha256']}\n  actual   {got}")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise Refused(2, f"{path.name} is not UTF-8: {exc}")
    reader = csv.reader(io.StringIO(text, newline=""))
    header = next(reader, None)
    if header != pin["header"]:
        raise Refused(2, f"header differs from the pinned 46-column header: {_header_diff(pin['header'], header)}")
    rows = []
    for n, values in enumerate(reader, start=2):
        if len(values) != len(header):
            raise Refused(2, f"line {n}: {len(values)} fields, expected {len(header)}")
        rows.append(dict(zip(header, values)))
    if len(rows) != pin["rows"]:
        raise Refused(2, f"{path.name}: {len(rows)} rows, expected {pin['rows']}")
    digest, count = slice_digest(rows, cfg)
    sl = cfg["slice"]
    if digest != sl["digest"] or count != sl["rows"]:
        raise Refused(2, f"historical-slice digest differs (historical rows changed upstream?)\n"
                         f"  expected {sl['digest']} ({sl['rows']} rows)\n  actual   {digest} ({count} rows)")
    return rows, {"sha256": got, "rows": len(rows), "slice_digest": digest, "slice_rows": count}


def _header_diff(want, got):
    if got is None:
        return "file is empty"
    missing = [c for c in want if c not in got]
    extra = [c for c in got if c not in want]
    if missing or extra:
        return f"missing {missing}, unexpected {extra}"
    return "same columns, different order"


def in_slice(season_text, cfg):
    sl = cfg["slice"]
    return INT_RE.fullmatch(season_text or "") is not None and sl["first_season"] <= int(season_text) <= sl["last_completed_season"]


def slice_digest(rows, cfg):
    """SHA-256 over the allowlisted fields of the in-slice rows, sorted, tab-joined, LF."""
    fields = cfg["slice"]["digest_fields"]
    lines = sorted("\t".join(r[c] for c in fields) for r in rows if in_slice(r["season"], cfg))
    # Sorting whole lines equals sorting by game_id (the first field) whenever game_ids are unique.
    return sha256("".join(line + "\n" for line in lines).encode("utf-8")), len(lines)


def row_digest(row, cfg):
    return sha256("\t".join(row[c] for c in cfg["slice"]["digest_fields"]).encode("utf-8"))


# ---------------------------------------------------------------- mapping

def load_map(map_rows, franchises):
    """Validate the code map itself (M-2, unknown franchise). Returns rows grouped by code."""
    by_code = defaultdict(list)
    for i, r in enumerate(map_rows):
        where = f"team code map row {i + 2}"
        if r.get("source") != SOURCE_ID:
            raise Refused(3, f"{where}: source must be {SOURCE_ID!r}")
        if not (INT_RE.fullmatch(r["first_season"]) and INT_RE.fullmatch(r["last_season"])):
            raise Refused(3, f"{where}: season range is not numeric")
        first, last = int(r["first_season"]), int(r["last_season"])
        if first > last:
            raise Refused(3, f"{where}: first_season after last_season")
        if r["franchise_id"] not in franchises:
            raise Refused(3, f"{where}: unknown franchise {r['franchise_id']!r}")
        if not r["expected_location"].strip():
            raise Refused(3, f"{where}: expected_location is empty")
        by_code[r["source_code"]].append({**r, "first": first, "last": last, "row": i + 2})
    for code, rows in by_code.items():
        rows.sort(key=lambda x: x["first"])
        for a, b in zip(rows, rows[1:]):
            if b["first"] <= a["last"]:
                raise Refused(3, f"team code map: overlapping rows for {code!r} (rows {a['row']} and {b['row']})")
    return by_code


def resolve_identity(identities, franchise_id, season):
    """Exactly one identity of the franchise whose range contains the season, else None plus a count."""
    hits = [i for i in identities if i["franchise_id"] == franchise_id
            and i["first_season"] <= season <= (i["last_season"] if i["last_season"] is not None else 10**6)]
    return (hits[0] if len(hits) == 1 else None), len(hits)


class Mapper:
    def __init__(self, map_rows, seed):
        self.franchises = {f["franchise_id"]: f for f in seed["franchises"]}
        self.identities = seed["identities"]
        self.merged_years = {m["season"] for m in seed["merged_seasons"]}
        self.by_code = load_map(map_rows, self.franchises)
        self.cache = {}
        self.used_rows = set()

    def resolve(self, code, season):
        """-> ('ok', resolution) | (Q3|Q4, detail). Map-level defects raise Refused(3)."""
        key = (code, season)
        if key in self.cache:
            return self.cache[key]
        hits = [m for m in self.by_code.get(code, []) if m["first"] <= season <= m["last"]]
        if not hits:
            out = (Q3, f"no map row for code {code!r} in {season}")
        else:
            m = hits[0]  # overlaps were refused in load_map, so at most one
            self.used_rows.add(m["row"])
            fid = m["franchise_id"]
            f = self.franchises[fid]
            last = f["last_season"] if f["last_season"] is not None else 10**6
            if not f["first_nfl_season"] <= season <= last:
                raise Refused(3, f"M-6: {code} {season} maps to {fid}, outside the franchise span")
            if season in self.merged_years:
                raise Refused(3, f"M-8: {code} {season} falls in a merged team-season year")
            ident, n = resolve_identity(self.identities, fid, season)
            if ident is None:
                out = (Q4, f"{fid} has {n} identities covering {season}")
            else:
                if ident["location_name"] != m["expected_location"]:
                    raise Refused(3, f"M-5: {code} {season} resolves to {ident['identity_id']} "
                                     f"({ident['location_name']!r}); map expects {m['expected_location']!r}")
                out = ("ok", {"code": code, "season": season, "franchise_id": fid,
                              "identity_id": ident["identity_id"], "map_row": m["row"],
                              "identity_verification": ident["verification"]})
        self.cache[key] = out
        return out


# ---------------------------------------------------------------- row validation

def validate_row(r, cfg):
    """Value checks for an in-slice row. Returns (code, detail) or None when valid."""
    if r["home_score"] == "" or r["away_score"] == "":
        return Q1, "a score is blank"
    problems = []
    season = int(r["season"])
    if r["game_type"] not in GAME_TYPES:
        return Q2, "game_type is not one of REG, WC, DIV, CON, SB"
    if not INT_RE.fullmatch(r["week"]):
        return Q2, "week is not an integer"
    week = int(r["week"])
    st = structure_for(cfg, season)
    if r["game_type"] == "REG" and not 1 <= week <= st["reg_max_week"]:
        problems.append(f"regular-season week {week} outside 1-{st['reg_max_week']}")
    if r["game_type"] != "REG" and not 18 <= week <= 22:
        problems.append(f"postseason week {week} outside 18-22")
    for side in ("home_score", "away_score"):
        if not SCORE_RE.fullmatch(r[side]):
            problems.append(f"{side.split('_')[0]} score is not an integer 0-99")
    if problems:
        return Q2, "; ".join(problems)
    hs, aw = int(r["home_score"]), int(r["away_score"])
    if r["home_team"] == r["away_team"] or not r["home_team"] or not r["away_team"]:
        problems.append("home and away teams are blank or identical")
    expected_id = f"{season}_{week:02d}_{r['away_team']}_{r['home_team']}"
    if r["game_id"] != expected_id:
        problems.append(f"game key does not follow season_week_away_home ({expected_id})")
    if r["result"] == "" or not re.fullmatch(r"-?\d{1,3}", r["result"]) or int(r["result"]) != hs - aw:
        problems.append("score-difference check failed")
    if r["total"] == "" or not INT_RE.fullmatch(r["total"]) or int(r["total"]) != hs + aw:
        problems.append("points-sum check failed")
    try:
        d = datetime.date.fromisoformat(r["gameday"])
        if not datetime.date(season, 8, 1) <= d < datetime.date(season + 1, 3, 1):
            problems.append(f"date {r['gameday']} outside Aug 1 {season} to end of Feb {season + 1}")
    except ValueError:
        problems.append("date is not ISO YYYY-MM-DD")
    if r["location"] not in ("Home", "Neutral"):
        problems.append("site designation is not Home or Neutral")
    if r["overtime"] not in ("0", "1"):
        problems.append("overtime flag is not 0 or 1")
    if problems:
        return Q2, "; ".join(problems)
    if r["game_type"] != "REG" and hs == aw:
        return Q6, "postseason game recorded as a tie"
    return None


# ---------------------------------------------------------------- dispositions

def dispose(rows, cfg, mapper):
    """Give every source row exactly one disposition. Returns a list in source order."""
    sl = cfg["slice"]
    out = []
    keys = Counter(r["game_id"] for r in rows if in_slice(r["season"], cfg))
    matchups = Counter((r["gameday"], r["home_team"], r["away_team"]) for r in rows if in_slice(r["season"], cfg))
    sb_per_season = Counter(r["season"] for r in rows if in_slice(r["season"], cfg) and r["game_type"] == "SB")
    for r in rows:
        d = {"source_key": r["game_id"], "season": r["season"], "game_type": r["game_type"],
             "row_digest": row_digest(r, cfg), "home": None, "away": None}
        if not INT_RE.fullmatch(r["season"] or ""):
            d.update(disposition=Q2, detail="season is not an integer")
        elif int(r["season"]) > sl["last_completed_season"]:
            d.update(disposition=X1, detail=f"season {r['season']} is after the last completed season {sl['last_completed_season']}")
        elif int(r["season"]) < sl["first_season"]:
            d.update(disposition=X2, detail=f"season {r['season']} is before {sl['first_season']}")
        elif keys[r["game_id"]] > 1 or matchups[(r["gameday"], r["home_team"], r["away_team"])] > 1:
            d.update(disposition=Q5, detail="source key or same teams and date appear more than once")
        else:
            bad = validate_row(r, cfg)
            if bad is None and r["game_type"] == "SB" and sb_per_season[r["season"]] > 1:
                bad = (Q6, "more than one Super Bowl row in the season")
            if bad is None:
                season = int(r["season"])
                for side in ("home", "away"):
                    status, res = mapper.resolve(r[f"{side}_team"], season)
                    if status != "ok":
                        bad = (status, f"{side}: {res}")
                        break
                    d[side] = res
            if bad is None:
                d.update(disposition=INCLUDED, detail=None)
            else:
                d.update(disposition=bad[0], detail=bad[1])
                # Resolve sides where possible so an approved quarantine can withhold the right records.
                if INT_RE.fullmatch(r["season"]):
                    for side in ("home", "away"):
                        if d[side] is None:
                            try:
                                status, res = mapper.resolve(r[f"{side}_team"], int(r["season"]))
                            except Refused:
                                status = None
                            if status == "ok":
                                d[side] = res
        out.append(d)
    return out


def apply_exceptions(dispositions, exceptions):
    """Unapproved in-slice quarantines refuse the build; stale exceptions refuse too."""
    approved = {(e["source_key"], e["disposition"]) for e in exceptions}
    seen = set()
    unapproved = []
    for d in dispositions:
        if d["disposition"] in QUARANTINE:
            k = (d["source_key"], d["disposition"])
            if k in approved:
                d["approved_quarantine"] = True
                seen.add(k)
            else:
                d["approved_quarantine"] = False
                unapproved.append(d)
    stale = sorted(approved - seen)
    if stale:
        raise Refused(3, f"approved exceptions that match no quarantined row: {stale}")
    if unapproved:
        lines = [f"  {d['source_key']}: {d['disposition']} ({d['detail']})" for d in unapproved[:50]]
        more = f"\n  … and {len(unapproved) - 50} more" if len(unapproved) > 50 else ""
        raise Refused(3, f"{len(unapproved)} quarantined row(s) are not approved in f2_exceptions.json:\n"
                         + "\n".join(lines) + more)


# ---------------------------------------------------------------- outputs

def game_id_for(source_key, length=12):
    return "g_" + sha256(f"{SOURCE_ID}:{source_key}".encode("utf-8"))[:length]


def make_games(rows, dispositions, id_length=12):
    by_key = {r["game_id"]: r for r in rows}
    games, ids = [], {}
    for d in dispositions:
        if d["disposition"] != INCLUDED:
            continue
        r = by_key[d["source_key"]]
        gid = game_id_for(d["source_key"], id_length)
        if gid in ids:
            raise Refused(3, f"game id collision: {gid} for {ids[gid]} and {d['source_key']}")
        ids[gid] = d["source_key"]
        d["game_id"] = gid
        games.append({
            "game_id": gid, "season": int(r["season"]), "league_code": "NFL",
            "game_type": r["game_type"], "week": int(r["week"]), "game_date": r["gameday"],
            "home": {"franchise_id": d["home"]["franchise_id"], "identity_id": d["home"]["identity_id"], "score": int(r["home_score"])},
            "away": {"franchise_id": d["away"]["franchise_id"], "identity_id": d["away"]["identity_id"], "score": int(r["away_score"])},
            "neutral_site": r["location"] == "Neutral", "overtime": r["overtime"] == "1",
            "source_ref": {"source": SOURCE_ID, "key": d["source_key"]},
            "class": "source", "verification": "single_source_pinned", "review_status": PENDING,
        })
    games.sort(key=lambda g: (g["season"], g["game_date"], TYPE_ORDER[g["game_type"]], g["source_ref"]["key"]))
    return games


def make_records(games, dispositions, cfg, seed):
    """Derived team-season records with reconciliation (data contract §6)."""
    seasons = {s["season_id"]: s for s in seed["seasons"]}
    notes = {}
    for n in cfg["record_notes"]:
        target = seasons.get(n["note_ref"]["season_id"])
        if target is None or not target.get(n["note_ref"]["field"]):
            raise Refused(3, f"record note {n['id']}: curated note {n['note_ref']} is missing in the seed")
        for fid in n["franchise_ids"]:
            notes[(n["season"], fid)] = n
    withheld = defaultdict(list)
    quarantined_seasons = set()
    for d in dispositions:
        if d.get("approved_quarantine"):
            quarantined_seasons.add(int(d["season"]))
            for side in ("home", "away"):
                if d[side]:
                    withheld[(int(d["season"]), d[side]["franchise_id"])].append(d["source_key"])
    teams = {}
    for g in games:
        for side in ("home", "away"):
            key = (g["season"], g[side]["franchise_id"])
            teams.setdefault(key, {"identity_id": g[side]["identity_id"], "reg": [0, 0, 0], "post": [0, 0], "rounds": set()})
    for key in withheld:  # a team-season may have all its games quarantined
        if key not in teams:
            raise Refused(3, f"withheld team-season {key} has no included games; not supported in F2.1")
    for g in games:
        h, a = g["home"], g["away"]
        for me, op in ((h, a), (a, h)):
            t = teams[(g["season"], me["franchise_id"])]
            if g["game_type"] == "REG":
                t["reg"][0 if me["score"] > op["score"] else 1 if me["score"] < op["score"] else 2] += 1
            else:
                t["post"][0 if me["score"] > op["score"] else 1] += 1
                t["rounds"].add(g["game_type"])
    records = []
    for (season, fid), t in sorted(teams.items()):
        st = structure_for(cfg, season)
        seed_games = seasons[f"NFL-{season}"]["regular_season_games"]
        if seed_games != st["reg_games_per_team"]:
            raise Refused(3, f"R-3: {season} schedule length {st['reg_games_per_team']} differs from the seed's {seed_games}")
        w, l, ti = t["reg"]
        rec = {
            "record_id": f"{season}-{fid}", "season": season, "league_code": "NFL",
            "franchise_id": fid, "identity_id": t["identity_id"], "expected_regular_season_games": seed_games,
            "regular_season": {"wins": w, "losses": l, "ties": ti, "games": w + l + ti},
            "postseason": {"wins": t["post"][0], "losses": t["post"][1], "games": sum(t["post"]),
                           "rounds": sorted(t["rounds"], key=TYPE_ORDER.get)},
            "status": "complete", "note_ref": None, "withheld_reason": None,
            "class": "derived", "verification": "derived_from_source", "review_status": PENDING,
        }
        if (season, fid) in withheld:
            rec.update(status="withheld", regular_season=None, postseason=None,
                       withheld_reason="An approved quarantined source row touches this team-season: "
                                       + ", ".join(sorted(withheld[(season, fid)])))
        elif w + l + ti != seed_games:
            n = notes.get((season, fid))
            if n is None or n["regular_season_games"] != w + l + ti:
                raise Refused(3, f"R-2: {season} {fid} has {w + l + ti} regular-season games, expected {seed_games}, no approved note")
            rec.update(status="complete_with_note", note_ref={"id": n["id"], **n["note_ref"]})
        records.append(rec)
    unused = [k for k in notes if k not in {(r["season"], r["franchise_id"]) for r in records if r["status"] == "complete_with_note"}]
    if unused:
        raise Refused(3, f"record notes that match no short team-season: {sorted(unused)}")
    reconcile(games, records, cfg, quarantined_seasons)
    return records


def reconcile(games, records, cfg, quarantined_seasons):
    """R-1 balance, structure per season. Seasons with an approved quarantine skip structure checks."""
    by_season = defaultdict(list)
    for g in games:
        by_season[g["season"]].append(g)
    sl = cfg["slice"]
    for season in range(sl["first_season"], sl["last_completed_season"] + 1):
        gs = by_season.get(season, [])
        reg = [g for g in gs if g["game_type"] == "REG"]
        w = sum(1 for g in reg if g["home"]["score"] != g["away"]["score"])
        ties = len(reg) - w
        recs = [r for r in records if r["season"] == season and r["regular_season"]]
        if sum(r["regular_season"]["wins"] for r in recs) != sum(r["regular_season"]["losses"] for r in recs) \
                and season not in quarantined_seasons:
            raise Refused(3, f"R-1: {season} wins and losses do not balance")
        if sum(r["regular_season"]["ties"] for r in recs) != 2 * ties and season not in quarantined_seasons:
            raise Refused(3, f"R-1: {season} tie count does not match its games")
        if season in quarantined_seasons:
            continue
        st = structure_for(cfg, season)
        types = Counter(g["game_type"] for g in gs)
        want = {"SB": 1, "CON": 2, "DIV": 4, "WC": st["wc_games"]}
        for t, n in want.items():
            if types[t] != n:
                raise Refused(3, f"R-4: {season} has {types[t]} {t} games, expected {n}")
        teams = {g[s]["franchise_id"] for g in gs for s in ("home", "away")}
        if len(teams) != st["teams"]:
            raise Refused(3, f"R-4: {season} has {len(teams)} teams, expected {st['teams']}")
        playoff = {g[s]["franchise_id"] for g in gs if g["game_type"] != "REG" for s in ("home", "away")}
        if len(playoff) != st["playoff_teams"]:
            raise Refused(3, f"R-4: {season} has {len(playoff)} playoff teams, expected {st['playoff_teams']}")
        two = Counter((g["season"], g[s]["franchise_id"]) for g in gs for s in ("home", "away") if g["game_type"] == "SB")
        if any(v != 1 for v in two.values()) or len(two) != 2:
            raise Refused(3, f"R-4: {season} Super Bowl participants are not two distinct teams")


def mapping_report(mapper, dispositions):
    counts = Counter()
    for d in dispositions:
        if d["disposition"] == INCLUDED:
            for side in ("home", "away"):
                counts[(d[side]["code"], d[side]["season"])] += 1
    rows = []
    for (code, season), (status, res) in sorted(mapper.cache.items()):
        row = {"source_code": code, "season": season, "outcome": "RESOLVED" if status == "ok" else status,
               "included_game_sides": counts.get((code, season), 0)}
        if status == "ok":
            row.update({k: res[k] for k in ("franchise_id", "identity_id", "map_row", "identity_verification")})
        else:
            row["detail"] = res
        rows.append(row)
    unused = sorted(r["row"] for rs in mapper.by_code.values() for r in rs if r["row"] not in mapper.used_rows)
    per_fs = defaultdict(set)
    for r in rows:
        if r["outcome"] == "RESOLVED":
            per_fs[(r["franchise_id"], r["season"])].add(r["source_code"])
    dupes = {f"{k[0]} {k[1]}": sorted(v) for k, v in per_fs.items() if len(v) > 1}
    if dupes:
        raise Refused(3, f"M-3: franchises with two source codes in one season: {dupes}")
    return rows, unused


def build(games_path, config_path, seed):
    """Run the whole F2 pipeline. Returns a dict with outputs, reports and manifest additions.

    Raises Refused. When the refusal happens after dispositions exist, the exception
    carries .report (a dispositions report) so the caller can write it for review.
    """
    conf = load_config(config_path)
    cfg = conf["cfg"]
    rows, input_report = read_source(games_path, cfg)
    mapper = Mapper(conf["map_rows"], seed)
    dispositions = dispose(rows, cfg, mapper)
    report = dispositions_report(dispositions, cfg)
    try:
        apply_exceptions(dispositions, conf["exceptions"])
        mapping_rows, unused = mapping_report(mapper, dispositions)
        games = make_games(rows, dispositions)
        records = make_records(games, dispositions, cfg, seed)
    except Refused as exc:
        exc.report = report
        raise
    report = dispositions_report(dispositions, cfg)  # now with game ids and approval flags
    return {"cfg": cfg, "conf": conf, "input_report": input_report, "games": games, "records": records,
            "dispositions": report, "mapping": {"code_seasons": mapping_rows, "unused_map_rows": unused}}


def dispositions_report(dispositions, cfg):
    items = []
    for d in sorted(dispositions, key=lambda x: x["source_key"]):
        item = {"source_key": d["source_key"], "season": d["season"], "game_type": d["game_type"],
                "disposition": d["disposition"], "detail": d["detail"], "row_digest": d["row_digest"],
                "game_id": d.get("game_id")}
        if d["disposition"] in QUARANTINE:
            item["approved_quarantine"] = d.get("approved_quarantine", False)
        items.append(item)
    return {"counts": dict(sorted(Counter(d["disposition"] for d in dispositions).items())), "rows": items,
            "slice": {"first_season": cfg["slice"]["first_season"], "last_completed_season": cfg["slice"]["last_completed_season"]}}
