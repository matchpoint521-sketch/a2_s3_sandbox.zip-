#!/usr/bin/env python3
"""Build the Version B development snapshot from the curated seed CSVs (F1 scope),
optionally with the F2.1 historical game data (--games, staging builds only).

Reads six hash-pinned CSV files (five curated datasets) and writes JSON under
frontend/data/snapshot/. Standard library only. It makes no network or database
connections, and it opens its inputs read-only.

F2.1 (--games): also reads the hash-pinned nflverse games CSV through
tools/f2_games.py and writes season-sharded games, a game index, derived
team-season records and audit reports. F2.1 game builds must go to an explicit
--out staging folder; data/snapshot and data/mock are refused (exit 4) until the
F2.2 provider integration is approved. Without --games the output is exactly F1.5.

F2.2b (--games --install --audit-out <folder>): writes the approved F2.2 served layout
into frontend/data/snapshot: the five curated files, games/<season>.json shards,
games/index.json and team_season_records.json, byte-identical to the F2.1 staging
build of the same inputs, plus an F2.2 manifest (games capability on). The two audit
reports go only to --audit-out, which must lie outside the frontend folder. The F2.1
staging build id is pinned in tools/f22_snapshot.json; any other staging result
refuses (exit 3). The default and staging modes are unchanged.

Exit codes:
  0  snapshot written (or --check passed)
  2  input refused: a file is missing or its SHA-256 does not match the pin
  3  integrity failure in the inputs (nothing written)
  4  output location refused (nothing written)

Usage:
  python3 tools/build_snapshot.py --source "<folder containing the seed CSVs>"
  python3 tools/build_snapshot.py --source "<folder>" --check   # verify only, write nothing
  python3 tools/build_snapshot.py --source "<seeds>" --games "<games.csv>" --out "<staging folder>" [--report "<file>"]
  python3 tools/build_snapshot.py --source "<seeds>" --games "<games.csv>" --install --audit-out "<folder outside frontend>" [--check]
"""
import argparse
import csv
import hashlib
import io
import json
import os
import re
import shutil
import sys
from pathlib import Path

import f2_games as F2  # noqa: E402  (same folder; standard library only)

FRONTEND = Path(__file__).resolve().parent.parent
PINS_FILE = FRONTEND / "tools" / "snapshot_inputs.json"
DEFAULT_OUT = FRONTEND / "data" / "snapshot"
MOCK_DIR = FRONTEND / "data" / "mock"
F2_CONFIG = FRONTEND / "tools" / "f2_games_inputs.json"
F22_CONFIG = FRONTEND / "tools" / "f22_snapshot.json"
# The only files --audit-out may ever contain (it is replaced as a whole on each install).
AUDIT_FILES = ("audit_manifest.json", "games_dispositions.json", "mapping_report.json")
F22_KEYS = {"authorization", "build_kind", "game_types", "expected_staging_build_id", "audit_note"}
SCHEMA = "velora-nfl-frontend/1"
PENDING = "pending_review"
# Never allowed in any output key (betting fields, source team codes, external ids).
FORBIDDEN_KEY = re.compile(r"moneyline|spread|odds|total_line|code_538|pfr|espn|gsis|pff|ftn", re.I)

CAPABILITIES = {
    "franchises": True, "seasons": True, "games": False, "headToHead": False,
    "players": False, "playerStats": False, "statCoverage": False, "compare": False, "search": True,
}


class Refused(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def locate(source, name):
    for candidate in (source / name, source / "seed" / name):
        if candidate.is_file():
            return candidate
    return None


def read_inputs(source, pins):
    """Read every pinned file once, verify its hash, and parse from the same bytes."""
    tables, report = {}, {}
    for name, expected in sorted(pins["files"].items()):
        path = locate(source, name)
        if path is None:
            raise Refused(2, f"missing input: {name} (looked in {source} and {source / 'seed'})")
        with open(path, "rb") as fh:
            raw = fh.read()
        got = sha256(raw)
        if got != expected:
            raise Refused(2, f"hash mismatch: {name}\n  expected {expected}\n  actual   {got}")
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise Refused(3, f"{name} is not UTF-8: {exc}")
        rows = list(csv.DictReader(io.StringIO(text, newline="")))
        want = pins["expected_rows"][name]
        if len(rows) != want:
            raise Refused(3, f"{name}: {len(rows)} rows, expected {want}")
        tables[name] = rows
        report[name] = {"sha256": got, "rows": len(rows)}
    return tables, report


def opt_int(value, field, where):
    value = (value or "").strip()
    if value == "":
        return None
    if not re.fullmatch(r"\d{4}|\d{1,2}", value):
        raise Refused(3, f"{where}: {field} is not an integer: {value!r}")
    return int(value)


def opt_text(value):
    value = (value or "").strip()
    return value or None


def pending(row, where):
    status = (row.get("review_status") or "").strip()
    if status != PENDING:
        raise Refused(3, f"{where}: review_status is {status!r}; curated records must stay {PENDING!r}")
    return PENDING


def transform(t):
    leagues = []
    for r in t["league_seed.csv"]:
        where = f"league {r['league_code']}"
        flag = r["recognized_by_nfl"].strip().lower()
        if flag not in ("true", "false"):
            raise Refused(3, f"{where}: recognized_by_nfl is {flag!r}")
        leagues.append({
            "league_code": r["league_code"].strip(), "name": r["name"].strip(),
            "recognized_by_nfl": flag == "true", "notes": opt_text(r["notes"]),
            "evidence": opt_text(r["evidence_refs"]), "review_status": pending(r, where), "class": "curated",
        })
    league_codes = {l["league_code"] for l in leagues}

    seasons = []
    for r in t["season_seed.csv"]:
        where = f"season {r['league_code']} {r['season_year']}"
        year = opt_int(r["season_year"], "season_year", where)
        if r["league_code"] not in league_codes or year is None:
            raise Refused(3, f"{where}: unknown league or missing year")
        seasons.append({
            "season_id": f"{r['league_code']}-{year}", "league_code": r["league_code"], "year": year,
            "regular_season_games": opt_int(r["regular_season_games"], "regular_season_games", where),
            "schedule_note": opt_text(r["schedule_note"]), "evidence": opt_text(r["evidence_refs"]),
            "review_status": pending(r, where), "class": "curated",
        })

    franchises = []
    for r in t["franchise_seed.csv"]:
        where = f"franchise {r['franchise_id']}"
        if r["status"] not in ("active", "defunct"):
            raise Refused(3, f"{where}: status {r['status']!r}")
        last = opt_int(r["last_season"], "last_season", where)
        if (r["status"] == "active") != (last is None):
            raise Refused(3, f"{where}: active franchises must have no last_season, defunct ones must")
        franchises.append({
            "franchise_id": r["franchise_id"], "display_name": r["display_name"].strip(), "status": r["status"],
            "origin_league": r["origin_league"], "first_nfl_season": opt_int(r["first_nfl_season"], "first_nfl_season", where),
            "last_season": last, "origin_note": opt_text(r["origin_note"]), "verification": opt_text(r["verification"]),
            "evidence": opt_text(r["source_refs"]), "review_status": pending(r, where), "class": "curated",
        })
    franchise_ids = {f["franchise_id"] for f in franchises}

    identities = []
    for r in t["team_identity_seed.csv"]:
        where = f"identity {r['identity_id']}"
        if r["franchise_id"] not in franchise_ids:
            raise Refused(3, f"{where}: unknown franchise {r['franchise_id']}")
        first = opt_int(r["first_season"], "first_season", where)
        last = opt_int(r["last_season"], "last_season", where)
        if first is None or (last is not None and last < first):
            raise Refused(3, f"{where}: invalid season range")
        identities.append({
            "identity_id": r["identity_id"], "franchise_id": r["franchise_id"],
            "location_name": r["location_name"].strip(), "nickname": r["nickname"].strip(),
            "first_season": first, "last_season": last, "verification": opt_text(r["verification"]),
            "evidence": opt_text(r["evidence_and_refs"]), "review_status": pending(r, where), "class": "curated",
        })

    merged_identities = {}
    for r in t["merged_identity_seed.csv"]:
        where = f"merged identity {r['identity_key']}"
        merged_identities[r["merged_key"]] = {
            "identity_id": r["identity_key"], "season": opt_int(r["season"], "season", where),
            "display_name": r["display_name"].strip(), "location_name": opt_text(r["location_name"]),
            "nickname": opt_text(r["nickname"]), "aliases_note": opt_text(r["aliases_note"]),
            "verification": opt_text(r["verification"]), "evidence": opt_text(r["evidence_refs"]),
            "review_status": pending(r, where), "class": "curated",
        }
    merged = []
    for r in t["merged_team_season_seed.csv"]:
        where = f"merged season {r['merged_key']}"
        season = opt_int(r["season"], "season", where)
        members = [x for x in r["franchise_ids"].split("|") if x]
        if len(members) < 2 or any(m not in franchise_ids for m in members):
            raise Refused(3, f"{where}: needs two or more known franchises, got {members}")
        ident = merged_identities.pop(r["merged_key"], None)
        if ident is None or ident["season"] != season:
            raise Refused(3, f"{where}: no merged identity for the same season")
        merged.append({
            "merged_key": r["merged_key"], "season": season, "common_name": r["common_name"].strip(),
            "franchise_ids": sorted(members), "identity": ident, "verification": opt_text(r["verification"]),
            "evidence": opt_text(r["evidence_and_refs"]), "review_status": pending(r, where), "class": "curated",
        })
    if merged_identities:
        raise Refused(3, f"merged identities without a merged season: {sorted(merged_identities)}")

    check_integrity(franchises, identities, seasons)
    return {
        "leagues": sorted(leagues, key=lambda x: x["league_code"]),
        "seasons": sorted(seasons, key=lambda x: (x["year"], x["league_code"])),
        "franchises": sorted(franchises, key=lambda x: x["franchise_id"]),
        "identities": sorted(identities, key=lambda x: (x["franchise_id"], x["first_season"], x["identity_id"])),
        "merged_seasons": sorted(merged, key=lambda x: (x["season"], x["merged_key"])),
    }


def check_integrity(franchises, identities, seasons):
    def unique(items, key, label):
        seen = set()
        for it in items:
            if it[key] in seen:
                raise Refused(3, f"duplicate {label}: {it[key]}")
            seen.add(it[key])
    unique(franchises, "franchise_id", "franchise_id")
    unique(identities, "identity_id", "identity_id")
    unique(seasons, "season_id", "season")
    by_franchise = {}
    for i in identities:
        by_franchise.setdefault(i["franchise_id"], []).append(i)
    for f in franchises:
        rows = sorted(by_franchise.get(f["franchise_id"], []), key=lambda x: x["first_season"])
        if not rows:
            raise Refused(3, f"franchise {f['franchise_id']} has no identity")
        for a, b in zip(rows, rows[1:]):
            if a["last_season"] is None or a["last_season"] >= b["first_season"]:
                raise Refused(3, f"overlapping identities {a['identity_id']} and {b['identity_id']}")
        open_ended = [r for r in rows if r["last_season"] is None]
        if (f["status"] == "active") != (len(open_ended) == 1):
            raise Refused(3, f"franchise {f['franchise_id']}: open-ended identity does not match status")


def check_keys(obj, path="$"):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if FORBIDDEN_KEY.search(k):
                raise Refused(3, f"forbidden field in output: {path}.{k}")
            check_keys(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            check_keys(v, f"{path}[{i}]")


def dumps(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + "\n").encode("utf-8")


def render(data, input_report):
    files, outputs = {}, {}
    for name, records in data.items():
        body = dumps({"schema": SCHEMA, "class": "curated", "review_status": PENDING, "records": records})
        files[f"{name}.json"] = body
        outputs[f"{name}.json"] = {"sha256": sha256(body), "records": len(records)}
    build_id = sha256("".join(f"{k}:{v['sha256']}\n" for k, v in sorted(outputs.items())).encode())
    years = [s["year"] for s in data["seasons"]]
    manifest = {
        "schema": SCHEMA, "provider": "snapshot", "build_id": build_id,
        "builder": {"name": "tools/build_snapshot.py", "milestone": "F1"},
        "authorization": "D-F1 (approved 2026-10-19): curated seed CSVs, local Version B only",
        "license_status": "Development only. Not for deployment: licensing gates L-1 to L-8 remain open.",
        "certification": "All curated records are pending review. Nothing here is historically certified.",
        "inputs": input_report, "outputs": outputs,
        "counts": {
            "leagues": len(data["leagues"]), "seasons": len(data["seasons"]), "franchises": len(data["franchises"]),
            "franchises_active": sum(f["status"] == "active" for f in data["franchises"]),
            "franchises_defunct": sum(f["status"] == "defunct" for f in data["franchises"]),
            "identities": len(data["identities"]), "merged_seasons": len(data["merged_seasons"]),
        },
        "coverage": {"seasons": {"from": min(years), "to": max(years)}},
        "capabilities": CAPABILITIES,
        "classes": ["curated"],
    }
    files["manifest.json"] = dumps(manifest)
    for body in files.values():
        check_keys(json.loads(body))
    return files, manifest


def guard_output(out, games=False):
    resolved = out.resolve()
    if "research" in resolved.parts:
        raise Refused(4, f"refusing to write inside a research workspace: {resolved}")
    if resolved == FRONTEND or resolved in FRONTEND.parents:
        raise Refused(4, f"refusing to replace {resolved}")
    mock = MOCK_DIR.resolve()
    if resolved == mock or mock in resolved.parents or resolved in mock.parents:
        raise Refused(4, f"refusing to write real data into or over the Version A demonstration folder: {resolved}")
    if games:
        snap = DEFAULT_OUT.resolve()
        if resolved == snap or snap in resolved.parents or resolved in snap.parents:
            raise Refused(4, "F2.1 game builds are staging builds: pass --out outside data/snapshot "
                             "(Version B is not switched to game data until F2.2 is approved)")
    return resolved


def guard_report(path):
    resolved = path.resolve()
    for d in (DEFAULT_OUT.resolve(), MOCK_DIR.resolve()):
        if resolved == d or d in resolved.parents:
            raise Refused(4, f"refusing to write a report inside {d}")
    return resolved


def write_report(path, body):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
    except OSError as exc:
        raise Refused(4, f"could not write the report to {path}: {exc}")


# ---------------------------------------------------------------- F2.1 games

F2_SCHEMA = SCHEMA


def scan_non_emitted(files, header, emitted):
    """Value-level guard: no non-emitted source column name appears as a word in any F2 output."""
    names = [c for c in header if c not in emitted]
    pattern = re.compile(r"(?<![A-Za-z0-9_])(" + "|".join(map(re.escape, names)) + r")(?![A-Za-z0-9_])")
    for name, body in files.items():
        m = pattern.search(body.decode("utf-8"))
        if m:
            raise Refused(3, f"non-emitted source column name {m.group(1)!r} found in {name}")


def render_with_games(data, input_report, result):
    files, manifest = render(data, input_report)
    del files["manifest.json"]
    cfg = result["cfg"]
    sl = cfg["slice"]
    outputs = dict(manifest["outputs"])
    f2_files = {}
    by_season = {}
    for g in result["games"]:
        by_season.setdefault(g["season"], []).append(g)
    for season in range(sl["first_season"], sl["last_completed_season"] + 1):
        games = by_season.get(season, [])
        f2_files[f"games/{season}.json"] = dumps({
            "schema": F2_SCHEMA, "class": "source", "review_status": PENDING, "season": season, "league_code": "NFL",
            "source": cfg["source"]["id"], "verification": "single_source_pinned", "records": games})
    f2_files["games/index.json"] = dumps({
        "schema": F2_SCHEMA, "class": "source", "review_status": PENDING,
        "description": "Lookup from Velora game id to its season shard.",
        "records": sorted(({"game_id": g["game_id"], "season": g["season"]} for g in result["games"]), key=lambda x: x["game_id"])})
    f2_files["team_season_records.json"] = dumps({
        "schema": F2_SCHEMA, "class": "derived", "review_status": PENDING,
        "label": cfg["record_label"], "formula": cfg["record_formula"], "records": result["records"]})
    f2_files["audit/games_dispositions.json"] = dumps({
        "schema": F2_SCHEMA, "kind": "audit", "description": "One disposition for every source row. Not read by pages.",
        **result["dispositions"]})
    f2_files["audit/mapping_report.json"] = dumps({
        "schema": F2_SCHEMA, "kind": "audit", "description": "Every source code-season and how it resolved. Not read by pages.",
        **result["mapping"]})
    header = cfg["file"]["header"]
    emitted = set(cfg["slice"]["digest_fields"])
    scan_non_emitted(f2_files, header, emitted)
    for name, body in f2_files.items():
        files[name] = body
        records = json.loads(body).get("records", json.loads(body).get("rows", []))
        outputs[name] = {"sha256": sha256(body), "records": len(records)}
    build_id = sha256("".join(f"{k}:{v['sha256']}\n" for k, v in sorted(outputs.items())).encode())
    games = result["games"]
    disp = result["dispositions"]["counts"]
    recs = result["records"]
    manifest.update({
        "build_id": build_id,
        "builder": {"name": "tools/build_snapshot.py + tools/f2_games.py", "milestone": "F2.1"},
        "authorization": manifest["authorization"] + "; " + cfg["authorization"],
        "build_kind": "F2.1 staging build. Game files are present but Version B does not read them; capabilities are unchanged until F2.2.",
        "classes": ["curated", "derived", "source"],
        "outputs": outputs,
        "inputs": {**manifest["inputs"], cfg["file"]["name"]: {
            "sha256": result["input_report"]["sha256"], "rows": result["input_report"]["rows"],
            "slice_digest": result["input_report"]["slice_digest"], "slice_rows": result["input_report"]["slice_rows"]}},
        "games_source": {k: cfg["source"][k] for k in ("id", "name", "location", "build_reported", "license", "attribution", "licensing_status")},
        "f2_config": {"config_sha256": result["conf"]["config_sha256"],
                      "packaged_config": result["conf"]["config_sha256"] == sha256(F2_CONFIG.read_bytes()) if F2_CONFIG.is_file() else False,
                      "team_code_map_sha256": cfg["team_code_map"]["sha256"], "exceptions_sha256": cfg["exceptions"]["sha256"],
                      "approved_quarantines": sum(1 for r in result["dispositions"]["rows"] if r.get("approved_quarantine")),
                      "emitted_fields": cfg["slice"]["digest_fields"], "non_emitted_column_count": len(header) - len(emitted)},
        "dispositions": disp,
        "coverage": {**manifest["coverage"], "games": {
            "league": "NFL", "from": sl["first_season"], "to": sl["last_completed_season"],
            "note": f"Game results exist in this snapshot only for NFL seasons {sl['first_season']}–{sl['last_completed_season']}. "
                    "Other seasons and all AFL seasons have no game data here; that is missing data, never zero."}},
    })
    manifest["counts"] = {**manifest["counts"],
        "games": len(games),
        **{f"games_{t.lower()}": sum(1 for g in games if g["game_type"] == t) for t in ("REG", "WC", "DIV", "CON", "SB")},
        "game_seasons": len({g["season"] for g in games}),
        "team_season_records": len(recs),
        "team_season_records_complete": sum(r["status"] == "complete" for r in recs),
        "team_season_records_with_note": sum(r["status"] == "complete_with_note" for r in recs),
        "team_season_records_withheld": sum(r["status"] == "withheld" for r in recs)}
    files["manifest.json"] = dumps(manifest)
    for name, body in files.items():
        check_keys(json.loads(body))
    scan_non_emitted({"manifest.json": files["manifest.json"]}, header, emitted)
    return files, manifest


# ---------------------------------------------------------------- F2.2b install

def load_f22_config(path):
    """Read and validate the F2.2 install config. Refused(2) on any defect."""
    try:
        raw = Path(path).read_bytes()
        cfg = json.loads(raw.decode("utf-8"))
    except (OSError, ValueError) as exc:
        raise Refused(2, f"F2.2 install config unreadable: {path}: {exc}")
    if not isinstance(cfg, dict) or set(cfg) != F22_KEYS:
        raise Refused(2, f"F2.2 install config keys must be exactly {sorted(F22_KEYS)}")
    types = cfg["game_types"]
    if not isinstance(types, dict) or set(types) != set(F2.GAME_TYPES) \
            or not all(isinstance(v, str) and v.strip() for v in types.values()):
        raise Refused(2, f"game_types must label exactly {list(F2.GAME_TYPES)}")
    for k in ("authorization", "build_kind", "audit_note"):
        if not isinstance(cfg[k], str) or not cfg[k].strip():
            raise Refused(2, f"F2.2 install config {k} is empty")
    if not re.fullmatch(r"[0-9a-f]{64}", str(cfg["expected_staging_build_id"])):
        raise Refused(2, "expected_staging_build_id is not a SHA-256 hex digest")
    return cfg, sha256(raw)


def guard_audit_out(path):
    """--audit-out must lie outside the frontend and hold nothing but earlier audit files."""
    resolved = path.resolve()
    if "research" in resolved.parts:
        raise Refused(4, f"refusing to write inside a research workspace: {resolved}")
    if resolved == FRONTEND or FRONTEND in resolved.parents:
        raise Refused(4, f"--audit-out must be outside the frontend folder (audit files are never served): {resolved}")
    if resolved in FRONTEND.parents:
        raise Refused(4, f"refusing to replace a parent of the frontend folder: {resolved}")
    if resolved.exists():
        if not resolved.is_dir():
            raise Refused(4, f"--audit-out exists and is not a folder: {resolved}")
        extra = sorted(p.name for p in resolved.iterdir() if p.name not in AUDIT_FILES)
        if extra:
            raise Refused(4, f"--audit-out holds files other than earlier audit reports {extra}; "
                             "choose an empty or new folder (it is replaced on each install)")
    return resolved


def render_install(data, input_report, result, f22, f22_sha):
    """F2.2 served layout: the staging files minus audit/, with an F2.2 manifest.

    Returns (served files incl. manifest.json, manifest, audit files). The served data
    files are the exact bytes of the F2.1 staging build; only the manifest differs.
    """
    files, staging = render_with_games(data, input_report, result)
    if staging["build_id"] != f22["expected_staging_build_id"]:
        raise Refused(3, "the F2.1 staging build of these inputs is "
                         f"{staging['build_id']}, not the pinned {f22['expected_staging_build_id']}")
    served = {k: v for k, v in files.items() if k != "manifest.json" and not k.startswith("audit/")}
    audit = {k[len("audit/"):]: v for k, v in files.items() if k.startswith("audit/")}
    if sorted(audit) != sorted(set(AUDIT_FILES) - {"audit_manifest.json"}):
        raise Refused(3, f"unexpected audit outputs {sorted(audit)}")
    outputs = {k: staging["outputs"][k] for k in sorted(served)}
    build_id = sha256("".join(f"{k}:{v['sha256']}\n" for k, v in sorted(outputs.items())).encode())
    audit_files = {name: {"sha256": sha256(body), "rows": len(json.loads(body).get("rows", json.loads(body).get("code_seasons", [])))}
                   for name, body in sorted(audit.items())}
    manifest = {k: v for k, v in staging.items() if k != "build_kind"}
    manifest.update({
        "build_id": build_id,
        "builder": {"name": "tools/build_snapshot.py --install + tools/f2_games.py", "milestone": "F2.2"},
        "authorization": staging["authorization"] + "; " + f22["authorization"],
        "build_kind": f22["build_kind"],
        "capabilities": {**CAPABILITIES, "games": True},
        "outputs": outputs,
        "game_types": dict(f22["game_types"]),
        "derived_from": {"staging_build_id": staging["build_id"],
                         "note": "Data files are byte-identical to the F2.1 staging build with this id; only the manifest differs."},
        "f22_config": {"config_sha256": f22_sha,
                       "packaged_config": f22_sha == sha256(F22_CONFIG.read_bytes()) if F22_CONFIG.is_file() else False},
        "audit": {"note": f22["audit_note"], "files": audit_files},
    })
    body = dumps(manifest)
    check_keys(json.loads(body))
    cfg = result["cfg"]
    scan_non_emitted({"manifest.json": body}, cfg["file"]["header"], set(cfg["slice"]["digest_fields"]))
    served["manifest.json"] = body
    audit["audit_manifest.json"] = dumps({
        "schema": SCHEMA, "kind": "audit",
        "description": "Audit reports for one F2.2 install build. Kept outside the served frontend; pages never read them.",
        "snapshot_build_id": build_id, "staging_build_id": staging["build_id"],
        "files": {name: info["sha256"] for name, info in audit_files.items()}})
    return served, manifest, audit


def write_atomically(out, files):
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.parent / f".{out.name}.building-{os.getpid()}"
    old = out.parent / f".{out.name}.previous-{os.getpid()}"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    for name, body in sorted(files.items()):
        (tmp / name).parent.mkdir(parents=True, exist_ok=True)
        (tmp / name).write_bytes(body)
    if out.exists():
        out.rename(old)
    tmp.rename(out)
    shutil.rmtree(old, ignore_errors=True)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", required=True, help="folder containing the seed CSVs (or a seed/ subfolder)")
    ap.add_argument("--out", default=None, help="output folder (default: frontend/data/snapshot)")
    ap.add_argument("--check", action="store_true", help="verify inputs and integrity only; write nothing")
    ap.add_argument("--games", help="F2.1: the pinned nflverse games CSV (requires --out outside data/snapshot, or --install)")
    ap.add_argument("--games-config", default=str(F2_CONFIG), help=argparse.SUPPRESS)
    ap.add_argument("--report", help="F2.1: also write the dispositions report here, including on a quarantine refusal")
    ap.add_argument("--install", action="store_true", help="F2.2b: write the F2.2 served layout into data/snapshot (needs --games and --audit-out)")
    ap.add_argument("--audit-out", help="F2.2b: folder outside the frontend for the audit reports (replaced on each install)")
    ap.add_argument("--install-config", default=str(F22_CONFIG), help=argparse.SUPPRESS)
    args = ap.parse_args(argv)
    if args.install:
        return install(args)
    if args.audit_out:
        return refuse_mode("--audit-out is only used with --install.")
    out_arg = Path(args.out) if args.out else DEFAULT_OUT
    if args.games and out_arg.resolve() == DEFAULT_OUT.resolve() and not args.check:
        print("REFUSED (exit 4): --games needs an explicit --out staging folder outside data/snapshot.", file=sys.stderr)
        print("Nothing was written.", file=sys.stderr)
        return 4
    try:
        pins = json.loads(PINS_FILE.read_text("utf-8"))
        out = guard_output(out_arg, games=bool(args.games) and not args.check)
        report_path = guard_report(Path(args.report)) if args.report else None
        tables, report = read_inputs(Path(args.source), pins)
        data = transform(tables)
        if args.games:
            try:
                result = F2.build(args.games, args.games_config, data)
            except F2.Refused as exc:
                if report_path is not None and not args.check and getattr(exc, "report", None) is not None:
                    write_report(report_path, dumps(exc.report))
                    print(f"dispositions report written to {report_path}", file=sys.stderr)
                raise Refused(exc.code, str(exc))
            files, manifest = render_with_games(data, report, result)
            if report_path is not None and not args.check:
                write_report(report_path, files["audit/games_dispositions.json"])
        else:
            files, manifest = render(data, report)
        if args.check:
            print(f"CHECK OK build_id={manifest['build_id']} counts={manifest['counts']}")
            return 0
        write_atomically(out, files)
    except Refused as exc:
        print(f"REFUSED (exit {exc.code}): {exc}", file=sys.stderr)
        print("Nothing was written to the snapshot folder.", file=sys.stderr)
        return exc.code
    print(f"SNAPSHOT OK build_id={manifest['build_id']}")
    print(f"  out    {out}")
    print(f"  counts {json.dumps(manifest['counts'], sort_keys=True)}")
    return 0


def refuse_mode(message):
    print(f"REFUSED (exit 4): {message}", file=sys.stderr)
    print("Nothing was written.", file=sys.stderr)
    return 4


def install(args):
    """F2.2b install mode. Writes audit reports first, then the served snapshot, each atomically."""
    if not args.games:
        return refuse_mode("--install needs --games (the pinned games CSV).")
    if not args.audit_out:
        return refuse_mode("--install needs --audit-out, a folder outside the frontend for the audit reports.")
    if args.out:
        return refuse_mode("--install always writes frontend/data/snapshot; do not pass --out.")
    if args.report:
        return refuse_mode("--install writes the dispositions report into --audit-out; do not pass --report.")
    try:
        out = guard_output(DEFAULT_OUT, games=False)
        audit_out = guard_audit_out(Path(args.audit_out))
        f22, f22_sha = load_f22_config(args.install_config)
        pins = json.loads(PINS_FILE.read_text("utf-8"))
        tables, report = read_inputs(Path(args.source), pins)
        data = transform(tables)
        try:
            result = F2.build(args.games, args.games_config, data)
        except F2.Refused as exc:
            raise Refused(exc.code, str(exc))
        files, manifest, audit = render_install(data, report, result, f22, f22_sha)
        if args.check:
            print(f"CHECK OK build_id={manifest['build_id']} staging_build_id={manifest['derived_from']['staging_build_id']} counts={manifest['counts']}")
            return 0
        write_atomically(audit_out, audit)
        write_atomically(out, files)
    except Refused as exc:
        print(f"REFUSED (exit {exc.code}): {exc}", file=sys.stderr)
        print("Nothing was written to the snapshot or audit folder.", file=sys.stderr)
        return exc.code
    print(f"SNAPSHOT OK build_id={manifest['build_id']}")
    print(f"  staging_build_id {manifest['derived_from']['staging_build_id']}")
    print(f"  out    {out}")
    print(f"  audit  {audit_out}")
    print(f"  counts {json.dumps(manifest['counts'], sort_keys=True)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
