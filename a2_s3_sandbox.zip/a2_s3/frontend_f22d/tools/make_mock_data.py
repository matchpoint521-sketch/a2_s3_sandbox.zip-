#!/usr/bin/env python3
"""Generate Version A demonstration data (fictional league, teams and players).

Everything here is invented to exercise the interface. Nothing describes the NFL.
Deterministic: the same script always produces byte-identical files.
Usage: python3 tools/make_mock_data.py
"""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "data" / "mock"
SCHEMA = "velora-nfl-frontend/1"
FIRST, LAST = 1962, 2025
NOTE = "Demonstration record. Fictional; not NFL history."


def demo(record):
    return {**record, "class": "demo", "review_status": None, "verification": None, "evidence": NOTE}


leagues = [demo({"league_code": "DEMO", "name": "Demonstration League", "recognized_by_nfl": False,
                 "notes": "A fictional league used to develop the interface."})]

seasons = []
for year in range(FIRST, LAST + 1):
    games = None if year == FIRST else (12 if year < 1978 else 14)
    note = "Demonstration: no uniform schedule in the first season." if games is None else None
    seasons.append(demo({"season_id": f"DEMO-{year}", "league_code": "DEMO", "year": year,
                         "regular_season_games": games, "schedule_note": note}))

franchises = [
    ("dm_lan", "Northgate Lanterns", "active", 1962, None, "Demonstrates a relocation."),
    ("dm_anc", "Saltmarsh Anchors", "active", 1962, None, None),
    ("dm_fox", "Redmoor Foxes", "active", 1970, None, "Demonstrates a rename without relocation."),
    ("dm_stg", "Grayhaven Stags", "active", 1962, None, None),
    ("dm_gul", "Kestrel Bay Gulls", "defunct", 1962, 1979, "Demonstrates a defunct franchise and a merged season."),
    ("dm_frg", "Ironvale Forge", "defunct", 1962, 1974, "Demonstrates a defunct franchise and a merged season."),
]
franchises = [demo({"franchise_id": f, "display_name": n, "status": s, "origin_league": "DEMO",
                    "first_nfl_season": a, "last_season": b, "origin_note": note})
              for f, n, s, a, b, note in franchises]

identities = [
    ("di_lan_01", "dm_lan", "Port Halden", "Lanterns", 1962, 1983),
    ("di_lan_02", "dm_lan", "Northgate", "Lanterns", 1984, None),
    ("di_anc_01", "dm_anc", "Saltmarsh", "Anchors", 1962, None),
    ("di_fox_01", "dm_fox", "Redmoor", "Owls", 1970, 1991),
    ("di_fox_02", "dm_fox", "Redmoor", "Foxes", 1992, None),
    ("di_stg_01", "dm_stg", "Grayhaven", "Stags", 1962, None),
    ("di_gul_01", "dm_gul", "Kestrel Bay", "Gulls", 1962, 1973),
    ("di_gul_02", "dm_gul", "Kestrel Bay", "Gulls", 1975, 1979),
    ("di_frg_01", "dm_frg", "Ironvale", "Forge", 1962, 1973),
]
identities = [demo({"identity_id": i, "franchise_id": f, "location_name": loc, "nickname": nick,
                    "first_season": a, "last_season": b}) for i, f, loc, nick, a, b in identities]

merged_seasons = [demo({
    "merged_key": "dmrg_1974", "season": 1974, "common_name": "Kestrel–Ironvale Combine",
    "franchise_ids": ["dm_frg", "dm_gul"],
    "identity": demo({"identity_id": "di_mrg_1974", "season": 1974, "display_name": "Kestrel–Ironvale Combine",
                      "location_name": None, "nickname": None, "aliases_note": None}),
})]

players = [
    ("dp_001", "Rowan Ashdale", "QB", 1996, [("dm_lan", 2015, 2021), ("dm_fox", 2022, 2025)]),
    ("dp_002", "Tobias Merriwether", "RB", 1999, [("dm_anc", 2018, 2025)]),
    ("dp_003", "Quinn Halvorsen", "WR", 1994, [("dm_stg", 2013, 2019), ("dm_lan", 2020, 2023)]),
    ("dp_004", "Ezra Thornbury", "LB", 1952, [("dm_gul", 1975, 1979), ("dm_fox", 1980, 1984)]),
]
players = [demo({"player_id": p, "display_name": n, "position": pos, "birth_year": by,
                 "stints": [{"franchise_id": f, "first_season": a, "last_season": b} for f, a, b in st]})
           for p, n, pos, by, st in players]

CAPABILITIES = {"franchises": True, "seasons": True, "games": False, "headToHead": False, "players": True,
                "playerStats": False, "statCoverage": False, "compare": False, "search": True}


def dumps(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=1) + "\n").encode("utf-8")


def main():
    data = {"leagues": leagues, "seasons": seasons, "franchises": franchises, "identities": identities,
            "merged_seasons": merged_seasons, "players": players}
    OUT.mkdir(parents=True, exist_ok=True)
    outputs = {}
    for name, records in data.items():
        body = dumps({"schema": SCHEMA, "class": "demo", "records": records})
        (OUT / f"{name}.json").write_bytes(body)
        outputs[f"{name}.json"] = {"sha256": hashlib.sha256(body).hexdigest(), "records": len(records)}
    manifest = {
        "schema": SCHEMA, "provider": "mock", "classes": ["demo"],
        "notice": "Demonstration data. Every team, player and season here is fictional.",
        "outputs": outputs,
        "counts": {"leagues": len(leagues), "seasons": len(seasons), "franchises": len(franchises),
                   "franchises_active": sum(f["status"] == "active" for f in franchises),
                   "franchises_defunct": sum(f["status"] == "defunct" for f in franchises),
                   "identities": len(identities), "merged_seasons": len(merged_seasons), "players": len(players)},
        "coverage": {"seasons": {"from": FIRST, "to": LAST}},
        "capabilities": CAPABILITIES,
    }
    (OUT / "manifest.json").write_bytes(dumps(manifest))
    print("MOCK OK", json.dumps(manifest["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
