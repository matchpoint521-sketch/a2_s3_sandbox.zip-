# Fonts — notice

Both families are licensed under the **SIL Open Font License 1.1** (OFL-1.1). Each folder holds the LICENSE file shipped in its npm package, copied verbatim. The fonts are self-hosted, nothing is fetched from a network, and they are unmodified (same bytes as the package).

| Family | Files | Source | Copyright (from the font's own name table) |
|---|---|---|---|
| Big Shoulders Display | `latin-700-normal`, `latin-800-normal` (woff2) | npm `@fontsource/big-shoulders-display@5.3.0`, published 2026-07-19, tarball SHA-256 `2b1193236ad6a1e801780541347a6d1b46bd11e866098edf492a87fdccc8849c` | Copyright 2019 The Big Shoulders Project Authors |
| Atkinson Hyperlegible Next | `latin-400-normal`, `latin-400-italic`, `latin-700-normal` (woff2) | npm `@fontsource/atkinson-hyperlegible-next@5.3.0`, published 2026-07-19, tarball SHA-256 `33dcb7d0d4e2ea98a96985ca7448f738c3b5b370cfc5230b1e40e4f728920cc2` | Copyright 2020-2024 The Atkinson Hyperlegible Next Project Authors |

## Note for licensing review

The Big Shoulders package LICENSE starts with the line "Google Inc." instead of the authors' copyright notice. The font file itself names "The Big Shoulders Project Authors". Both are OFL-1.1, so this does not change the terms. It should still be reconciled in the attribution text before public deployment.

The OFL allows bundling and redistribution with software. The fonts may not be sold on their own. "Big Shoulders" and "Atkinson Hyperlegible" may be Reserved Font Names, so a modified version would need a different name. These files are used unmodified.
