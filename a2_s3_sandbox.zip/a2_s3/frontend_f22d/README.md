# Velora pro football frontend (F1.5 + F2.1 builder)

F1.5 is a visual refinement of F1 ("Line to Gain, night game"). Data, providers, routes and capability gates are unchanged from F1. See `NFL_FRONTEND_F1_5_DESIGN_SPEC.md` (delivered beside the ZIP) for the design system.

One source tree, two versions:

| Version | Entry | Data | Needs |
|---|---|---|---|
| A, foundation | `foundation.html` | `data/mock/`: fictional demonstration league, teams and players | Nothing |
| B, data validation | `validation.html` | `data/snapshot/`: local development snapshot of curated seed records, all pending review | The snapshot, built once (below) |

Both entries load the same `src/` code. Each entry binds exactly one provider (`providers/mock` or `providers/snapshot`). Version B never falls back to demonstration data: with no snapshot, every page shows "Snapshot not built".

No framework, no build step, no runtime dependencies. No database connection exists anywhere in this code. Fonts are self-hosted OFL files in `assets/fonts/` (licences and notice in that folder); nothing loads from the network.

## Requirements
- Python 3.10+ (builder, local server, Python tests)
- Node 18+ (Node tests only)
- A modern browser

## 1. Build the Version B snapshot (optional for Version A)
The builder reads six hash-pinned seed CSVs (approval D-F1) and refuses if any hash differs. It only reads them.

```bash
cd "$HOME/Claude:Chat Stuff/Velora(NFL website)/frontend"
python3 tools/build_snapshot.py --source "<folder containing the seed CSVs, or its parent with seed/>" --check
python3 tools/build_snapshot.py --source "<same folder>"
```
Expected: `SNAPSHOT OK build_id=50dfae255ff610ad738593fc8a98b131d209837c70ff59fd1d851e953b790c2a`.

Exit codes: 0 ok · 2 input missing or hash mismatch · 3 integrity failure · 4 output location refused. On any refusal nothing is written.

## 1a. F2.1 staging build: historical games (optional)
F2.1 adds a game builder (`tools/f2_games.py`, approval D-F2a to D-F2i). It reads the pinned nflverse games CSV (SHA-256 `24d55c06…`) plus the seed CSVs and writes season-sharded games (1999–2025), a game index, derived team-season records and audit reports. **Version B does not read these files yet**: game builds must go to an explicit staging `--out` folder, and `data/snapshot` or `data/mock` are refused (exit 4) until the F2.2 provider integration is approved. Without `--games` the builder output is byte-identical to F1.5.

```bash
python3 tools/build_snapshot.py --source "<seed folder>" --games "<pinned games CSV>" --out "<staging folder>/snapshot" --report "<staging folder>/dispositions.json"
```
Expected: `SNAPSHOT OK build_id=dca7bad746883593fa059d0ebdad03076b277ce9b85de3116cf24a14d5419499`.

Pins and rules live in `tools/f2_games_inputs.json`, `tools/f2_team_code_map.csv` and `tools/f2_exceptions.json` (all hash-pinned). Any quarantined row in 1999–2025 refuses the build (exit 3) unless it is listed in `f2_exceptions.json`; `--report` then still writes the dispositions for review.

F2.1 tests (skip without both variables):
```bash
VELORA_SEED_SOURCE="<seed folder>" VELORA_GAMES_SOURCE="<pinned games CSV>" python3 -m unittest tests/test_f2_games.py -v
```

## 2. Run the tests
```bash
node --test tests/*.test.mjs
VELORA_SEED_SOURCE="<seed folder>" python3 -m unittest tests/test_build_snapshot.py -v
```
Without a snapshot, snapshot-dependent Node tests report SKIP. Without `VELORA_SEED_SOURCE`, the Python build tests report SKIP.

Optional (needs Python Playwright + Chromium): `python3 tests/browser_smoke.py --screens /tmp/velora_shots`. Without a built snapshot the Version B passes that need it print explicit `SKIP` lines; the no-snapshot (fail-closed) pass always runs. Set `AXE_JS=<path to axe.min.js>` to add an accessibility scan.

## 3. Open it
```bash
python3 -m http.server 8731 --bind 127.0.0.1
```
Then open `http://127.0.0.1:8731/foundation.html` or `http://127.0.0.1:8731/validation.html`.
A static file server is required only because browsers block ES modules and `fetch` on `file://`. It is not a backend.

## Layout
```
entries/      one file per version; the only place a provider is chosen
src/app/      boot, router, routes, shell
src/core/     provider contract, envelopes, data classes, capabilities, shared query logic
src/components/  DOM helpers, badges, states, tables, field strip
src/styles/   tokens (colour, type, fonts), base, layout, components, scenes (section backdrops)
assets/fonts/ self-hosted OFL fonts with their LICENSE files and FONTS_NOTICE.md
src/pages/    one module per page; pages only use ctx.provider
providers/    mock and snapshot bindings
data/mock/    committed demonstration data (regenerate: python3 tools/make_mock_data.py)
data/snapshot/  generated, git-ignored
tools/        build_snapshot.py, snapshot_inputs.json, make_mock_data.py
tests/        Node tests (*.test.mjs), Python builder tests, optional browser smoke test
```

## 4. Historical games in Version B (F2.2d-A1, development only)
The snapshot provider now serves the installed game files (snapshot build `5913437c…`). Version A (mock) is unchanged: it has no game data and its game methods return `unavailable`.

**Coverage.** NFL seasons 1999–2025 only: 7,276 completed games (6,967 regular season, 120 Wild Card, 108 Divisional, 54 Conference, 27 Super Bowl) and 861 team-season records.
- Seasons before 1999, all AFL seasons (1960–1969) and the merged seasons (1943–1945) have **no game data here**. That is missing data, not zero games, and the provider returns `unavailable` with that reason.
- The 2026 season is not completed and is `unavailable` with that reason.
- Pages must never show an empty list or a 0–0 record for these seasons.

**Provenance.**
- **Game results** (class `source`): from the nflverse-data `schedules` release, verified against that one pinned source only (`single_source_pinned`). Attribution: "Game results: nflverse, nflverse-data, CC BY 4.0."
- **Team-season records** (class `derived`): calculated by Velora from those results. **Not official league standings.** The label and formula travel with every record.
- **Status:** everything is `pending_review`. Nothing is historically certified.
- **Notes:** two 2022 records (Buffalo and Cincinnati) are `complete_with_note`. Their note resolves to the 2022 season's schedule note (one game was not completed).

**Development only.** Licensing gates L-1 to L-8 and the trademark review are open. Do not publish, deploy, share or upload this build or its data. There are no betting, prediction or odds features, and none may be added.

**Provider methods** (contract: 14 methods; the original 12 in their original order, then 2 new):
- `getGame(gameId)`: one game with team names, season and round label. Only `g_` plus 12 hex IDs; source keys such as `1999_01_ARI_PHI` are `not_found`.
- `listSeasonGames(league, year, {week, type})`: games of one season, optionally filtered.
- `getTeamSeason(franchiseId, year)`: now also returns that team's `games` and a `results` block with a state: `available`, `no_games`, `outside_coverage`, `not_completed` or `unavailable`. `record` and `games` are null unless the state is `available`.
- `getFranchiseRecords(franchiseId)`: one row per covered season, under the name used that season. There are no totals across seasons.

**Checks before anything is shown.** Game files load lazily: the index on the first game lookup, one season file on first use, and the records file once.
- Each season is accepted only after its games, its index entries and its team-season records all pass `src/core/games.js`.
- Any problem rejects the call with `DataLoadError`; nothing partial is returned.
- The provider then forgets only that season, so other seasons keep working.

**Known limitation: reload after a data-check failure.** The browser loader (`src/core/loader.js`) keeps one copy of each file it has read, for the life of the page. If a game file fails its checks, retrying on the same page sees the same copy and fails again. After the snapshot is corrected, **reload the page**. This is covered by test G25-4 and is intentional: `loader.js` and the portable loader are not changed.

## 5. Game and team-season pages (F2.2d-A2, development only)
The interim A1 notes about these pages no longer apply.

**Game page** (`#/games/<id>`):
- Shows the two teams under the names they used that season, the final score and the result (or "Tie").
- Also shows the season, the week (regular season) or round (postseason), the date, and the overtime and neutral-site flags.
- Shows the source, attribution, source key and pending-review status.
- Nothing else is shown, because nothing else is in the snapshot: no venue, quarter scores or player data.
- An id that is not in the data gives "Game not found". Version A (mock) has no games and shows the unavailable reason.

**Team-season page** (`#/teams/<franchise>/<year>`):
- When results are available, shows the calculated record (class `derived`, "Not official league standings", with its formula) and the regular-season and postseason games in stored order.
- Opponents appear under the names they used that season. Each game links to its game page, and each game page links back to both team-seasons.
- For 2022 Buffalo and Cincinnati: "16 of 17 expected regular-season games are in this data", plus the season's schedule note verbatim. No row is added for the no-contest game.
- Seasons outside game coverage, the 2026 season (not completed) and Version A show the provider's reason and no record numbers.

**Season page:** in Version B it now states that standings and playoff brackets are not shown yet, with the manifest's coverage note (D-A2-6b). Version A is unchanged.

**Code:** display rules live in `src/core/game-view.js`, which is pure and DOM-free. Pages read only provider envelopes. The provider, contract, routes and data are unchanged.

**Tests.** `node --test tests/*.test.mjs` runs 101 tests (86 from A1 and 15 in `tests/game_view.test.mjs`, which renders the pages in Node against the real snapshot). One test needs `VELORA_F21_STAGING` set to the F2.1 staging snapshot folder; without it, that test reports `SKIP`. `tests/browser_smoke.py` also checks the A2 pages at 1280 px and 375 px.

**Portable build.** The P-1 builder's `--check` for the foundation (Version A) file now reports a new portable build ID, because the bundled code changed. The ID also depends on every file listed in `SHA256SUMS`, this README included, so it is recorded in each milestone's handoff (F2.2d-A1, F2.2d-A2) rather than here. The frozen P-1 artifact (`41f0dd50…`) is unchanged and remains the verified P-1 build. Games in a standalone file are a later, separately approved step (P-5).
