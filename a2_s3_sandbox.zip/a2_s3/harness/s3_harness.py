"""A2-S3 verification harness (sandbox only; lives outside the frontend tree, writes nothing into it).
Usage: python3 s3_harness.py <frontend> <axe.min.js> <out dir>"""
import functools, glob, http.server, json, os, re, shutil, sys, tempfile, threading
from pathlib import Path
from playwright.sync_api import sync_playwright

FE, AXE, OUT = Path(sys.argv[1]), Path(sys.argv[2]).read_text(), Path(sys.argv[3])
SHOTS = OUT / "screenshots"; SHOTS.mkdir(parents=True, exist_ok=True)
results, findings = [], []
def check(ok, msg, group):
    results.append({"group": group, "ok": bool(ok), "msg": msg})

class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
def serve(root):
    h = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Q, directory=str(root)))
    threading.Thread(target=h.serve_forever, daemon=True).start()
    return h, f"http://127.0.0.1:{h.server_address[1]}/"

# ---------------------------------------------------------------- route matrix from the snapshot itself
snap = FE / "data" / "snapshot"
games = []
for f in sorted(glob.glob(str(snap / "games" / "[0-9]*.json"))):
    games += json.load(open(f))["records"]
ids = {i["identity_id"]: i for i in json.load(open(snap / "identities.json"))["records"]}
recs = json.load(open(snap / "team_season_records.json"))["records"]
name = lambda iid: ids[iid].get("display_name") or f"{ids[iid]['location_name']} {ids[iid]['nickname']}"
by_id = {g["game_id"]: g for g in games}
sel = {}
sel["super_bowl"] = [g["game_id"] for g in games if g["game_type"] == "SB"]
sel["tie"] = [g["game_id"] for g in games if g["home"]["score"] == g["away"]["score"]]
sel["post_ot"] = [g["game_id"] for g in games if g["overtime"] and g["game_type"] != "REG"]
sel["neutral_reg"] = [g["game_id"] for g in games if g["neutral_site"] and g["game_type"] == "REG"]
sel["neutral_wc"] = [g["game_id"] for g in games if g["neutral_site"] and g["game_type"] == "WC"]
sel["buf_cin_2022"] = [g["game_id"] for g in games if g["season"] == 2022 and {"fr_buf", "fr_cin"} & {g["home"]["franchise_id"], g["away"]["franchise_id"]}]
reloc_fr = {"fr_lar": [2015, 2016], "fr_lac": [2016, 2017], "fr_lv": [2019, 2020], "fr_was": [2019, 2020, 2022]}
sel["relocation_first_games"] = []
for f, years in reloc_fr.items():
    for y in years:
        sel["relocation_first_games"].append(next(g["game_id"] for g in games if g["season"] == y and f in (g["home"]["franchise_id"], g["away"]["franchise_id"])))
GAME_IDS = sorted(set(sum(sel.values(), [])))
TS = [("fr_buf", 2022), ("fr_cin", 2022), ("fr_hou", 2022), ("fr_lar", 2015), ("fr_lar", 2016), ("fr_lac", 2016), ("fr_lac", 2017),
      ("fr_lv", 2019), ("fr_lv", 2020), ("fr_was", 2019), ("fr_was", 2020), ("fr_was", 2022), ("fr_ten", 1999), ("fr_ne", 2025),
      ("fr_sea", 2025), ("fr_lar", 2024), ("fr_kc", 2023)]
TS_NODATA = [("fr_ten", 1998, "outside"), ("fr_cle", 1997, "outside"), ("fr_ari", 1944, "merged/outside"), ("fr_kc", 1965, "AFL/outside"),
             ("fr_buf", 2026, "not_completed"), ("fr_hou", 2000, "empty"), ("fr_buf", 2027, "not_found"), ("fr_nope", 2000, "not_found")]
SEASONS = [("NFL", 2022), ("NFL", 1950), ("AFL", 1965), ("NFL", 2026)]
BAD_GAMES = ["1999_01_MIN_ATL", "g_000000000000", "g_D34106702F37"]
rec_of = {(r["franchise_id"], r["season"]): r for r in recs}
RECORD_SHAPE = re.compile(r"(?<!\d)\d{1,2}\u2013\d{1,2}(?!\d)|Wins \d|No postseason games")
STRAY = re.compile(r"\b(null|undefined|NaN)\b|\[object Object\]")
WAIT = "() => document.querySelector('main h1') && !document.querySelector('main').hasAttribute('aria-busy')"

def load(page, url):
    errs = []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.goto(url); page.wait_for_function(WAIT); page.wait_for_timeout(200)
    return errs

def axe_scan(page):
    page.add_script_tag(content=AXE)
    return page.evaluate("""async () => (await axe.run(document, {resultTypes: ['violations', 'incomplete']}))""")

with sync_playwright() as p:
    br = p.chromium.launch()
    httpd, base = serve(FE)
    V, F = base + "validation.html", base + "foundation.html"

    # ------------------------------------------------ 1. axe on every A1 and A2 route (both versions)
    a1_routes = {"validation": ["#/", "#/compare", "#/compare/teams?a=fr_ari", "#/compare/seasons", "#/compare/players", "#/teams", "#/teams/fr_ari",
                               "#/teams/fr_ari/1944", "#/players", "#/players/dp_001", "#/seasons", "#/seasons/AFL/1965", "#/search?q=cardinals", "#/data", "#/nope"],
                 "foundation": ["#/", "#/compare", "#/teams", "#/teams/dm_lan", "#/teams/dm_lan/1990", "#/players", "#/players/dp_001", "#/seasons",
                               "#/seasons/DEMO/1974", "#/games/dg_0001", "#/search?q=redmoor", "#/data", "#/nope"]}
    axe_routes = [("validation", r) for r in a1_routes["validation"]] + [("foundation", r) for r in a1_routes["foundation"]]
    axe_routes += [("validation", f"#/games/{g}") for g in ["g_d34106702f37", sel["tie"][0], sel["neutral_wc"][0], sel["super_bowl"][-1], sel["post_ot"][0]] + BAD_GAMES[:2]]
    axe_routes += [("validation", f"#/teams/{f}/{y}") for f, y in [("fr_buf", 2022), ("fr_lar", 2015), ("fr_hou", 2022)]] + [("validation", f"#/teams/{f}/{y}") for f, y, _ in TS_NODATA]
    axe_routes += [("validation", f"#/seasons/{l}/{y}") for l, y in SEASONS]
    axe_summary = {}
    for width in (1280, 375):
        ctx = br.new_context(viewport={"width": width, "height": 900}, bypass_csp=True)
        for ver, r in axe_routes:
            page = ctx.new_page()
            load(page, (V if ver == "validation" else F) + r)
            res = axe_scan(page)
            for v in res["violations"]:
                findings.append({"kind": "violation", "width": width, "version": ver, "route": r, "id": v["id"], "impact": v["impact"], "nodes": len(v["nodes"]), "help": v["help"],
                                 "targets": [n["target"] for n in v["nodes"][:3]]})
            for v in res["incomplete"]:
                findings.append({"kind": "needs_review", "width": width, "version": ver, "route": r, "id": v["id"], "impact": v["impact"], "nodes": len(v["nodes"]), "help": v["help"],
                                 "targets": [n["target"] for n in v["nodes"][:3]]})
            serious = [v["id"] for v in res["violations"] if v["impact"] in ("serious", "critical")]
            check(not serious, f"axe {ver} {r} @{width}: no serious/critical ({serious})", "axe")
            page.close()
        ctx.close()

    # ------------------------------------------------ 2. keyboard, tab order, skip link, focus
    def tab_walk(page, n=80):
        seq = []
        for _ in range(n):
            page.keyboard.press("Tab")
            info = page.evaluate("""() => { const e = document.activeElement; const cs = getComputedStyle(e);
              return { tag: e.tagName, text: (e.innerText || e.value || e.getAttribute('aria-label') || '').trim().slice(0, 50), href: e.getAttribute('href'),
                       outline: cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) >= 2, inMain: !!e.closest('main'), tabindex: e.getAttribute('tabindex') } }""")
            seq.append(info)
            if info["tag"] == "BODY": break
        return seq
    ctx = br.new_context(viewport={"width": 1280, "height": 900})
    for r in ["#/games/g_d34106702f37", "#/teams/fr_buf/2022", "#/games/g_000000000000", "#/teams/fr_ten/1998"]:
        page = ctx.new_page(); load(page, V + r)
        page.evaluate("document.activeElement && document.activeElement.blur()")
        seq = tab_walk(page)
        check(seq[0]["text"] == "Skip to content", f"kbd {r}: first Tab is the skip link ({seq[0]['text']})", "keyboard")
        check(all(s["outline"] for s in seq if s["tag"] != "BODY"), f"kbd {r}: every focused element shows a >=2px outline", "keyboard")
        check(not any(s["tabindex"] not in (None, "0", "-1") for s in seq), f"kbd {r}: no positive tabindex", "keyboard")
        main_links = page.evaluate("[...document.querySelectorAll('main a[href], main button, main summary, main [tabindex=\"0\"]')].length")
        reached = sum(1 for s in seq if s["inMain"])
        check(reached == main_links, f"kbd {r}: all {main_links} focusable items in main reached by Tab ({reached})", "keyboard")
        (OUT / "keyboard").mkdir(exist_ok=True)
        (OUT / "keyboard" / (re.sub(r"[^a-z0-9]+", "_", r) + ".json")).write_text(json.dumps(seq, indent=1))
        # skip link activation moves focus to main
        page.evaluate("document.activeElement && document.activeElement.blur()")
        page.keyboard.press("Tab"); page.keyboard.press("Enter")
        check(page.evaluate("document.activeElement.id") == "main", f"kbd {r}: skip link focuses main", "keyboard")
        page.close()
    # keyboard-only navigation: team-season -> game (Enter on a result link) -> back link -> focus on h1 each time
    page = ctx.new_page(); load(page, V + "#/teams/fr_buf/2022")
    page.focus("main a[href^='#/games/']"); page.keyboard.press("Enter")
    page.wait_for_function("() => location.hash.startsWith('#/games/') && " + WAIT[6:]); page.wait_for_timeout(200)
    check(page.evaluate("document.activeElement === document.querySelector('main h1')"), "kbd nav: Enter on a result link opens the game; focus on h1", "keyboard")
    page.focus("main a[href='#/teams/fr_buf/2022']"); page.keyboard.press("Enter")
    page.wait_for_function("() => location.hash === '#/teams/fr_buf/2022' && " + WAIT[6:]); page.wait_for_timeout(200)
    check(page.evaluate("document.activeElement === document.querySelector('main h1')"), "kbd nav: back to the team-season; focus on h1", "keyboard")
    page.go_back(); page.wait_for_function("() => location.hash.startsWith('#/games/') && " + WAIT[6:])
    check(page.inner_text("main h1").endswith("Buffalo Bills") or "Buffalo Bills" in page.inner_text("main h1"), "kbd nav: browser Back returns to the game", "keyboard")
    # details/summary operable by keyboard
    load(page, V + "#/teams/fr_buf/2022")
    page.focus("main summary"); page.keyboard.press("Enter")
    check(page.evaluate("document.querySelector('main details').open"), "kbd: Enter opens 'How this record is calculated'", "keyboard")
    # result-link accessible names
    names = page.evaluate("[...document.querySelectorAll('main a.result-link')].map(a => a.innerText.replace(/\\s+/g,' ').trim())")
    acc = page.evaluate("""async () => [...document.querySelectorAll('main a.result-link')].map(a => a.textContent.replace(/\\s+/g,' ').trim())""")
    check(all(re.match(r"^[WLT]?(Win|Loss|Tie), \d+–\d+, game details$", a.replace("W", "", 1) if a.startswith("W") else a) or re.search(r"(Win|Loss|Tie), \d+–\d+, game details$", a) for a in acc),
          f"a11y: result link text includes the full word and 'game details' (e.g. '{acc[0]}')", "keyboard")
    hidden = page.evaluate("getComputedStyle(document.querySelector('main a.result-link .result-letter')).getPropertyValue('display')")
    check(page.evaluate("document.querySelector('main a.result-link .result-letter').getAttribute('aria-hidden')") == "true", "a11y: W/L/T letter is aria-hidden (word is announced instead)", "keyboard")
    ctx.close()

    # ------------------------------------------------ 3. display modes
    mode_routes = ["#/games/g_d34106702f37", "#/games/" + sel["super_bowl"][-1], "#/teams/fr_buf/2022", "#/teams/fr_ten/1998", "#/seasons/NFL/2022", "#/games/g_000000000000"]
    def overflow(page):
        return page.evaluate("document.documentElement.scrollWidth") - page.evaluate("window.innerWidth")
    for label, opts in [("320px", {"viewport": {"width": 320, "height": 700}}), ("375px", {"viewport": {"width": 375, "height": 812}}),
                        ("zoom200", {"viewport": {"width": 640, "height": 450}, "device_scale_factor": 2}),
                        ("forced_colors", {"viewport": {"width": 1280, "height": 900}, "forced_colors": "active"}),
                        ("reduced_motion", {"viewport": {"width": 1280, "height": 900}, "reduced_motion": "reduce"})]:
        ctx = br.new_context(**opts)
        for r in mode_routes:
            page = ctx.new_page(); errs = load(page, V + r)
            check(not errs, f"{label} {r}: no page errors {errs}", "modes")
            check(overflow(page) <= 0, f"{label} {r}: no horizontal page overflow ({overflow(page)}px)", "modes")
            if label == "forced_colors":
                check(page.evaluate("getComputedStyle(document.querySelector('.backdrop')).display") == "none", f"{label} {r}: decorative backdrop hidden", "modes")
                if "games/g_d" in r:
                    vis = page.evaluate("[...document.querySelectorAll('.scoreline__team, .scoreline__score, .scoreline__meta')].every(e => e.getBoundingClientRect().height > 0 && getComputedStyle(e).visibility === 'visible')")
                    check(vis, f"{label} {r}: scoreline text visible", "modes")
            if label == "reduced_motion":
                durs = page.evaluate("[...document.querySelectorAll('main *')].map(e => getComputedStyle(e)).filter(cs => parseFloat(cs.transitionDuration) > 0 || (cs.animationName !== 'none' && parseFloat(cs.animationDuration) > 0)).length")
                check(durs == 0, f"{label} {r}: no running transitions/animations in main ({durs})", "modes")
            if label in ("320px", "zoom200") and "teams/fr_buf" in r:
                # tables scroll inside their own labelled region instead of the page
                wraps = page.evaluate("[...document.querySelectorAll('.table-wrap')].map(w => [w.scrollWidth > w.clientWidth, w.getAttribute('role'), w.getAttribute('tabindex')])")
                check(all(w[1] == "region" and w[2] == "0" for w in wraps), f"{label} {r}: wide tables scroll in focusable labelled regions {wraps}", "modes")
            page.close()
        ctx.close()
    # reduced motion: the A1 field sweep still disabled (team page)
    ctx = br.new_context(reduced_motion="reduce"); page = ctx.new_page(); load(page, V + "#/teams/fr_buf")
    check(page.evaluate("getComputedStyle(document.querySelector('.field__line')).transitionDuration") in ("0s", "0ms"), "reduced_motion: A1 field sweep still off", "modes"); ctx.close()

    # ------------------------------------------------ 4. states
    ctx = br.new_context(viewport={"width": 1280, "height": 900})
    # loading: hold the season shard for 1.5 s
    page = ctx.new_page()
    def slow(route, *_):
        import time; time.sleep(1.5); route.continue_()
    page.route("**/data/snapshot/games/2022.json", slow)
    page.goto(V + "#/games/g_d34106702f37"); page.wait_for_timeout(600)
    busy = page.evaluate("document.querySelector('main').getAttribute('aria-busy')")
    loading = page.evaluate("document.querySelector('main .state--loading h2')?.textContent")
    page.screenshot(path=str(SHOTS / "state_loading_desktop.png"))
    check(busy == "true" and loading == "Loading this page", f"state loading: aria-busy and loading text shown ({busy}, {loading})", "states")
    page.wait_for_function(WAIT)
    check(page.inner_text("main h1") == "Buffalo Bills at Los Angeles Rams", "state loading: resolves to the game", "states"); page.close()
    # corrupted data: altered score (fails validation), invalid JSON, missing file (404)
    raw = (snap / "games" / "2022.json").read_text()
    bad_score = json.loads(raw); bad_score["records"][0]["home"]["score"] = 99
    variants = {"tampered_score": json.dumps(bad_score), "invalid_json": raw[:500], "missing_404": None}
    for label, body in variants.items():
        page = ctx.new_page()
        if body is None: page.route("**/data/snapshot/games/2022.json", lambda rt, *_: rt.fulfill(status=404, body="nope"))
        else: page.route("**/data/snapshot/games/2022.json", (lambda b: (lambda rt, *_: rt.fulfill(status=200, content_type="application/json", body=b)))(body))
        load(page, V + "#/games/g_d34106702f37")
        h1 = page.inner_text("main h1"); text = page.inner_text("main")
        check(h1 == "Something went wrong" and page.query_selector("main [role=alert]") and page.query_selector("main button.action"),
              f"state corrupted/{label}: game page shows the error state with Try again (h1 '{h1}')", "states")
        check(not RECORD_SHAPE.search(text) and "Buffalo Bills" not in text, f"state corrupted/{label}: nothing partial shown", "states")
        if label == "tampered_score": page.screenshot(path=str(SHOTS / "state_data_error_desktop.png"))
        # team-season of the same season also fails closed; another season still works on the same page
        page.goto(V + "#/teams/fr_buf/2022"); page.wait_for_function(WAIT); page.wait_for_timeout(200)
        check(page.inner_text("main h1") == "Something went wrong", f"state corrupted/{label}: team-season 2022 fails closed", "states")
        page.goto(V + "#/teams/fr_buf/2021"); page.wait_for_function(WAIT); page.wait_for_timeout(200)
        check(page.inner_text("main h1") == "Buffalo Bills, 2021" and "Regular season" in page.inner_text("main"), f"state corrupted/{label}: other seasons keep working", "states")
        page.close()
    # not found / unavailable
    for r, want in [("#/games/1999_01_MIN_ATL", "Game not found"), ("#/games/g_000000000000", "Game not found"), ("#/teams/fr_buf/2027", "Season not found"), ("#/teams/fr_nope/2000", "Season not found")]:
        page = ctx.new_page(); load(page, V + r)
        check(page.inner_text("main h1") == want and not RECORD_SHAPE.search(page.inner_text("main")), f"state not_found {r}: '{want}'", "states"); page.close()
    for f, y, kind in TS_NODATA:
        if kind == "not_found": continue
        page = ctx.new_page(); load(page, V + f"#/teams/{f}/{y}")
        t = page.inner_text("main")
        check(not RECORD_SHAPE.search(t) and not page.query_selector("main a[href^='#/games/']"), f"state {kind} {f}/{y}: no record numbers, no game links", "states")
        page.close()
    page = ctx.new_page(); load(page, F + "#/games/dg_0001")
    check(page.inner_text("main h1") == "Game" and "Demonstration game results" in page.inner_text("main"), "state unavailable (mock game): reason shown", "states"); page.close()
    page = ctx.new_page(); load(page, F + "#/teams/dm_lan/1990")
    check("Demonstration game results" in page.inner_text("main") and not RECORD_SHAPE.search(page.inner_text("main")), "state unavailable (mock team-season): reason, no numbers", "states"); page.close()
    ctx.close()
    httpd.shutdown()
    # missing snapshot: copy without data/snapshot
    tmp = Path(tempfile.mkdtemp(prefix="velora-s3-nosnap-"))
    shutil.copytree(FE, tmp / "fe", ignore=lambda d, n: [x for x in n if x == "snapshot" and Path(d).name == "data"])
    h2, b2 = serve(tmp / "fe")
    ctx = br.new_context()
    for r in ["#/games/g_d34106702f37", "#/teams/fr_buf/2022", "#/seasons/NFL/2022", "#/games/g_000000000000"]:
        page = ctx.new_page(); load(page, b2 + "validation.html" + r)
        check(page.inner_text("main h1") == "Snapshot not built", f"state missing snapshot {r}", "states")
        if r == "#/teams/fr_buf/2022": page.screenshot(path=str(SHOTS / "state_snapshot_not_built_desktop.png"))
        page.close()
    ctx.close(); h2.shutdown(); shutil.rmtree(tmp)

    # ------------------------------------------------ 5. expanded matrix (data-checked) at 1280 and 375
    httpd, base = serve(FE); V, F = base + "validation.html", base + "foundation.html"
    for width in (1280, 375):
        ctx = br.new_context(viewport={"width": width, "height": 900})
        page = ctx.new_page()
        for gid in GAME_IDS:
            g = by_id[gid]; errs = load(page, V + f"#/games/{gid}")
            t = page.inner_text("main"); h1 = page.inner_text("main h1")
            want = f"{name(g['away']['identity_id'])} {'vs.' if g['neutral_site'] else 'at'} {name(g['home']['identity_id'])}"
            scores = page.evaluate("[...document.querySelectorAll('.scoreline__score')].map(e => Number(e.textContent))")
            ok = (h1 == want and scores == [g["away"]["score"], g["home"]["score"]] and ("Final, overtime" in t) == g["overtime"]
                  and ("Tie" in page.inner_text(".scoreline__status")) == (g["home"]["score"] == g["away"]["score"]) and not STRAY.search(t) and not errs and overflow(page) <= 0)
            check(ok, f"matrix game {gid} ({g['season']} {g['game_type']}) @{width}: '{h1}' {scores}", "matrix")
        for f, y in TS:
            r = rec_of[(f, y)]; errs = load(page, V + f"#/teams/{f}/{y}")
            t = page.inner_text("main"); rows = page.evaluate("document.querySelectorAll('main a.result-link').length")
            rs = r["regular_season"]; reg = f"{rs['wins']}–{rs['losses']}" + (f"–{rs['ties']}" if rs["ties"] else "")
            ok = (page.inner_text("main h1") == f"{name(r['identity_id'])}, {y}" and reg in t and rows == rs["games"] + r["postseason"]["games"]
                  and (("16 of 17 expected" in t) == (r["status"] == "complete_with_note")) and not STRAY.search(t) and not errs and overflow(page) <= 0)
            check(ok, f"matrix team-season {f}/{y} @{width}: {reg}, {rows} games", "matrix")
        for f, y, kind in TS_NODATA:
            errs = load(page, V + f"#/teams/{f}/{y}")
            check(not errs and not RECORD_SHAPE.search(page.inner_text("main")) and overflow(page) <= 0, f"matrix no-data {f}/{y} ({kind}) @{width}", "matrix")
        for l, y in SEASONS:
            errs = load(page, V + f"#/seasons/{l}/{y}"); t = page.inner_text("main")
            check(not errs and "not in this development snapshot" not in t and "1999–2025" in t and overflow(page) <= 0, f"matrix season {l} {y} @{width}", "matrix")
        for r in ["#/games/dg_0001", "#/teams/dm_lan/1990", "#/seasons/DEMO/1974"]:
            errs = load(page, F + r)
            check(not errs and "Demonstration game results" in page.inner_text("main") and overflow(page) <= 0, f"matrix mock {r} @{width}", "matrix")
        ctx.close()
    # winner never marked in gold (gold reserved for selection/focus)
    ctx = br.new_context(); page = ctx.new_page(); load(page, V + "#/games/g_d34106702f37")
    cols = page.evaluate("[...document.querySelectorAll('.scoreline__row')].map(r => getComputedStyle(r.querySelector('.scoreline__score')).color)")
    check(all(c != "rgb(212, 175, 55)" for c in cols), f"visual: winner not marked in gold {cols}", "matrix"); ctx.close()

    # ------------------------------------------------ 6. screenshots for visual approval
    shots = [("game_regular", V + "#/games/g_d34106702f37"), ("game_tie_ot", V + "#/games/" + sel["tie"][-3]),
             ("game_neutral_wildcard", V + "#/games/" + sel["neutral_wc"][0]), ("game_super_bowl", V + "#/games/" + sel["super_bowl"][-1]),
             ("teamseason_buf_2022", V + "#/teams/fr_buf/2022"), ("teamseason_stl_rams_2015", V + "#/teams/fr_lar/2015"),
             ("teamseason_oilers_1998_outside", V + "#/teams/fr_ten/1998"), ("teamseason_buf_2026_not_completed", V + "#/teams/fr_buf/2026"),
             ("season_nfl_2022", V + "#/seasons/NFL/2022"), ("game_not_found", V + "#/games/g_000000000000"),
             ("mock_game_unavailable", F + "#/games/dg_0001"), ("mock_teamseason_unavailable", F + "#/teams/dm_lan/1990")]
    for vname, opts in [("desktop", {"viewport": {"width": 1280, "height": 900}}), ("mobile", {"viewport": {"width": 375, "height": 812}, "device_scale_factor": 2})]:
        ctx = br.new_context(**opts)
        for n, url in shots:
            page = ctx.new_page(); load(page, url); page.wait_for_timeout(400)
            page.screenshot(path=str(SHOTS / f"{n}_{vname}.png"), full_page=True); page.close()
        ctx.close()
    for n, opts, url in [("game_regular_forced_colors", {"viewport": {"width": 1280, "height": 900}, "forced_colors": "active"}, V + "#/games/g_d34106702f37"),
                         ("teamseason_buf_2022_zoom200", {"viewport": {"width": 640, "height": 450}, "device_scale_factor": 2}, V + "#/teams/fr_buf/2022"),
                         ("teamseason_buf_2022_320px", {"viewport": {"width": 320, "height": 700}}, V + "#/teams/fr_buf/2022")]:
        ctx = br.new_context(**opts); page = ctx.new_page(); load(page, url); page.wait_for_timeout(400)
        page.screenshot(path=str(SHOTS / f"{n}.png"), full_page=True); ctx.close()
    httpd.shutdown(); br.close()

(OUT / "s3_results.json").write_text(json.dumps(results, indent=1))
(OUT / "axe_findings.json").write_text(json.dumps(findings, indent=1))
(OUT / "matrix_selection.json").write_text(json.dumps({k: v for k, v in sel.items()} | {"team_seasons": TS, "no_data": TS_NODATA, "seasons": SEASONS}, indent=1))
groups = {}
for r in results: groups.setdefault(r["group"], [0, 0])[0 if r["ok"] else 1] += 1
for g, (ok, bad) in groups.items(): print(f"{g:9s} PASS {ok}  FAIL {bad}")
for r in results:
    if not r["ok"]: print("FAIL", r["msg"])
from collections import Counter
print("axe violations by impact:", Counter(f["impact"] for f in findings if f["kind"] == "violation"))
print("axe violations by rule:", Counter(f["id"] for f in findings if f["kind"] == "violation"))
print("axe needs-review by rule:", Counter(f["id"] for f in findings if f["kind"] == "needs_review"))
print(f"S3 HARNESS {'PASS' if all(r['ok'] for r in results) else 'FAIL'} {sum(r['ok'] for r in results)}/{len(results)}")
