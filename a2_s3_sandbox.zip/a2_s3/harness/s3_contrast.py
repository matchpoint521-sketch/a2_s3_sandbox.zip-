"""Empirical text-contrast check for axe 'needs review' color-contrast items (backdrop gradients).
Renders the page, records each text element's colour and box, re-renders with text made transparent,
and compares the text colour with the worst-case (closest-luminance) background pixel inside its box."""
import functools, http.server, io, json, sys, threading
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright
FE, OUT = Path(sys.argv[1]), Path(sys.argv[2])
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
h = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Q, directory=str(FE)))
threading.Thread(target=h.serve_forever, daemon=True).start()
base = f"http://127.0.0.1:{h.server_address[1]}/"
def lum(rgb):
    def c(v):
        v /= 255; return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = rgb[:3]; return 0.2126 * c(r) + 0.7152 * c(g) + 0.0722 * c(b)
def ratio(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True); return (la + 0.05) / (lb + 0.05)
PAGES = ["validation.html#/games/g_d34106702f37", "validation.html#/games/g_443cce357e60", "validation.html#/games/g_987fe5b35110",
         "validation.html#/teams/fr_buf/2022", "validation.html#/teams/fr_ten/1998", "validation.html#/seasons/NFL/2022",
         "validation.html#/games/g_000000000000", "foundation.html#/games/dg_0001", "foundation.html#/teams/dm_lan/1990"]
JS = """() => { const out = []; let i = 0;
  for (const el of document.querySelectorAll('body *')) {
    if (el.closest('.backdrop') || el.closest('.visually-hidden')) continue;
    const own = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
    if (!own) continue;
    const r = el.getBoundingClientRect(); if (r.width < 6 || r.height < 6) continue;
    if (el.checkVisibility && !el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) continue;
    const clip = el.closest('.table-wrap, details:not([open])'); if (clip && clip.tagName === 'DETAILS') continue;
    if (clip) { const c = clip.getBoundingClientRect(); if (r.left < c.left || r.right > c.right) continue; }
    const cs = getComputedStyle(el); if (cs.visibility !== 'visible' || parseFloat(cs.opacity) === 0) continue;
    const m = cs.color.match(/[\\d.]+/g).map(Number);
    out.push({ i: i++, sel: el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').join('.') : ''),
      text: el.textContent.trim().slice(0, 40), color: m.slice(0, 3), alpha: m[3] ?? 1,
      size: parseFloat(cs.fontSize), weight: Number(cs.fontWeight), x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height });
  } return out; }"""
rows = []
with sync_playwright() as p:
    br = p.chromium.launch()
    for vw in (1280, 375):
        ctx = br.new_context(viewport={"width": vw, "height": 900}, device_scale_factor=1, bypass_csp=True)  # measurement only
        for path in PAGES:
            pg = ctx.new_page(); pg.goto(base + path)
            pg.wait_for_function("() => document.querySelector('main h1') && !document.querySelector('main').hasAttribute('aria-busy')"); pg.wait_for_timeout(500)
            els = pg.evaluate(JS)
            pg.add_style_tag(content="*, *::before, *::after { color: transparent !important; text-shadow: none !important; text-decoration-color: transparent !important; caret-color: transparent !important; }")
            pg.wait_for_timeout(200)
            img = Image.open(io.BytesIO(pg.screenshot(full_page=True))).convert("RGB")
            for e in els:
                x0, y0 = max(0, int(e["x"])), max(0, int(e["y"])); x1, y1 = min(img.width, int(e["x"] + e["w"])), min(img.height, int(e["y"] + e["h"]))
                if x1 <= x0 or y1 <= y0: continue
                # inset 2 px so the element's own border and rounded corners are not read as its text background
                if x1 - x0 > 6 and y1 - y0 > 6: x0, y0, x1, y1 = x0 + 2, y0 + 2, x1 - 2, y1 - 2
                px = list(img.crop((x0, y0, x1, y1)).getdata())
                fg = e["color"]
                rs = sorted(ratio(fg, q) for q in px)
                worst = rs[int(len(rs) * 0.02)]  # 2nd percentile: robust to single anti-aliased pixels, still catches bright backdrop areas
                absolute_min = rs[0]
                large = e["size"] >= 24 or (e["size"] >= 18.66 and e["weight"] >= 700)
                need = 3.0 if large else 4.5
                rows.append({"page": path, "width": vw, "sel": e["sel"], "text": e["text"], "fg": fg, "alpha": e["alpha"], "ratio": round(worst, 2), "min_pixel_ratio": round(absolute_min, 2), "need": need, "ok": worst >= need and e["alpha"] == 1})
            pg.close()
        ctx.close()
    br.close()
h.shutdown()
(OUT / "contrast_measurements.json").write_text(json.dumps(rows, indent=1))
bad = [r for r in rows if not r["ok"]]
print("measured", len(rows), "text elements; below threshold:", len(bad))
for r in sorted(bad, key=lambda r: r["ratio"])[:25]: print(r["ratio"], "<", r["need"], r["width"], r["page"], r["sel"], repr(r["text"]))
print("min ratio overall", min(r["ratio"] for r in rows))
