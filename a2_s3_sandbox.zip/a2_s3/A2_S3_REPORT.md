# A2_S3_REPORT.md — Real-snapshot integration, accessibility and navigation verification
Velora NFL · F2.2d-A2 · S3 · 2026-10-22 · Status: **Tested (sandbox only) · Awaiting visual sign-off · Not applied to the Mac**
Authority: S3 authorization (A2-S2 approved). S4 and S5 not started.

## 0. Verdict
**S3: PASS in the sandbox, with the limitations in §8.**

This is not full acceptance:
- The R-3 staging test was skipped.
- R-4 is missing.
- Screen-reader testing was not done (automated checks only).
- Nothing has run on your Mac yet.

| Area | Result |
|---|---|
| S2 package and manifests | Verified (§1) |
| axe-core 4.10.2 | **0 violations at any impact.** 100 checks in the S3 harness plus every route in the browser smoke run. **Needs review:** colour contrast (backdrop gradients), measured separately at **800+ text elements, all ≥ 4.5:1; minimum 6.83:1**. |
| Keyboard, tab order, skip link, focus | 26/26 |
| Display modes (reduced motion, forced colours, 200% zoom, 375 px, 320 px) | 76/76 |
| States (loading, missing snapshot, unavailable, not found, corrupted data ×3) | 30/30 |
| Expanded matrix | 421/421: 178 games and 29 team-season/season/mock routes at 2 widths, values checked against the snapshot |
| Node | 101 tests: 100 pass, 0 fail, **1 skip (R-3)** |
| Python | 69 OK, no skips |
| Browser smoke with axe | 365/365 |
| P-1 | `--check` OK; gate passes; standalone file opens with no errors |
| Defects found | 2 usability defects, fixed in scope (§6). The new tests prove that both existed in S2. |

## 1. Pre-test verification of the S2 package

| Check | Result |
|---|---|
| `a2_s2_sandbox.zip` SHA-256 | `1f63098e…2e1388` = S2 report ✔ |
| Manifests | `a1_baseline.sha` `a5e3dd29…` (= A1 `a1_final.sha`), `a2_s2_tree.sha` `3703221d…`, `changes.tsv` `5c3c1e5b…` ✔ |
| Extracted tree vs `a2_s2_tree.sha` | Identical, 133 files ✔ |
| `SHA256SUMS` self-check | 97/97 ✔ |
| `changes.tsv` | Every before-hash matches the A1 baseline and every after-hash matches the tree. No unlisted differences. ✔ |

S3 worked in a separate copy (`work/`). The S2 copy and the A1 reference were confirmed unchanged at the end.

## 2. Accessibility

### 2.1 axe-core
- Version **4.10.2** from the npm registry, published 2024-10-23.
  - Tarball SHA-256 `9ea2d2d6…f89158100`; its SHA-1 matches the registry `dist.shasum`.
  - **`axe.min.js` SHA-256 `b511cd9dec01c76f4b2ad1723b66b6db37d4c2eb4ed199076e1829d9ee7b75e3`.** Details in `evidence/axe_pin.txt`.
- **S3 harness:** 50 routes × 2 widths (1280, 375), covering every A1 route in both versions, the A2 game and team-season pages in all states, and the season pages. Result: **0 violations at any impact (critical, serious, moderate, minor).**
- **`browser_smoke.py` with `AXE_JS`:** every route, 365/365, also **0 violations.**
- **Needs review (not violations):** the `color-contrast` rule could not decide on 100 of 100 scans (2,868 nodes) because text sits over the decorative backdrop gradients. This is expected for this design and also affects A1 pages.

### 2.2 Contrast measured separately (`harness/s3_contrast.py`)
Method:
1. Record each visible text element's colour and box.
2. Re-render with all text transparent.
3. Compare the text colour with the background pixels inside the box (2 px inset; 2nd-percentile worst pixel).

Scope: 9 pages × 2 widths (game REG/tie/SB/not-found, team-season BUF 2022 and Oilers 1998, season NFL 2022, mock game and team-season).

Result: **836 elements, 0 below threshold (4.5:1 normal, 3:1 large); minimum 6.83:1.** Measurements are in `evidence/contrast_measurements.json`.

**Limitation:** this is a pixel method in Chromium. It does not replace a manual review on your display.

### 2.3 Keyboard and focus (26/26)
Pages: game (valid, not found) and team-season (available, outside coverage).
- The first Tab reaches "Skip to content"; Enter moves focus to `main`.
- Every focused element shows a ≥ 2 px outline. There is no positive `tabindex`.
- **Every** link, button, `summary` and scroll region in `main` is reachable by Tab. Tab sequences are saved in `evidence/keyboard/`.
- Keyboard-only round trip works: team-season → Enter on a result link → game (focus on h1) → Enter on the team-season link → back (focus on h1). Browser Back also works.
- `summary` opens with Enter.
- Result links announce as e.g. "Win, 31–10, game details". The W/L/T letter is `aria-hidden`.
- Wide tables scroll inside labelled, focusable regions (`role=region`, `tabindex=0`).

## 3. Display modes (76/76)
Six routes in each mode: two games, two team-seasons, a season and not-found.

| Mode | Checks |
|---|---|
| 320 px | No page errors; no page-level horizontal overflow |
| 375 px | Same |
| 200% zoom (1280 px → 640 CSS px at 2×) | Same |
| Forced colours (emulated) | Backdrop hidden, scoreline text visible, no overflow |
| Reduced motion | No running transitions or animations in `main`; the A1 field sweep is still off |

**Forced colours:** the winner's heavier weight is not visible, but "Won", "Lost" and "Tie" are text, so the result is still clear.

## 4. States (30/30)

| State | How it was produced | Result |
|---|---|---|
| Loading | 2022 shard held for 1.5 s | `aria-busy=true` and "Loading this page" shown, then resolves to the game |
| Missing snapshot | Copy without `data/snapshot` | "Snapshot not built" on the game, team-season, season and invalid-game routes |
| Unavailable | Mock game and mock team-season | Provider reason shown, no numbers |
| Unavailable / outside coverage / not completed / empty | Oilers 1998, Browns 1997, 1944 merged, KC 1965 (AFL), BUF 2026, HOU 2000 | No record numbers and no game links |
| Not found | `1999_01_MIN_ATL`, `g_000000000000`, `fr_buf/2027`, `fr_nope/2000` | Correct "…not found" page |
| Corrupted data | Served in the browser via request interception; **no file was changed**. Variants: altered score (fails the record recompute), truncated JSON, and 404 for `games/2022.json` | Game page and the 2022 team-season show the error state (`role=alert`, Try again) with **nothing partial**. Other seasons (BUF 2021) keep working on the same page. |

## 5. Expanded route matrix (421/421; 1280 and 375 px)
Each check compares the page with the snapshot files: h1 text with the season's identity names and `at`/`vs.`, both scores in order, the overtime text, the tie text, no stray text, no page errors and no overflow.

| Group | Coverage |
|---|---|
| Games (178 unique) | All 27 **Super Bowls**; all 15 **ties**; all 28 **postseason overtime** games; all 66 neutral regular-season games (incl. international); the neutral Wild Card; all 36 **2022 BUF/CIN** games; the first game of each **relocation or rename** season (Rams 2015/16, Chargers 2016/17, Raiders 2019/20, Washington 2019/20/22) |
| Team-seasons (17 available) | Exact stored record, one result link per game, and "16 of 17" only for `complete_with_note`. Includes BUF/CIN 2022, HOU 2022 (tie), the relocation pairs, TEN 1999, NE/SEA 2025, LAR 2024 (neutral Wild Card), KC 2023. |
| No-data and not-found team-seasons | 8 |
| Season pages | NFL 2022, NFL 1950, AFL 1965, NFL 2026 (no false "not in this snapshot" text) |
| Mock | Game, team-season and season |
| Visual rule | The winner is never shown in gold |

## 6. Defects found in S3 and fixes (in scope; before/after hashes)

| # | Defect | Fix | File |
|---|---|---|---|
| D-S3-1 | At 375 px the opponent column wrapped one word per line and the **result column was off-screen**. Found in the mobile screenshot review. | Column order changed to **Week/Round · Opponent · Result · Date · Overtime**. CSS gives the opponent column a 9rem minimum width and keeps date and overtime on one line. **This changes the column order approved in S1 §4.3. Please confirm.** | `team-season.js`, `components.css` |
| D-S3-2 | Postseason game pages showed the round twice ("Game type: Super Bowl", "Round: Super Bowl") | "Game type" now reads **Postseason** for postseason games; "Round" keeps the label | `game.js` |
| — | Both fixes locked by new assertions. They fail on the S2 code (2 fails) and pass on S3 (15/15). | | `game_view.test.mjs` |

| File | S2 SHA-256 | S3 SHA-256 |
|---|---|---|
| `src/pages/game.js` | `358500f4…6d9794` | `e5c4c5b6…f727a5c3` |
| `src/pages/team-season.js` | `16d61096…ad9bfa375` | `84d5d71c…10445e27` |
| `src/styles/components.css` | `112f094e…52ad6e705dedf34c` | `3268176d…af93b8e2` |
| `tests/game_view.test.mjs` | `2ac92a44…4761e494` | `ef332048…be14e235c` |
| `SHA256SUMS` | `a7a4f8e6…2e5d6d` | `cacd3955…be10529` |

Full hashes are in `manifests/s3_fixes_delta.tsv`.

**No out-of-scope change was needed.** Providers, routes, snapshot data, the P-1 builder, entries, HTML and all A1 tests are untouched.

## 7. Regression and portability on the final S3 tree

| Check | Result | Evidence |
|---|---|---|
| Node | 101 tests: 100 pass, 0 fail, **1 skip** (`VELORA_F21_STAGING`, R-3) | `node.tap` |
| Python (R-2 inputs) | Ran 69, **OK**, no skips | `python.txt` |
| Browser smoke + axe | **365/365** | `browser_smoke_axe.txt` |
| S3 harness | **653/653** | `s3_harness.txt`, `s3_results.json` |
| P-1 `--check` | CHECK OK, `velora-nfl-foundation-6ca93c7e.html`, 325,141 bytes, **`portable_build_id=6ca93c7e6338c06a89193a4d4fb7a37900df1bad25f4d1e7d6597008c3479e2f`** (replaces the S2 value `76b5b51c…`) | `p1_check.txt` |
| P-1 two-graph gate | Both entries: 39 modules, including `games.js` and `game-view.js` | `p1_gate.txt` |
| Standalone file | Opened via `file://`: 5 mock routes, no errors, no non-file requests | `p1_standalone.txt` |
| `f2_2b/portable` | Unchanged (8/8) | |
| A2 tree | Unchanged by all test runs | |

**Final manifests:**
- `changes.tsv` (A1 → S3): 7 modified, 2 added, 0 removed, **0 outside the approved boundary**, 124 A1 files byte-identical. SHA-256 `84065ee2…`.
- `a2_s3_tree.sha`: 133 files, SHA-256 `9cd1c3c5…`.

**Expected values for S4/S5:**

| Item | Value |
|---|---|
| Node | 101/101 with `VELORA_F21_STAGING` |
| Python | 69 |
| `SHA256SUMS` | 97 entries, digest `cacd3955…` |
| Snapshot build ID | `5913437c…` (unchanged) |
| Portable ID | `6ca93c7e…` (proposed A2 record) |

## 8. Explicit limitations and unverified behaviour

| # | Limitation |
|---|---|
| L-1 | **R-3 not supplied.** The staging-snapshot Node test has never run on the A2 tree. It must run in S5 on your Mac (`VELORA_F21_STAGING`). |
| L-2 | **R-4 design spec missing.** Visual consistency was judged against `tokens.css` rules and needs your sign-off. Open style question: record numerals use the body font (U-10). |
| L-3 | **Accessibility limits.** axe is automated and catches only part of WCAG. No screen reader (VoiceOver/NVDA) was used. Contrast is measured, not reviewed by a person. Forced colours were emulated in Chromium, not Windows High Contrast. 200% zoom was approximated with a 640 CSS px viewport at 2×. |
| L-4 | **Browsers.** Chromium only. Safari (your likely browser) and Firefox are not tested. |
| L-5 | **Runtimes.** Sandbox Node 22 / Python 3.12 vs your Node 24 / Python 3.14. The Mac results in S5 are authoritative. |
| L-6 | **Error-state copy** (A1 shell, protected). It advises checking the local server but does not mention the documented reload-after-correction limitation. Out of A2 scope. |
| L-7 | **Carried from S2:** the stale mock wording and `team.js` copy (deferred, D-A2-6); the curation items for the 2022 note (X-8); the Python suite writing `tools/__pycache__` (pre-existing, pruned by manifests). |
| L-8 | **Column order (D-S3-1)** differs from the S1 contract and needs your confirmation. |

## 9. Screenshots for visual approval (`screenshots/`, 30 files)

| Group | Files |
|---|---|
| Desktop 1280 (12) | `game_regular`, `game_tie_ot`, `game_neutral_wildcard`, `game_super_bowl`, `game_not_found`, `teamseason_buf_2022`, `teamseason_stl_rams_2015`, `teamseason_oilers_1998_outside`, `teamseason_buf_2026_not_completed`, `season_nfl_2022`, `mock_game_unavailable`, `mock_teamseason_unavailable` (each `_desktop.png`) |
| Mobile 375 @2× (12) | The same pages (each `_mobile.png`) |
| Modes and states (6) | `game_regular_forced_colors`, `teamseason_buf_2022_zoom200`, `teamseason_buf_2022_320px`, `state_loading_desktop`, `state_data_error_desktop`, `state_snapshot_not_built_desktop` |

## 10. Requested decisions
1. **Visual sign-off** on the screenshots, including U-10 (record numeral font).
2. **Confirm D-S3-1** (column order) and D-S3-2 (postseason game type).
3. **Authorize S4** (packaging and the gated Mac installer). S4 will pin the S3 tree (`a2_s3_tree.sha` `9cd1c3c5…`) and the expected values in §7.
